// Resolution contract for the pitch test. Someone proposes an outcome with a bond, there is a
// challenge window, and a challenge names a different answer and sends the case to a jury drawn from the Council
// registry that votes in two steps, a hidden commitment and then the reveal, for one of the two answers. A jury that
// does not decide gets one larger second jury. Final outcomes are written to the market contract, which only trusts
// this contract.
// The JSON interface takes one argument per field, so a few methods are long on purpose.
#![allow(clippy::too_many_arguments)]

use near_sdk::borsh::{self, BorshDeserialize, BorshSerialize};
use near_sdk::json_types::{Base58CryptoHash, U128, U64};
use near_sdk::serde_json::json;
use near_sdk::store::LookupMap;
use near_sdk::{
    assert_one_yocto, env, ext_contract, near, require, AccountId, BorshStorageKey, CurveType, Gas, NearToken,
    PanicOnDefault, Promise, PromiseError, PublicKey,
};

const ONE_YOCTO: NearToken = NearToken::from_yoctonear(1);
const GAS_REMOVE_VERIFIER_KEY: Gas = Gas::from_tgas(15);
// The verifier burned 3.8 TGas for a payout from a contract in the sandbox (INTENTS-PROOF.md), so this is a wide margin.
const GAS_MT_TRANSFER: Gas = Gas::from_tgas(15);
const GAS_APPLY: Gas = Gas::from_tgas(20);
const GAS_CALLBACK: Gas = Gas::from_tgas(10);
// Measured against the Council's seat cap; see the note on CouncilContract.
const GAS_DRAW: Gas = Gas::from_tgas(250);
const GAS_DRAWN: Gas = Gas::from_tgas(15);
// unlock_case burned 8.9 TGas for a 21 juror case where every juror forfeits revenue, the most work it can do
// (measured in the sandbox), so 15 leaves room.
const GAS_UNLOCK: Gas = Gas::from_tgas(15);
// The gas floors. Each is what the method reserves for the calls it sends plus a margin over what it burns itself, and
// each was checked against the least that worked in the sandbox. A call below its floor fails
// part way through with a host error that names no amount, so these refuse it first and say how much to attach.
//
// A call that settles a case sends the answer to the market with its callback, then releases the first jury and, after a
// second round, the second. Its own work was 8.4 TGas in the worst case measured: a second round of 21 jurors, the 11th
// of them revealing a 1,000 byte reason. 72 TGas was the least that worked there.
const GAS_SETTLE_OVERHEAD: Gas = Gas::from_tgas(20);
const GAS_SETTLE_FLOOR: Gas =
    Gas::from_gas(GAS_APPLY.as_gas() + GAS_CALLBACK.as_gas() + 2 * GAS_UNLOCK.as_gas() + GAS_SETTLE_OVERHEAD.as_gas());
// The draw's own work is about 2.5 TGas; 270 TGas was the least that worked with the 250 it hands the council.
const GAS_DRAW_OVERHEAD: Gas = Gas::from_tgas(10);
const GAS_DRAW_FLOOR: Gas = Gas::from_gas(GAS_DRAW.as_gas() + GAS_DRAWN.as_gas() + GAS_DRAW_OVERHEAD.as_gas());
// retry_unlock attaches no fixed gas, so each of the two releases takes an equal share of what the caller attached. The
// floor leaves each one the 15 that settle gives it.
const GAS_RETRY_UNLOCK_OVERHEAD: Gas = Gas::from_tgas(5);
const GAS_RETRY_UNLOCK_FLOOR: Gas = Gas::from_gas(2 * GAS_UNLOCK.as_gas() + GAS_RETRY_UNLOCK_OVERHEAD.as_gas());
// A bond withdrawal sends the payout and then settles it, and burns about 3 TGas itself. 29 TGas was the least that worked in the
// sandbox.
const GAS_WITHDRAW_OVERHEAD: Gas = Gas::from_tgas(8);
const GAS_WITHDRAW_FLOOR: Gas =
    Gas::from_gas(GAS_MT_TRANSFER.as_gas() + GAS_CALLBACK.as_gas() + GAS_WITHDRAW_OVERHEAD.as_gas());
const SETTLE_REASON: &str = "a call that settles a case sends the answer to the market and releases the juries";
const NS_PER_MS: u64 = 1_000_000;
// The owner windows and the draw delay stop at a year and a day of blocks. A larger value overflows a deadline or pushes
// every draw past its limit.
const MAX_WINDOW_MS: u64 = 365 * 86_400_000;
const MAX_DRAW_DELAY_BLOCKS: u64 = 100_000;
// The owner cannot set a window shorter than an hour, a jury smaller than five or a bond under 5 USDC (6 decimals). Below
// these a case is too quick to notice, too easy to capture or too cheap to bother with.
const MIN_WINDOW_MS: u64 = 3_600_000;
const MIN_JURY_SIZE: u32 = 5;
const MIN_BOND: u128 = 5_000_000;
// A first draw that finds too few free seats is retried, up to this many draw windows after the challenge. The market's own
// deadline usually ends the wait sooner.
const MAX_DRAW_QUEUE_WINDOWS: u64 = 32;
const NS_PER_SEC: u64 = 1_000_000_000;
// The layout of the state below. migrate reads exactly this one and refuses any other.
const STATE_VERSION: u16 = 3;
// Token ids in the verifier are exactly "nep141:<contract>". Anything else would never match a transfer.
const NEP141_PREFIX: &str = "nep141:";
// Two disjoint groups of publishers must never both reach the threshold, or two prices could win for one moment.
const MAJORITY_NEEDED: &str = "the threshold must be more than half of the publishers";
// Settling a case still takes one more cross-contract hop (apply) to reach the market. This keeps a case that used
// its full allotted time clear of resolve_by, after which anyone can send the market its deadline answer. The owner can
// change it within the range below, for markets registered afterwards. Under 5 seconds the hop could miss the room it
// is meant to leave, and over 5 minutes every market would need an absurd gap between close_at and resolve_by.
const DEFAULT_APPLY_BUFFER_NS: u64 = 30_000_000_000;
const MIN_APPLY_BUFFER_NS: u64 = 5_000_000_000;
const MAX_APPLY_BUFFER_NS: u64 = 300_000_000_000;
// How long a payout can sit pending before the owner may decide it by hand, which leaves its callback time to arrive. The
// owner can move it between the bounds: under 10 minutes the callback may still be on its way, and over 7 days a bond stuck
// in flight waits too long for its money.
const DEFAULT_RECONCILE_WAIT_NS: u64 = 3_600_000_000_000;
const MIN_RECONCILE_WAIT_NS: u64 = 600_000_000_000;
const MAX_RECONCILE_WAIT_NS: u64 = 604_800_000_000_000;
// The council keeps one jury per key. A case's first jury is kept under the case's uid and its second under this bit
// set on the uid, so the two can never be taken for each other.
const SECOND_ROUND_KEY: u64 = 1 << 63;
// Text limits (bytes). Records are paid for out of this contract's own balance, so they must be bounded.
const MAX_EVIDENCE: usize = 512;
const MAX_REASON: usize = 1000;
const MAX_PANEL: usize = 21;
const MAX_SALT: usize = 64;
// A submission with all 10 signing burned 4.5 TGas in this contract, 9.4 in all, and worked with 30 TGas attached
// (measured in the sandbox). The owner can change the limit within the range below: 25 publishers is the most that
// keeps a submission inside its gas, and a limit of 1 is the least a price can be signed with.
const DEFAULT_MAX_PUBLISHERS: u32 = 10;
const MIN_MAX_PUBLISHERS: u32 = 1;
const MAX_MAX_PUBLISHERS: u32 = 25;
// The most market ids list_cases looks at in one call.
const MAX_LIST_CASES: u32 = 50;
// Of the loser's bond in a decided dispute, the share the jurors who revealed and sat with the majority split.
// The rest goes to the winner. The owner can change it for cases proposed afterwards, within the range below: under 5%
// a juror is paid too little to be worth the stake, and over 50% the winner of a dispute would net less than the
// loser's bond they were owed.
const DEFAULT_JUROR_SHARE_BPS: u32 = 2_500;
const MIN_JUROR_SHARE_BPS: u32 = 500;
const MAX_JUROR_SHARE_BPS: u32 = 5_000;
// Of the challenger's bond when neither jury decided, the share the jurors who revealed split. The rest goes to the
// proposer. With no juror having revealed, this share goes to the no-decision recipient instead, so it always leaves the
// two parties. Changeable like the share above. At least 10% so a jury that reveals is paid something, and at most all of
// it, which still leaves the proposer their own bond back.
const DEFAULT_NO_DECISION_JUROR_SHARE_BPS: u32 = 5_000;
const MIN_NO_DECISION_JUROR_SHARE_BPS: u32 = 1_000;
const MAX_NO_DECISION_JUROR_SHARE_BPS: u32 = 10_000;

#[near(serializers=[borsh])]
#[derive(BorshStorageKey)]
enum Key {
    Markets,
    Cases,
    Claimable,
    Payouts,
}

// Every record in a map is stored behind a one-byte version tag, so a later layout can be read next to this one. The
// wrapper is what the maps hold: it reads any stored version up to the current layout (the stored enum's into_current is
// where an upgrade from an older version goes) and always writes the current one.
macro_rules! versioned {
    ($name:ident, $stored:ident, $ty:ty) => {
        enum $stored {
            V1($ty),
        }

        impl $stored {
            fn into_current(self) -> $ty {
                match self {
                    Self::V1(value) => value,
                }
            }
        }

        #[derive(Clone)]
        struct $name($ty);

        impl $name {
            fn current(value: $ty) -> Self {
                Self(value)
            }

            fn into_inner(self) -> $ty {
                self.0
            }
        }

        impl std::ops::Deref for $name {
            type Target = $ty;

            fn deref(&self) -> &$ty {
                &self.0
            }
        }

        impl std::ops::DerefMut for $name {
            fn deref_mut(&mut self) -> &mut $ty {
                &mut self.0
            }
        }

        impl BorshSerialize for $name {
            fn serialize<W: borsh::io::Write>(&self, writer: &mut W) -> borsh::io::Result<()> {
                0u8.serialize(writer)?;
                self.0.serialize(writer)
            }
        }

        impl BorshDeserialize for $name {
            fn deserialize_reader<R: borsh::io::Read>(reader: &mut R) -> borsh::io::Result<Self> {
                let stored = match u8::deserialize_reader(reader)? {
                    0 => $stored::V1(<$ty>::deserialize_reader(reader)?),
                    _ => env::panic_str("a stored record has a newer version than this code can read"),
                };
                Ok(Self(stored.into_current()))
            }
        }
    };
}

// Like the one above for a record whose layout changed once: the stored version 0 is the `$previous` layout, read through
// its From impl, and the wrapper writes version 1.
macro_rules! versioned_after {
    ($name:ident, $stored:ident, $ty:ty, $previous:ty) => {
        enum $stored {
            V1($previous),
            V2($ty),
        }

        impl $stored {
            fn into_current(self) -> $ty {
                match self {
                    Self::V1(old) => old.into(),
                    Self::V2(value) => value,
                }
            }
        }

        #[derive(Clone)]
        struct $name($ty);

        impl $name {
            fn current(value: $ty) -> Self {
                Self(value)
            }

            fn into_inner(self) -> $ty {
                self.0
            }
        }

        impl std::ops::Deref for $name {
            type Target = $ty;

            fn deref(&self) -> &$ty {
                &self.0
            }
        }

        impl std::ops::DerefMut for $name {
            fn deref_mut(&mut self) -> &mut $ty {
                &mut self.0
            }
        }

        impl BorshSerialize for $name {
            fn serialize<W: borsh::io::Write>(&self, writer: &mut W) -> borsh::io::Result<()> {
                1u8.serialize(writer)?;
                self.0.serialize(writer)
            }
        }

        impl BorshDeserialize for $name {
            fn deserialize_reader<R: borsh::io::Read>(reader: &mut R) -> borsh::io::Result<Self> {
                let stored = match u8::deserialize_reader(reader)? {
                    0 => $stored::V1(<$previous>::deserialize_reader(reader)?),
                    1 => $stored::V2(<$ty>::deserialize_reader(reader)?),
                    _ => env::panic_str("a stored record has a newer version than this code can read"),
                };
                Ok(Self(stored.into_current()))
            }
        }
    };
}

// A market is known by its account and the id that account gave it, so two market contracts can both have a market 1.
type MarketKey = (AccountId, u64);

#[near(serializers=[borsh, json])]
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
#[serde(rename_all = "lowercase")]
pub enum Outcome {
    Yes,
    No,
    Void,
}

#[near(serializers=[borsh, json])]
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
#[serde(rename_all = "snake_case")]
pub enum Stage {
    Proposed,
    Disputed,
    Final,
}

impl Outcome {
    fn word(self) -> &'static str {
        match self {
            Outcome::Yes => "yes",
            Outcome::No => "no",
            Outcome::Void => "void",
        }
    }
}

// Set by market when it creates a price market, so the oracle knows what to check a signed price against.
// Yes if the price is at or above strike when `above` is true, Yes if it is below strike otherwise. strike and the
// signed price are integers scaled by 10^decimals.
#[near(serializers=[borsh, json])]
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct PriceRule {
    observation_time: U64,
    strike: U128,
    decimals: u8,
    above: bool,
}

#[near(serializers=[borsh, json])]
#[derive(Clone)]
pub struct MarketInfo {
    close_at: U64,
    resolve_by: U64,
    rule_hash: String,
    price_rule: Option<PriceRule>,
    // The windows in force when the market was registered. Every case of this market runs on them, so a longer setting
    // later can never leave an already registered market without the time to be answered.
    window_ns: U64,
    panel_deadline_ns: U64,
    draw_window_ns: U64,
    // The room left for apply() to land, as set when the market was registered.
    apply_buffer_ns: U64,
}

impl MarketInfo {
    fn case_span_ns(&self) -> u64 {
        case_span_ns(self.window_ns.0, self.draw_window_ns.0, self.panel_deadline_ns.0)
    }
}

versioned!(VersionedMarketInfo, StoredMarketInfo, MarketInfo);

#[near(serializers=[borsh, json])]
#[derive(Clone)]
pub struct Vote {
    juror: AccountId,
    outcome: Outcome,
    reason: String,
}

#[near(serializers=[borsh, json])]
#[derive(Clone)]
pub struct Commit {
    juror: AccountId,
    commitment: String,
}

#[near(serializers=[borsh, json])]
#[derive(Clone)]
pub struct Case {
    // Unique across every market account, from a counter that only goes up. The council keeps this case's juries under it.
    case_uid: U64,
    stage: Stage,
    proposer: AccountId,
    proposed: Outcome,
    // The bond in force when the answer was proposed. The challenge must match it and the case pays it out, so a new
    // bond setting touches only new cases.
    bond: U128,
    evidence: String,
    window_ends_at: U64,
    challenger: Option<AccountId>,
    // What the challenger says the answer is. Jurors vote for it or for `proposed`, so with an odd jury and full
    // turnout a majority always exists.
    challenger_answer: Option<Outcome>,
    // 0 for the first jury, 1 for the one jury that is drawn if the first did not decide.
    round: u8,
    // How many jurors the current round draws. Set when the answer is proposed and grown for the second round, so
    // changing the setting later never touches an open case. 0 only on a case stored before it was kept at proposal,
    // which takes the setting when it is challenged.
    jury_size: u32,
    // The last moment the current round's jury can be drawn. A round never drawn by then did not decide.
    draw_by: U64,
    draw_after_height: U64,
    // Both are set when the jury is seated, and count from that moment.
    commit_ends_at: U64,
    panel_deadline: U64,
    // The current round's jurors, drawn once. Changing the Council later never touches an open case.
    panel: Vec<AccountId>,
    // The first jury once a second one has been called for. It cannot sit again, and it is still owed or penalised
    // for what it did.
    first_panel: Vec<AccountId>,
    // True once any round has seated a jury. A case that never seated one was failed by the system, not by the
    // parties, so it returns each party's own bond.
    seated: bool,
    commits: Vec<Commit>,
    // Revealed votes only, from both rounds.
    votes: Vec<Vote>,
    final_outcome: Option<Outcome>,
    applied: bool,
    challenged_at: U64,
    // The shares of the bonds that go to jurors, as set when the answer was proposed. The case pays out on these, so a
    // new setting touches only new cases. The first is of the loser's bond in a decided dispute, the second of the
    // challenger's bond when no jury decided.
    juror_share_bps: u32,
    no_decision_share_bps: u32,
    // Set when a disputed case settles: the drawn jurors of either round who did not vote. The Council takes the
    // revenue their seats earned while serving. Kept on the case so retry_unlock sends the same list.
    delinquent: Vec<AccountId>,
    // The blocks to wait before a draw, as set when the answer was proposed. A case stored before this field existed has
    // none and takes old_case_draw_delay_blocks.
    draw_delay_blocks: Option<U64>,
}

// Exact layout of a case before it kept its own draw delay.
#[near(serializers=[borsh])]
#[derive(Clone)]
struct CaseV1 {
    case_uid: U64,
    stage: Stage,
    proposer: AccountId,
    proposed: Outcome,
    bond: U128,
    evidence: String,
    window_ends_at: U64,
    challenger: Option<AccountId>,
    challenger_answer: Option<Outcome>,
    round: u8,
    jury_size: u32,
    draw_by: U64,
    draw_after_height: U64,
    commit_ends_at: U64,
    panel_deadline: U64,
    panel: Vec<AccountId>,
    first_panel: Vec<AccountId>,
    seated: bool,
    commits: Vec<Commit>,
    votes: Vec<Vote>,
    final_outcome: Option<Outcome>,
    applied: bool,
    challenged_at: U64,
    juror_share_bps: u32,
    no_decision_share_bps: u32,
    delinquent: Vec<AccountId>,
}

impl From<CaseV1> for Case {
    fn from(old: CaseV1) -> Self {
        Self {
            case_uid: old.case_uid,
            stage: old.stage,
            proposer: old.proposer,
            proposed: old.proposed,
            bond: old.bond,
            evidence: old.evidence,
            window_ends_at: old.window_ends_at,
            challenger: old.challenger,
            challenger_answer: old.challenger_answer,
            round: old.round,
            jury_size: old.jury_size,
            draw_by: old.draw_by,
            draw_after_height: old.draw_after_height,
            commit_ends_at: old.commit_ends_at,
            panel_deadline: old.panel_deadline,
            panel: old.panel,
            first_panel: old.first_panel,
            seated: old.seated,
            commits: old.commits,
            votes: old.votes,
            final_outcome: old.final_outcome,
            applied: old.applied,
            challenged_at: old.challenged_at,
            juror_share_bps: old.juror_share_bps,
            no_decision_share_bps: old.no_decision_share_bps,
            delinquent: old.delinquent,
            draw_delay_blocks: None,
        }
    }
}

// One row of list_cases: where a case stands, without the evidence, the panel or the vote text.
#[near(serializers=[json])]
#[derive(Clone, Debug)]
pub struct CaseSummary {
    market: AccountId,
    market_id: U64,
    stage: Stage,
    proposed: Outcome,
    challenger_answer: Option<Outcome>,
    round: u8,
    final_outcome: Option<Outcome>,
    applied: bool,
    // Revealed votes only.
    votes: u32,
    window_ends_at: U64,
    draw_by: U64,
    panel_deadline: U64,
}

// What bond_totals adds up. total is what total_owed returns.
#[near(serializers=[json])]
#[derive(Clone, Copy, Debug)]
pub struct BondTotals {
    bonds_held: U128,
    claimable: U128,
    pending_payouts: U128,
    total: U128,
}

// A payout sent to the verifier whose callback has not run yet. It stays until the callback settles it.
#[near(serializers=[borsh, json])]
#[derive(Clone, Debug)]
pub struct Payout {
    account: AccountId,
    amount: U128,
    at: U64,
}

versioned_after!(VersionedCase, StoredCase, Case, CaseV1);
versioned!(VersionedPayout, StoredPayout, Payout);

// The NEAR Intents verifier. Bonds arrive in this contract's account there, and payouts are sent out of it.
#[ext_contract(ext_verifier)]
pub trait Verifier {
    fn remove_public_key(&mut self, public_key: PublicKey);
    fn mt_transfer(
        &mut self,
        receiver_id: AccountId,
        token_id: String,
        amount: U128,
        approval: Option<(AccountId, u64)>,
        memo: Option<String>,
    );
}

#[ext_contract(ext_market)]
pub trait Market {
    fn set_outcome(&mut self, market_id: U64, outcome: Outcome);
}

#[ext_contract(ext_council)]
pub trait Council {
    fn draw(&mut self, case_key: U64, n: u32, exclude: Vec<AccountId>) -> Vec<AccountId>;
    fn unlock_case(&mut self, case_key: U64, delinquent: Vec<AccountId>);
}

#[near(contract_state, contract_metadata(standard(standard = "nep297", version = "1.0.0")))]
#[derive(PanicOnDefault)]
pub struct OracleContract {
    // First, so migrate can read it before it trusts the rest of the layout.
    state_version: u16,
    // Set by migrate, so it is true only once an upgrade has gone through. seal refuses until then.
    upgrade_proven: bool,
    // Set by upgrade just before it sends the deploy and migrate batch, cleared by migrate. migrate refuses to run when it
    // is not set, so the proof cannot come from calling migrate by hand. A batch that fails leaves it set in the old code,
    // and the next upgrade sets it again.
    upgrade_in_flight: bool,
    owner: AccountId,
    // Set by propose_owner. Ownership moves only when this account calls accept_owner.
    pending_owner: Option<AccountId>,
    // The fast key for protective changes: it can remove a price publisher at once. Adding one, and changing how many
    // must agree, stay with the owner, which is the DAO.
    operator: AccountId,
    // The market accounts that may register markets and take new proposals. A market taken off the list keeps its open
    // cases: they can still be challenged and finish as before.
    allowed_markets: Vec<AccountId>,
    // The Intents verifier that holds every bond, and the exact id of the collateral in it, "nep141:<token>".
    verifier: AccountId,
    collateral_token_id: String,
    bond: u128,
    window_ns: u64,
    // The room left for apply() to land. Copied onto each market when it is registered.
    apply_buffer_ns: u64,
    // Copied onto each case when it is proposed, so a change never touches an open case. In basis points of the bond.
    juror_share_bps: u32,
    no_decision_share_bps: u32,
    // The most publishers that can be added. Lowering it removes none; it only stops more being added.
    max_publishers: u32,
    // How long each jury has once it is seated, the commit phase and then the reveal phase.
    panel_deadline_ns: u64,
    // How long after a challenge, or after the first jury fails, a jury can still be drawn.
    draw_window_ns: u64,
    // The least time a market must leave after close_at for someone to notice it closed and propose, on top of
    // the time a case needs to finish. register_market refuses markets with less, because they could only end in Void.
    min_proposal_ns: u64,
    council: AccountId,
    jury_size: u32,
    draw_delay_blocks: u64,
    // The network this contract runs on, signed into every price so a price signed for testnet is no use on mainnet.
    network: String,
    // The keys that sign prices, and how many of them must sign the same price for it to count.
    publishers: Vec<PublicKey>,
    price_threshold: u32,
    // Where the challenger's half bond goes when neither jury decided and no juror revealed. The owner is the DAO, which
    // takes no part in the token flow, so this is normally the business wallet.
    no_decision_recipient: AccountId,
    markets: LookupMap<MarketKey, VersionedMarketInfo>,
    cases: LookupMap<MarketKey, VersionedCase>,
    // The uid the last case got. Starts at 0, so the first case is 1, and only goes up.
    last_case_uid: u64,
    // Bonds waiting to be withdrawn, by account.
    claimable: LookupMap<AccountId, u128>,
    // The sum of every entry in claimable, and the bonds sitting in cases that are not final: one after a proposal, two
    // after a challenge. Kept so total_owed can add them up without walking a map.
    claimable_total: u128,
    bonds_held: u128,
    // Payouts sent to the verifier and not yet confirmed or refused, by id. The amount left claimable_total when the payout
    // was sent and sits in pending_payouts_total until its callback settles it, so total_owed still counts it.
    payouts: LookupMap<u64, VersionedPayout>,
    pending_payouts_total: u128,
    // How long a payout must be pending before reconcile_bond_payout can decide it.
    reconcile_wait_ns: u64,
    // The id the next payout gets. Starts at 1 and only goes up.
    last_payout_id: u64,
    // The draw delay at the upgrade that began keeping it on each case. A case stored before that has no delay of its own
    // and uses this one.
    old_case_draw_delay_blocks: u64,
}

// Exact layout of state version 2, before cases kept their own draw delay.
#[near(serializers=[borsh])]
struct StateV2 {
    state_version: u16,
    upgrade_proven: bool,
    upgrade_in_flight: bool,
    owner: AccountId,
    pending_owner: Option<AccountId>,
    operator: AccountId,
    allowed_markets: Vec<AccountId>,
    verifier: AccountId,
    collateral_token_id: String,
    bond: u128,
    window_ns: u64,
    apply_buffer_ns: u64,
    juror_share_bps: u32,
    no_decision_share_bps: u32,
    max_publishers: u32,
    panel_deadline_ns: u64,
    draw_window_ns: u64,
    min_proposal_ns: u64,
    council: AccountId,
    jury_size: u32,
    draw_delay_blocks: u64,
    network: String,
    publishers: Vec<PublicKey>,
    price_threshold: u32,
    no_decision_recipient: AccountId,
    markets: LookupMap<MarketKey, VersionedMarketInfo>,
    cases: LookupMap<MarketKey, VersionedCase>,
    last_case_uid: u64,
    claimable: LookupMap<AccountId, u128>,
    claimable_total: u128,
    bonds_held: u128,
    payouts: LookupMap<u64, VersionedPayout>,
    pending_payouts_total: u128,
    reconcile_wait_ns: u64,
    last_payout_id: u64,
}

impl From<StateV2> for OracleContract {
    fn from(old: StateV2) -> Self {
        let old_case_draw_delay_blocks = old.draw_delay_blocks;
        Self {
            state_version: STATE_VERSION,
            upgrade_proven: old.upgrade_proven,
            upgrade_in_flight: old.upgrade_in_flight,
            owner: old.owner,
            pending_owner: old.pending_owner,
            operator: old.operator,
            allowed_markets: old.allowed_markets,
            verifier: old.verifier,
            collateral_token_id: old.collateral_token_id,
            bond: old.bond,
            window_ns: old.window_ns,
            apply_buffer_ns: old.apply_buffer_ns,
            juror_share_bps: old.juror_share_bps,
            no_decision_share_bps: old.no_decision_share_bps,
            max_publishers: old.max_publishers,
            panel_deadline_ns: old.panel_deadline_ns,
            draw_window_ns: old.draw_window_ns,
            min_proposal_ns: old.min_proposal_ns,
            council: old.council,
            jury_size: old.jury_size,
            draw_delay_blocks: old.draw_delay_blocks,
            network: old.network,
            publishers: old.publishers,
            price_threshold: old.price_threshold,
            no_decision_recipient: old.no_decision_recipient,
            markets: old.markets,
            cases: old.cases,
            last_case_uid: old.last_case_uid,
            claimable: old.claimable,
            claimable_total: old.claimable_total,
            bonds_held: old.bonds_held,
            payouts: old.payouts,
            pending_payouts_total: old.pending_payouts_total,
            reconcile_wait_ns: old.reconcile_wait_ns,
            last_payout_id: old.last_payout_id,
            old_case_draw_delay_blocks,
        }
    }
}

fn emit(event: &str, data: near_sdk::serde_json::Value) {
    env::log_str(&format!(
        "EVENT_JSON:{}",
        json!({ "standard": "oracle", "version": "1.0.0", "event": event, "data": data })
    ));
}

fn valid_jury_size(n: u32) -> bool {
    n % 2 == 1 && (MIN_JURY_SIZE..=MAX_PANEL as u32).contains(&n)
}

fn require_window_ms(ms: u64) {
    require!(
        (MIN_WINDOW_MS..=MAX_WINDOW_MS).contains(&ms),
        "windows must be at least an hour and at most a year"
    );
}

fn require_bond(bond: u128) {
    require!(bond >= MIN_BOND, "the bond must be at least 5 USDC");
}

fn require_jury_size(n: u32) {
    require!(valid_jury_size(n), "jury size must be odd, from 5 to 21");
}

// How long a case can take from its proposal: the challenge window, then two rounds, each a draw window and a full
// panel deadline.
fn case_span_ns(window_ns: u64, draw_window_ns: u64, panel_deadline_ns: u64) -> u64 {
    window_ns + 2 * (draw_window_ns + panel_deadline_ns)
}

fn distinct(accounts: &[AccountId]) -> bool {
    let mut seen: Vec<&AccountId> = accounts.iter().collect();
    seen.sort();
    seen.dedup();
    seen.len() == accounts.len()
}

fn commitment_of(juror: &AccountId, outcome: Outcome, salt: &str) -> String {
    env::sha256_array(format!("{juror}:{}:{salt}", outcome.word()))
        .iter()
        .map(|b| format!("{b:02x}"))
        .collect()
}

fn is_commitment(s: &str) -> bool {
    s.len() == 64 && s.bytes().all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
}

// The drawn jurors who did not vote. In the first jury after it was replaced that is everyone who never revealed, its
// time being over. In the current jury it is those who never committed, and, once the reveal window is over, those
// who committed and never revealed. A case that settles early on a majority leaves the other committed jurors no
// chance to reveal, so while the window is still open they are not counted.
fn delinquent_jurors(case: &Case, now: u64) -> Vec<AccountId> {
    let revealed = |j: &AccountId| case.votes.iter().any(|v| v.juror == *j);
    let committed = |j: &AccountId| case.commits.iter().any(|c| c.juror == *j);
    let first = case.first_panel.iter().filter(|j| !revealed(j));
    let current = case
        .panel
        .iter()
        .filter(|j| !revealed(j) && (!committed(j) || now > case.panel_deadline.0));
    first.chain(current).cloned().collect()
}

// Whether the jury drawn for the current round did its work or ran out of time: with no jury seated that is the last
// moment to draw, with one seated it is the end of the reveal phase.
fn round_is_over(case: &Case, now: u64) -> bool {
    if case.panel.is_empty() {
        now > case.draw_by.0
    } else {
        now > case.panel_deadline.0
    }
}

fn council_key(case_uid: u64, round: u8) -> U64 {
    U64(if round == 0 {
        case_uid
    } else {
        case_uid | SECOND_ROUND_KEY
    })
}

// How a case ended, which decides who is paid what.
#[derive(Clone, Copy, PartialEq, Eq)]
enum Ruling {
    Unchallenged,
    // A majority of a jury voted for the outcome.
    Decided,
    // Neither jury reached a majority in time.
    NoDecision,
    // No jury could be drawn in either round, so nobody was ever asked.
    NoJury,
}

impl Ruling {
    fn word(self) -> &'static str {
        match self {
            Ruling::Unchallenged => "unchallenged",
            Ruling::Decided => "decided",
            Ruling::NoDecision => "no_decision",
            Ruling::NoJury => "no_jury",
        }
    }
}

// What a publisher signs: this contract and network, the market account and id, its observation time, the price and its
// decimals. Everything but the price is fixed by the market, so one signature is good for exactly one price of one market.
fn price_message(
    contract: &AccountId,
    network: &str,
    market: &AccountId,
    market_id: u64,
    rule: &PriceRule,
    price: u128,
) -> String {
    format!(
        "price:v2:{contract}:{network}:{market}:{market_id}:{}:{price}:{}",
        rule.observation_time.0, rule.decimals
    )
}

fn decode_signature(hex: &str) -> [u8; 64] {
    require!(hex.len() == 128 && hex.is_ascii(), "a signature is 128 hex characters");
    let mut signature = [0u8; 64];
    for (i, byte) in signature.iter_mut().enumerate() {
        *byte = u8::from_str_radix(&hex[2 * i..2 * i + 2], 16).unwrap_or_else(|_| env::panic_str("a signature is hex"));
    }
    signature
}

fn parse_outcome(s: &str) -> Outcome {
    match s {
        "yes" => Outcome::Yes,
        "no" => Outcome::No,
        "void" => Outcome::Void,
        _ => env::panic_str("outcome must be yes, no or void"),
    }
}

#[near]
impl OracleContract {
    // Only this account can run it, so a deploy and init batch signed by it is the one way in.
    #[private]
    #[init]
    pub fn new(
        owner_id: AccountId,
        market_contract: AccountId,
        verifier_id: AccountId,
        collateral_token_id: String,
        bond: U128,
        window_ms: U64,
        panel_deadline_ms: U64,
        draw_window_ms: U64,
        council: AccountId,
        jury_size: u32,
        draw_delay_blocks: U64,
        min_proposal_ms: U64,
        operator_id: AccountId,
        network: String,
        price_threshold: u32,
        no_decision_recipient: AccountId,
    ) -> Self {
        require!(
            collateral_token_id.starts_with(NEP141_PREFIX),
            "the collateral token id must look like nep141:<token>"
        );
        require_bond(bond.0);
        require!(
            !network.is_empty() && !network.contains(':'),
            "the network name must be a word without a colon"
        );
        require!(price_threshold > 0, "at least one publisher must sign a price");
        for ms in [window_ms.0, panel_deadline_ms.0, draw_window_ms.0, min_proposal_ms.0] {
            require_window_ms(ms);
        }
        require!(
            draw_delay_blocks.0 <= MAX_DRAW_DELAY_BLOCKS,
            "the draw delay must be at most 100000 blocks"
        );
        require_jury_size(jury_size);
        Self {
            state_version: STATE_VERSION,
            upgrade_proven: false,
            upgrade_in_flight: false,
            owner: owner_id,
            pending_owner: None,
            operator: operator_id,
            allowed_markets: vec![market_contract],
            verifier: verifier_id,
            collateral_token_id,
            bond: bond.0,
            window_ns: window_ms.0 * NS_PER_MS,
            apply_buffer_ns: DEFAULT_APPLY_BUFFER_NS,
            juror_share_bps: DEFAULT_JUROR_SHARE_BPS,
            no_decision_share_bps: DEFAULT_NO_DECISION_JUROR_SHARE_BPS,
            max_publishers: DEFAULT_MAX_PUBLISHERS,
            panel_deadline_ns: panel_deadline_ms.0 * NS_PER_MS,
            draw_window_ns: draw_window_ms.0 * NS_PER_MS,
            min_proposal_ns: min_proposal_ms.0 * NS_PER_MS,
            council,
            jury_size,
            draw_delay_blocks: draw_delay_blocks.0,
            network,
            publishers: vec![],
            price_threshold,
            no_decision_recipient,
            markets: LookupMap::new(Key::Markets),
            cases: LookupMap::new(Key::Cases),
            last_case_uid: 0,
            claimable: LookupMap::new(Key::Claimable),
            claimable_total: 0,
            bonds_held: 0,
            payouts: LookupMap::new(Key::Payouts),
            pending_payouts_total: 0,
            reconcile_wait_ns: DEFAULT_RECONCILE_WAIT_NS,
            last_payout_id: 0,
            old_case_draw_delay_blocks: draw_delay_blocks.0,
        }
    }

    // Anyone can stage a wasm: the call input is the code, the deposit pays for its storage and the answer is its hash.
    #[payable]
    pub fn stage_code(&mut self) -> Base58CryptoHash {
        let staged = upgrade::stage_code();
        emit(
            "code_staged",
            json!({ "code_hash": staged.code_hash, "bytes": staged.bytes.to_string(), "by": staged.by }),
        );
        staged.code_hash
    }

    // Owner only, which is the DAO. SputnikDAO runs a proposal as soon as it passes, so its voting period is the only
    // delay a code change waits out. The deploy and migrate are one batch: a migrate that panics puts the old code back.
    // Attach at least 100 TGas.
    pub fn upgrade(&mut self, code_hash: Base58CryptoHash) -> Promise {
        upgrade::require_upgrade_gas();
        self.only_owner();
        let code = upgrade::take_staged(code_hash);
        self.upgrade_in_flight = true;
        emit("upgrade_sent", json!({ "code_hash": code_hash }));
        upgrade::deploy_and_migrate(code).then(
            Self::ext(env::current_account_id())
                .with_static_gas(upgrade::GAS_UPGRADE_DONE)
                .on_upgrade_done(),
        )
    }

    // A batch that fails leaves the old code and the flag `upgrade` set. Cleared here, so nobody can call migrate by hand to
    // fake the proof that lets the owner seal a contract whose upgrade path never worked.
    #[private]
    pub fn on_upgrade_done(&mut self, #[callback_result] result: Result<(), PromiseError>) {
        if result.is_err() {
            self.upgrade_in_flight = false;
            emit("upgrade_failed", json!({}));
        }
    }

    // Runs in the new code, in the same batch as the deploy. It reads the current layout or the one before it, which is
    // StateV2. A later version keeps a copy of the current struct, reads that, builds its own state from it and bumps
    // state_version.
    #[private]
    #[init(ignore_state)]
    pub fn migrate() -> Self {
        let bytes = env::storage_read(b"STATE").unwrap_or_else(|| env::panic_str("there is no state to migrate"));
        require!(bytes.len() >= 2, "invalid state");
        let mut state: Self = match u16::from_le_bytes([bytes[0], bytes[1]]) {
            STATE_VERSION => env::state_read().unwrap_or_else(|| env::panic_str("invalid current state")),
            2 => Self::from(env::state_read::<StateV2>().unwrap_or_else(|| env::panic_str("invalid previous state"))),
            _ => env::panic_str("unsupported state version"),
        };
        require!(state.upgrade_in_flight, "migrate runs only inside an upgrade");
        // An older build allowed a threshold that two separate groups of publishers could both reach. The upgrade stops until
        // the owner fixes it in the old code.
        require!(
            2 * state.price_threshold as usize > state.publishers.len(),
            MAJORITY_NEEDED
        );
        // An older build allowed settings below the floors. The upgrade stops until the owner raises them in the old code.
        require_bond(state.bond);
        for ns in [
            state.window_ns,
            state.panel_deadline_ns,
            state.draw_window_ns,
            state.min_proposal_ns,
        ] {
            require_window_ms(ns / NS_PER_MS);
        }
        require_jury_size(state.jury_size);
        state.upgrade_in_flight = false;
        state.upgrade_proven = true;
        emit("migrated", json!({ "state_version": state.state_version }));
        state
    }

    // Deletes one access key of this account, for good if it is the last. Refused until an upgrade has gone through.
    pub fn seal(&mut self, public_key: PublicKey) -> Promise {
        self.only_owner();
        require!(self.upgrade_proven, "prove the upgrade path before deleting keys");
        emit("seal_sent", json!({ "public_key": public_key }));
        upgrade::delete_key(public_key)
    }

    // Seal deletes NEAR access keys only. A key registered for this account in the Intents verifier can still move everything it
    // holds, so the owner removes one here, as this account, the way the verifier requires.
    pub fn remove_verifier_key(&mut self, public_key: PublicKey) -> Promise {
        self.only_owner();
        emit("verifier_key_removal_sent", json!({ "public_key": public_key }));
        ext_verifier::ext(self.verifier.clone())
            .with_attached_deposit(ONE_YOCTO)
            .with_static_gas(GAS_REMOVE_VERIFIER_KEY)
            .remove_public_key(public_key)
    }

    // Applies to cases proposed from now on. A case already proposed keeps the bond it was proposed with.
    pub fn set_bond(&mut self, bond: U128) {
        self.only_owner();
        require_bond(bond.0);
        emit("bond_set", json!({ "bond": bond }));
        self.bond = bond.0;
    }

    // The four windows below apply to markets registered from now on. A registered market keeps the ones it was
    // registered with, and min_proposal_ms only matters at registration.
    pub fn set_window_ms(&mut self, window_ms: U64) {
        self.only_owner();
        require_window_ms(window_ms.0);
        emit("window_set", json!({ "window_ms": window_ms }));
        self.window_ns = window_ms.0 * NS_PER_MS;
    }

    pub fn set_panel_deadline_ms(&mut self, panel_deadline_ms: U64) {
        self.only_owner();
        require_window_ms(panel_deadline_ms.0);
        emit("panel_deadline_set", json!({ "panel_deadline_ms": panel_deadline_ms }));
        self.panel_deadline_ns = panel_deadline_ms.0 * NS_PER_MS;
    }

    pub fn set_min_proposal_ms(&mut self, min_proposal_ms: U64) {
        self.only_owner();
        require_window_ms(min_proposal_ms.0);
        emit("min_proposal_set", json!({ "min_proposal_ms": min_proposal_ms }));
        self.min_proposal_ns = min_proposal_ms.0 * NS_PER_MS;
    }

    pub fn set_draw_window_ms(&mut self, draw_window_ms: U64) {
        self.only_owner();
        require_window_ms(draw_window_ms.0);
        emit("draw_window_set", json!({ "draw_window_ms": draw_window_ms }));
        self.draw_window_ns = draw_window_ms.0 * NS_PER_MS;
    }

    // Applies to answers proposed from now on. A case already proposed keeps the delay it was proposed with, in blocks.
    pub fn set_draw_delay_blocks(&mut self, draw_delay_blocks: U64) {
        self.only_owner();
        require!(
            draw_delay_blocks.0 <= MAX_DRAW_DELAY_BLOCKS,
            "the draw delay must be at most 100000 blocks"
        );
        emit("draw_delay_set", json!({ "draw_delay_blocks": draw_delay_blocks }));
        self.draw_delay_blocks = draw_delay_blocks.0;
    }

    // Applies to cases proposed from now on. A case already proposed pays out on the shares it was proposed with. The
    // first is of the loser's bond in a decided dispute, the second of the challenger's bond when no jury decided.
    pub fn set_juror_shares(&mut self, decided_bps: u32, no_decision_bps: u32) {
        self.only_owner();
        require!(
            (MIN_JUROR_SHARE_BPS..=MAX_JUROR_SHARE_BPS).contains(&decided_bps),
            "the decided juror share must be between 500 and 5000 basis points"
        );
        require!(
            (MIN_NO_DECISION_JUROR_SHARE_BPS..=MAX_NO_DECISION_JUROR_SHARE_BPS).contains(&no_decision_bps),
            "the no decision juror share must be between 1000 and 10000 basis points"
        );
        emit(
            "juror_shares_set",
            json!({ "decided_bps": decided_bps, "no_decision_bps": no_decision_bps }),
        );
        self.juror_share_bps = decided_bps;
        self.no_decision_share_bps = no_decision_bps;
    }

    // Applies to markets registered from now on. A registered market keeps the buffer it was registered with.
    pub fn set_apply_buffer_ms(&mut self, apply_buffer_ms: U64) {
        self.only_owner();
        require!(
            (MIN_APPLY_BUFFER_NS / NS_PER_MS..=MAX_APPLY_BUFFER_NS / NS_PER_MS).contains(&apply_buffer_ms.0),
            "the apply buffer must be between 5 seconds and 5 minutes"
        );
        emit("apply_buffer_set", json!({ "apply_buffer_ms": apply_buffer_ms }));
        self.apply_buffer_ns = apply_buffer_ms.0 * NS_PER_MS;
    }

    // How long a payout must be pending before the owner can decide it by hand. It applies to every payout from now on.
    pub fn set_reconcile_wait_ns(&mut self, reconcile_wait_ns: U64) {
        self.only_owner();
        require!(
            (MIN_RECONCILE_WAIT_NS..=MAX_RECONCILE_WAIT_NS).contains(&reconcile_wait_ns.0),
            "the reconcile wait must be between 10 minutes and 7 days"
        );
        emit(
            "reconcile_wait_set",
            json!({ "reconcile_wait_ns": reconcile_wait_ns.0.to_string() }),
        );
        self.reconcile_wait_ns = reconcile_wait_ns.0;
    }

    // Live. It never removes a publisher, and it cannot go below the number that must sign a price.
    pub fn set_max_publishers(&mut self, max_publishers: u32) {
        self.only_owner();
        require!(
            (MIN_MAX_PUBLISHERS..=MAX_MAX_PUBLISHERS).contains(&max_publishers),
            "the publisher limit must be between 1 and 25"
        );
        require!(
            max_publishers >= self.price_threshold,
            "the publisher limit cannot be below the number that must sign"
        );
        emit("max_publishers_set", json!({ "max_publishers": max_publishers }));
        self.max_publishers = max_publishers;
    }

    // Two steps, so a mistyped account cannot lock the owner out: nothing changes until the new owner accepts.
    pub fn propose_owner(&mut self, new_owner: AccountId) {
        require!(env::predecessor_account_id() == self.owner, "owner only");
        emit("owner_proposed", json!({ "owner": self.owner, "proposed": new_owner }));
        self.pending_owner = Some(new_owner);
    }

    pub fn accept_owner(&mut self) {
        let who = env::predecessor_account_id();
        require!(self.pending_owner.as_ref() == Some(&who), "not the proposed owner");
        emit("owner_changed", json!({ "from": self.owner, "to": who }));
        self.owner = who;
        self.pending_owner = None;
    }

    // Applies to answers proposed from now on. A case already proposed keeps the jury size it was proposed with.
    pub fn set_jury_size(&mut self, jury_size: u32) {
        require!(env::predecessor_account_id() == self.owner, "owner only");
        require_jury_size(jury_size);
        emit("jury_size_set", json!({ "jury_size": jury_size }));
        self.jury_size = jury_size;
    }

    // Lets a market contract register markets and take proposals and challenges. Owner only, which is the DAO.
    pub fn allow_market(&mut self, market: AccountId) {
        self.only_owner();
        require!(!self.allowed_markets.contains(&market), "already an allowed market");
        emit("market_allowed", json!({ "market": market }));
        self.allowed_markets.push(market);
    }

    // Stops new registrations, proposals and challenges from that market contract. Its open cases still finish, settle, pay
    // out their bonds and release their juries. The last one can be removed: nothing then registers until another is
    // allowed, and no stored case is touched.
    pub fn disallow_market(&mut self, market: AccountId) {
        self.only_owner();
        let at = self
            .allowed_markets
            .iter()
            .position(|m| *m == market)
            .unwrap_or_else(|| env::panic_str("not an allowed market"));
        emit("market_disallowed", json!({ "market": market }));
        self.allowed_markets.remove(at);
    }

    pub fn set_operator(&mut self, operator_id: AccountId) {
        require!(env::predecessor_account_id() == self.owner, "owner only");
        emit("operator_set", json!({ "operator": operator_id }));
        self.operator = operator_id;
    }

    pub fn set_no_decision_recipient(&mut self, recipient: AccountId) {
        require!(env::predecessor_account_id() == self.owner, "owner only");
        emit("no_decision_recipient_set", json!({ "recipient": recipient }));
        self.no_decision_recipient = recipient;
    }

    // Adding a publisher grants power over prices, so it is the owner's (a DAO proposal).
    pub fn add_publisher(&mut self, key: PublicKey) {
        require!(env::predecessor_account_id() == self.owner, "owner only");
        require!(key.curve_type() == CurveType::ED25519, "publishers use ed25519 keys");
        require!(!self.publishers.contains(&key), "already a publisher");
        require!(
            self.publishers.len() < self.max_publishers as usize,
            &format!("there can be at most {} publishers", self.max_publishers)
        );
        require!(
            2 * self.price_threshold as usize > self.publishers.len() + 1,
            MAJORITY_NEEDED
        );
        emit("publisher_added", json!({ "key": key }));
        self.publishers.push(key);
    }

    // Removing one only ever takes power away, so the operator can do it at once: a leaked key is cut off in one call
    // instead of waiting out a vote. It can never leave fewer publishers than must sign, or no price could be accepted.
    pub fn remove_publisher(&mut self, key: PublicKey) {
        let who = env::predecessor_account_id();
        require!(who == self.operator || who == self.owner, "operator or owner only");
        let at = self
            .publishers
            .iter()
            .position(|k| *k == key)
            .unwrap_or_else(|| env::panic_str("not a publisher"));
        require!(
            self.publishers.len() > self.price_threshold as usize,
            "that would leave fewer publishers than must sign"
        );
        emit("publisher_removed", json!({ "key": key, "by": who }));
        self.publishers.remove(at);
    }

    pub fn set_price_threshold(&mut self, threshold: u32) {
        require!(env::predecessor_account_id() == self.owner, "owner only");
        require!(
            threshold > 0 && threshold as usize <= self.publishers.len(),
            "the threshold must be between 1 and the number of publishers"
        );
        require!(2 * threshold as usize > self.publishers.len(), MAJORITY_NEEDED);
        emit("price_threshold_set", json!({ "threshold": threshold }));
        self.price_threshold = threshold;
    }

    // Called by the market contract when a market is created. Calling twice changes nothing. A market that
    // leaves less than min_resolve_gap_ns between close_at and resolve_by is refused: no case could ever finish
    // in it, so the only way it could end is a Void at its deadline, which pays the cheap side a windfall.
    // A price market is measured from its observation time, the moment its answer is first known, and needs enough
    // publishers configured that it can be answered at all.
    pub fn register_market(
        &mut self,
        market_id: U64,
        close_at: U64,
        resolve_by: U64,
        rule_hash: String,
        price_rule: Option<PriceRule>,
    ) {
        let market = env::predecessor_account_id();
        self.require_allowed(&market);
        if self.markets.contains_key(&(market.clone(), market_id.0)) {
            return;
        }
        let answerable_from = match &price_rule {
            Some(rule) => {
                require!(
                    self.publishers.len() >= self.price_threshold as usize,
                    "not enough price publishers are configured"
                );
                require!(
                    rule.observation_time.0 >= close_at.0,
                    "observation_time must not be before close_at"
                );
                rule.observation_time.0
            }
            None => close_at.0,
        };
        require!(
            resolve_by.0.saturating_sub(answerable_from) >= self.min_resolve_gap_ns(),
            "resolve_by is too soon after close_at for a case to finish"
        );
        self.markets.insert(
            (market.clone(), market_id.0),
            VersionedMarketInfo::current(MarketInfo {
                close_at,
                resolve_by,
                rule_hash,
                price_rule,
                window_ns: U64(self.window_ns),
                panel_deadline_ns: U64(self.panel_deadline_ns),
                draw_window_ns: U64(self.draw_window_ns),
                apply_buffer_ns: U64(self.apply_buffer_ns),
            }),
        );
        emit(
            "market_registered",
            json!({ "market": market, "market_id": market_id.0.to_string() }),
        );
    }

    // Bonds arrive here, from the verifier, after a user's mt_transfer_call (or a signed transfer with a notification), once
    // the money is already in this contract's Intents account. A market is named by its account and its id there.
    // Propose: "propose:<market account>:<market id>:<yes|no|void>:<evidence url>".
    // Challenge: "challenge:<market account>:<market id>:<yes|no|void>", naming the answer the challenger says is right.
    // Answer a price market: "price:<market account>:<market id>:<price>:<publisher key>.<signature hex>,<publisher key>.<signature hex>,...".
    // The answer is the amounts to hand back, so 0 keeps the whole bond. Panicking makes the verifier refund the sender in
    // full. A plain deposit never reaches here: it is surplus that nobody is credited for (see total_owed). There is no gas
    // floor: the verifier keeps about 21 TGas of what is attached, a bond opened its case with 22 attached and not with 21
    // (sandbox), and a receipt that runs short fails and is refunded.
    pub fn mt_on_transfer(
        &mut self,
        sender_id: AccountId,
        previous_owner_ids: Vec<AccountId>,
        token_ids: Vec<String>,
        amounts: Vec<U128>,
        msg: String,
    ) -> Vec<U128> {
        require!(
            env::predecessor_account_id() == self.verifier,
            "only the verifier can deliver money"
        );
        require!(
            token_ids.len() == 1 && amounts.len() == 1,
            "exactly one token and amount"
        );
        require!(token_ids[0] == self.collateral_token_id, "wrong token");
        require!(
            previous_owner_ids.as_slice() == [sender_id.clone()],
            "the money must come from the sender's own balance"
        );
        let amount = amounts[0];
        require!(amount.0 > 0, "amount must be positive");
        let mut parts = msg.splitn(5, ':');
        let action = parts.next().unwrap_or("");
        let market: AccountId = parts
            .next()
            .and_then(|s| s.parse().ok())
            .unwrap_or_else(|| env::panic_str("bad market account"));
        let id: u64 = parts
            .next()
            .and_then(|s| s.parse().ok())
            .unwrap_or_else(|| env::panic_str("bad market id"));
        // A market taken off the list takes nothing new, but a case it already has stays open to a challenge: otherwise a
        // wrong answer would finalize with nobody able to dispute it.
        if !(action == "challenge" && self.get_case_of(&market, id).is_some()) {
            self.require_allowed(&market);
        }
        // A challenge matches the bond its case was proposed with, which may not be today's.
        let due = match action {
            "challenge" => self.get_case_of(&market, id).map_or(self.bond, |case| case.bond.0),
            _ => self.bond,
        };
        require!(amount.0 == due, "send exactly the bond");
        match action {
            "propose" => {
                let outcome = parse_outcome(parts.next().unwrap_or(""));
                let evidence = parts.next().unwrap_or("").to_string();
                let is_price_market = self.get_market_of(&market, id).is_some_and(|m| m.price_rule.is_some());
                require!(!is_price_market, "a price market is answered with a signed price");
                self.propose(sender_id, &market, id, outcome, evidence, &[]);
            }
            "price" => {
                let price: u128 = parts
                    .next()
                    .and_then(|s| s.parse().ok())
                    .unwrap_or_else(|| env::panic_str("bad price"));
                self.answer_price(sender_id, &market, id, price, parts.next().unwrap_or(""));
            }
            "challenge" => self.challenge(sender_id, &market, id, parse_outcome(parts.next().unwrap_or(""))),
            _ => env::panic_str("unknown action"),
        }
        self.bonds_held += amount.0;
        vec![U128(0)]
    }

    // Anyone can call this once the draw delay has passed and until the case's draw_by. The seed is the block seed of the
    // council's receipt, a block after the challenge, so nobody knows the jury when they challenge or can steer it with
    // what they pass. A failed draw changes nothing and can be retried. The second jury leaves out the first one, along
    // with the proposer and the challenger.
    pub fn resolve_draw(&mut self, market: AccountId, market_id: U64) -> Promise {
        upgrade::require_gas(GAS_DRAW_FLOOR, "the jury draw reads every staked seat");
        let case = self.case(&market, market_id.0);
        require!(case.stage == Stage::Disputed, "no open dispute");
        require!(case.panel.is_empty(), "the jury is already drawn");
        require!(
            env::block_height() >= case.draw_after_height.0,
            "too early to draw the jury"
        );
        require!(env::block_timestamp() <= case.draw_by.0, "too late to draw a jury");
        let challenger = case.challenger.unwrap_or_else(|| env::panic_str("no challenger"));
        let mut exclude = vec![case.proposer, challenger];
        exclude.extend(case.first_panel);
        ext_council::ext(self.council.clone())
            .with_static_gas(GAS_DRAW)
            .draw(council_key(case.case_uid.0, case.round), case.jury_size, exclude)
            .then(
                Self::ext(env::current_account_id())
                    .with_static_gas(GAS_DRAWN)
                    .on_drawn(market, market_id, case.round),
            )
    }

    // Two draws can be in flight at once. The first good one to land is the jury, and the jury's time starts when it
    // lands. A draw for a round the case has moved past is refused.
    #[private]
    pub fn on_drawn(
        &mut self,
        market: AccountId,
        market_id: U64,
        round: u8,
        #[callback_result] result: Result<Vec<AccountId>, PromiseError>,
    ) {
        let mut case = self.case(&market, market_id.0);
        match result {
            Ok(jury)
                if case.stage == Stage::Disputed
                    && case.round == round
                    && case.panel.is_empty()
                    && jury.len() == case.jury_size as usize
                    && distinct(&jury) =>
            {
                let seated = env::block_timestamp();
                let panel_deadline_ns = self.market_info(&market, market_id.0).panel_deadline_ns.0;
                emit(
                    "jury_drawn",
                    json!({ "market": market, "market_id": market_id.0.to_string(), "round": round, "panel": jury }),
                );
                case.commit_ends_at = U64(seated + panel_deadline_ns / 2);
                case.panel_deadline = U64(seated + panel_deadline_ns);
                case.panel = jury;
                case.seated = true;
                self.put_case(&market, market_id.0, case);
            }
            _ => emit(
                "draw_failed",
                json!({ "market": market, "market_id": market_id.0.to_string(), "round": round }),
            ),
        }
    }

    // A juror's vote stays hidden until the commit phase ends. The commitment is
    // hex(sha256("<juror>:<yes|no|void>:<salt>")), so one juror cannot reuse another's. A juror must commit to the
    // proposed answer or the challenger's, because no other vote can be revealed.
    #[payable]
    pub fn commit_vote(&mut self, market: AccountId, market_id: U64, commitment: String) {
        assert_one_yocto();
        let juror = env::predecessor_account_id();
        let mut case = self.case(&market, market_id.0);
        require!(case.panel.contains(&juror), "not on the panel for this case");
        require!(case.stage == Stage::Disputed, "no open dispute");
        require!(
            env::block_timestamp() < case.commit_ends_at.0,
            "the commit phase is over"
        );
        require!(
            is_commitment(&commitment),
            "commitment must be 64 lowercase hex characters"
        );
        require!(!case.commits.iter().any(|c| c.juror == juror), "already committed");
        case.commits.push(Commit {
            juror: juror.clone(),
            commitment: commitment.clone(),
        });
        self.put_case(&market, market_id.0, case);
        emit(
            "vote_committed",
            json!({ "market": market, "market_id": market_id.0.to_string(), "juror": juror, "commitment": commitment }),
        );
    }

    // ponytail: a juror who commits and never reveals just does not count. The penalty for a no-show
    // moves into the Council registry with staking in slice 2.
    #[payable]
    pub fn reveal_vote(&mut self, market: AccountId, market_id: U64, outcome: Outcome, salt: String, reason: String) {
        upgrade::require_gas(GAS_SETTLE_FLOOR, SETTLE_REASON);
        assert_one_yocto();
        let juror = env::predecessor_account_id();
        require!(!reason.trim().is_empty(), "a reason is required");
        require!(reason.len() <= MAX_REASON, "reason is too long");
        require!(salt.len() <= MAX_SALT, "salt is too long");
        let mut case = self.case(&market, market_id.0);
        let commit = case
            .commits
            .iter()
            .find(|c| c.juror == juror)
            .unwrap_or_else(|| env::panic_str("no commitment to reveal"));
        require!(case.panel.contains(&juror), "not on the panel for this case");
        require!(case.stage == Stage::Disputed, "no open dispute");
        let answers = [
            case.proposed,
            case.challenger_answer
                .unwrap_or_else(|| env::panic_str("no challenger answer")),
        ];
        require!(
            answers.contains(&outcome),
            "vote for the proposed answer or the challenger's answer"
        );
        let now = env::block_timestamp();
        require!(now >= case.commit_ends_at.0, "the commit phase is still open");
        require!(now <= case.panel_deadline.0, "the panel deadline passed");
        require!(!case.votes.iter().any(|v| v.juror == juror), "already revealed");
        require!(
            commit.commitment == commitment_of(&juror, outcome, &salt),
            "the vote does not match the commitment"
        );
        case.votes.push(Vote {
            juror: juror.clone(),
            outcome,
            reason: reason.clone(),
        });
        emit(
            "vote_revealed",
            json!({ "market": market, "market_id": market_id.0.to_string(), "juror": juror, "outcome": outcome, "reason": reason }),
        );

        let needed = case.panel.len() / 2 + 1;
        let winner = answers.into_iter().find(|answer| {
            case.votes
                .iter()
                .filter(|v| v.outcome == *answer && case.panel.contains(&v.juror))
                .count()
                >= needed
        });
        self.put_case(&market, market_id.0, case);
        if let Some(w) = winner {
            self.settle(&market, market_id.0, w, Ruling::Decided);
        }
    }

    // Anyone can call this. Settles an unchallenged proposal after its window. For a dispute whose jury did not decide
    // in time it calls for the one second jury, or, if that was the second jury or there is no time left for another
    // round before resolve_by, settles it with no decision.
    pub fn finalize(&mut self, market: AccountId, market_id: U64) {
        upgrade::require_gas(GAS_SETTLE_FLOOR, SETTLE_REASON);
        let case = self.case(&market, market_id.0);
        let now = env::block_timestamp();
        match case.stage {
            Stage::Proposed => {
                require!(now >= case.window_ends_at.0, "challenge window is still open");
                self.settle(&market, market_id.0, case.proposed, Ruling::Unchallenged);
            }
            Stage::Disputed => {
                require!(round_is_over(&case, now), "the panel still has time");
                self.close_round(&market, market_id.0, case);
            }
            Stage::Final => env::panic_str("already final"),
        }
    }

    // Anyone can call this once the market's resolve_by has passed. It settles whatever is settleable: an unchallenged
    // proposal whose window ended, a dispute whose jury ran out of time, or a final answer the market has not received.
    // A market nobody answered gets Void. A case that still has time is refused: the timing rules in propose and
    // close_round leave none at this point, and voiding the market under it would leave the case to settle an answer that
    // can no longer be applied. The market's own void_if_unresolved is only for an oracle that is gone.
    pub fn resolve_by_deadline(&mut self, market: AccountId, market_id: U64) {
        upgrade::require_gas(GAS_SETTLE_FLOOR, SETTLE_REASON);
        let info = self.market_info(&market, market_id.0);
        let now = env::block_timestamp();
        require!(now >= info.resolve_by.0, "the answer deadline has not passed");
        let Some(case) = self.get_case_of(&market, market_id.0) else {
            emit(
                "deadline_void",
                json!({ "market": market, "market_id": market_id.0.to_string() }),
            );
            return self.apply(&market, market_id.0, Outcome::Void);
        };
        match case.stage {
            Stage::Proposed if now >= case.window_ends_at.0 => {
                self.settle(&market, market_id.0, case.proposed, Ruling::Unchallenged)
            }
            Stage::Disputed if round_is_over(&case, now) => self.close_round(&market, market_id.0, case),
            Stage::Final if !case.applied => {
                self.apply(&market, market_id.0, case.final_outcome.unwrap_or(Outcome::Void))
            }
            Stage::Final => env::panic_str("already resolved"),
            _ => env::panic_str("the case still has time; finalize it when its round is over"),
        }
    }

    // Writing the answer to the market is a separate call and can fail. Anyone can retry it.
    pub fn retry_apply(&mut self, market: AccountId, market_id: U64) {
        let case = self.case(&market, market_id.0);
        require!(case.stage == Stage::Final && !case.applied, "nothing to apply");
        let outcome = case.final_outcome.unwrap_or_else(|| env::panic_str("no final outcome"));
        self.apply(&market, market_id.0, outcome);
    }

    // settle() sends unlock_case once and nothing waits for it, so if that call ever fails the jurors' seats stay
    // locked. Anyone can send it again. The council ignores a case it has already released, so repeating it is
    // harmless. It takes whatever gas the caller attaches, so a retry is never capped below what the unlock needs.
    pub fn retry_unlock(&mut self, market: AccountId, market_id: U64) -> Promise {
        upgrade::require_gas(
            GAS_RETRY_UNLOCK_FLOOR,
            "each jury's release gets an equal share of what is attached",
        );
        let case = self.case(&market, market_id.0);
        require!(
            case.stage == Stage::Final && case.challenger.is_some(),
            "no settled dispute to unlock"
        );
        // No static gas: each unlock takes an equal share of whatever the caller attached.
        self.unlock_juries(case.case_uid.0, case.round, case.delinquent, Gas::from_gas(0))
    }

    #[private]
    pub fn on_applied(
        &mut self,
        market: AccountId,
        market_id: U64,
        #[callback_result] result: Result<(), PromiseError>,
    ) {
        if result.is_ok() {
            // A market voided at its deadline with nobody having answered has no case to mark.
            if let Some(mut case) = self.get_case_of(&market, market_id.0) {
                case.applied = true;
                self.put_case(&market, market_id.0, case);
            }
            emit(
                "outcome_applied",
                json!({ "market": market, "market_id": market_id.0.to_string() }),
            );
        } else {
            emit(
                "apply_failed",
                json!({ "market": market, "market_id": market_id.0.to_string() }),
            );
        }
    }

    // Pays the caller's whole claimable balance into the caller's own Intents account, out of this contract's. The balance
    // is zeroed first and recorded as a pending payout, which the callback settles: confirmed, or given back if the verifier
    // refuses. A callback that never reports leaves the amount pending, still owed and never credited back.
    #[payable]
    pub fn withdraw_bond(&mut self) -> Promise {
        upgrade::require_gas(GAS_WITHDRAW_FLOOR, "a withdrawal sends the payout and then settles it");
        assert_one_yocto();
        let who = env::predecessor_account_id();
        let amount = self.claimable.get(&who).copied().unwrap_or(0);
        require!(amount > 0, "nothing to withdraw");
        self.claimable.remove(&who);
        self.claimable_total -= amount;
        self.last_payout_id += 1;
        let id = self.last_payout_id;
        self.payouts.insert(
            id,
            VersionedPayout::current(Payout {
                account: who.clone(),
                amount: U128(amount),
                at: U64(env::block_timestamp()),
            }),
        );
        self.pending_payouts_total += amount;
        emit(
            "bond_payout_requested",
            json!({ "account": who, "amount": amount.to_string(), "id": id.to_string() }),
        );
        // mt_transfer returns nothing, so an error here means the verifier's receipt failed (paused, locked, out of gas) and
        // nothing moved.
        ext_verifier::ext(self.verifier.clone())
            .with_attached_deposit(ONE_YOCTO)
            .with_static_gas(GAS_MT_TRANSFER)
            .mt_transfer(who.clone(), self.collateral_token_id.clone(), U128(amount), None, None)
            .then(
                Self::ext(env::current_account_id())
                    .with_static_gas(GAS_CALLBACK)
                    .on_bond_withdrawn(U64(id)),
            )
    }

    // Settles one pending payout. The account and amount come from the stored record, never from the call. An id with no
    // record, already settled or never issued, changes nothing.
    #[private]
    pub fn on_bond_withdrawn(&mut self, id: U64, #[callback_result] result: Result<(), PromiseError>) {
        let Some(payout) = self.get_payout(id.0) else {
            return;
        };
        let data = self.close_payout(id.0, payout, result.is_err());
        emit(
            if result.is_err() {
                "bond_payout_failed"
            } else {
                "bond_paid"
            },
            data,
        );
    }

    // Owner only, for a payout whose callback never came, so it stays in the pending total and still counts as owed. It
    // needs the reconcile wait after the payout, which leaves the callback time to land, and the owner checks the verifier's
    // events first: `paid` true means the transfer happened and the record is dropped, false means it did not and the amount
    // is claimable again. A callback that comes later finds no record and changes nothing.
    pub fn reconcile_bond_payout(&mut self, id: U64, paid: bool) {
        self.only_owner();
        let payout = self
            .get_payout(id.0)
            .unwrap_or_else(|| env::panic_str("no payout is pending with that id"));
        require!(
            env::block_timestamp() >= payout.at.0.saturating_add(self.reconcile_wait_ns),
            &format!(
                "wait {} minutes after the payout before reconciling",
                self.reconcile_wait_ns / (60 * NS_PER_SEC)
            )
        );
        let mut data = self.close_payout(id.0, payout, !paid);
        data["paid"] = json!(paid);
        emit("bond_payout_reconciled", data);
    }

    // Takes a payout out of the pending total and makes the amount claimable again when it failed. Both the payout callback
    // and reconcile_bond_payout end a payout here, so the two cannot disagree about the books. Returns the event data.
    fn close_payout(&mut self, id: u64, payout: Payout, failed: bool) -> near_sdk::serde_json::Value {
        self.payouts.remove(&id);
        let amount = payout.amount.0;
        self.pending_payouts_total -= amount;
        if failed {
            self.add_claimable(&payout.account, amount);
        }
        json!({ "account": payout.account, "amount": amount.to_string(), "id": id.to_string() })
    }

    // ---- views ----------------------------------------------------------------------------

    pub fn get_case(&self, market: AccountId, market_id: U64) -> Option<Case> {
        self.get_case_of(&market, market_id.0)
    }

    pub fn get_market_info(&self, market: AccountId, market_id: U64) -> Option<MarketInfo> {
        self.get_market_of(&market, market_id.0)
    }

    pub fn claimable_of(&self, account_id: AccountId) -> U128 {
        U128(self.claimable.get(&account_id).copied().unwrap_or(0))
    }

    // Everything this contract owes, in collateral units: the bonds in cases that are not final and everything waiting to be
    // withdrawn, plus payouts sent to the verifier and not yet confirmed. The keeper compares it with the verifier's
    // mt_balance_of for this account at the same finalized block. More there than here is surplus nobody is credited for.
    // Less is an incident, unless the shortfall is within pending_payouts_total: a payout that already left the verifier
    // is owed here until its callback runs.
    pub fn total_owed(&self) -> U128 {
        U128(self.bonds_held + self.claimable_total + self.pending_payouts_total)
    }

    // Looks at `limit` consecutive ids of one market account from `from_market_id` (at most MAX_LIST_CASES) and returns a
    // summary for each one that has a case. An id without a case is skipped, so a page can hold fewer than `limit` entries
    // and the caller advances by `limit`, not by the number returned.
    pub fn list_cases(&self, market: AccountId, from_market_id: U64, limit: u32) -> Vec<CaseSummary> {
        (from_market_id.0..=u64::MAX)
            .take(limit.min(MAX_LIST_CASES) as usize)
            .filter_map(|id| {
                self.get_case_of(&market, id).map(|case| CaseSummary {
                    market: market.clone(),
                    market_id: U64(id),
                    stage: case.stage,
                    proposed: case.proposed,
                    challenger_answer: case.challenger_answer,
                    round: case.round,
                    final_outcome: case.final_outcome,
                    applied: case.applied,
                    votes: case.votes.len() as u32,
                    window_ends_at: case.window_ends_at,
                    draw_by: case.draw_by,
                    panel_deadline: case.panel_deadline,
                })
            })
            .collect()
    }

    pub fn bond_totals(&self) -> BondTotals {
        BondTotals {
            bonds_held: U128(self.bonds_held),
            claimable: U128(self.claimable_total),
            pending_payouts: U128(self.pending_payouts_total),
            total: self.total_owed(),
        }
    }

    // Whether a wasm with this sha256 is staged here, for the members to check before they vote to deploy it.
    pub fn is_staged(&self, code_hash: Base58CryptoHash) -> bool {
        upgrade::is_staged(code_hash)
    }

    pub fn config(&self) -> near_sdk::serde_json::Value {
        json!({ "state_version": self.state_version, "upgrade_proven": self.upgrade_proven, "upgrade_in_flight": self.upgrade_in_flight,
                "owner": self.owner, "pending_owner": self.pending_owner, "markets": self.allowed_markets, "verifier": self.verifier,
                "collateral_token_id": self.collateral_token_id,
                "bond": self.bond.to_string(), "window_ns": self.window_ns.to_string(),
                "panel_deadline_ns": self.panel_deadline_ns.to_string(),
                "draw_window_ns": self.draw_window_ns.to_string(), "council": self.council,
                "jury_size": self.jury_size, "draw_delay_blocks": self.draw_delay_blocks.to_string(),
                "min_proposal_ns": self.min_proposal_ns.to_string(),
                "min_resolve_gap_ns": self.min_resolve_gap_ns().to_string(),
                "apply_buffer_ns": self.apply_buffer_ns.to_string(), "juror_share_bps": self.juror_share_bps,
                "no_decision_share_bps": self.no_decision_share_bps, "max_publishers": self.max_publishers, "operator": self.operator,
                "network": self.network, "publishers": self.publishers, "price_threshold": self.price_threshold,
                "no_decision_recipient": self.no_decision_recipient,
                "reconcile_wait_ns": self.reconcile_wait_ns.to_string() })
    }
}

// ---- private helpers ----------------------------------------------------------------------

impl OracleContract {
    // Anyone can answer a price market with a price that enough publishers signed for this market and its observation
    // time. The answer then goes through the same bond, challenge window and jury as any other, so a wrong price that
    // enough publishers signed can still be challenged. There is no staleness limit: each signature covers exactly the
    // observation time, so a publisher that was down at that moment can sign the price later.
    fn answer_price(&mut self, proposer: AccountId, market: &AccountId, id: u64, price: u128, signatures: &str) {
        let info = self.market_info(market, id);
        let rule = info.price_rule.unwrap_or_else(|| env::panic_str("not a price market"));
        require!(
            env::block_timestamp() >= rule.observation_time.0,
            "the observation time has not come"
        );
        let message = price_message(&env::current_account_id(), &self.network, market, id, &rule, price);
        let signers = self.verified_signers(&message, signatures);
        require!(
            signers.len() >= self.price_threshold as usize,
            "not enough valid publisher signatures"
        );
        let outcome = if (price >= rule.strike.0) == rule.above {
            Outcome::Yes
        } else {
            Outcome::No
        };
        self.propose(
            proposer,
            market,
            id,
            outcome,
            format!("signed price {price} by {} publishers", signers.len()),
            &signers,
        );
    }

    // The different publishers who signed `message`, in the order they were given, so the record can name them. Any entry
    // that is malformed, from a key that is not a publisher, repeated, or that does not verify refuses the whole submission.
    fn verified_signers(&self, message: &str, signatures: &str) -> Vec<PublicKey> {
        let mut seen: Vec<PublicKey> = vec![];
        for entry in signatures.split(',') {
            let (key, signature) = entry
                .rsplit_once('.')
                .unwrap_or_else(|| env::panic_str("a signature is <publisher key>.<hex>"));
            let key: PublicKey = key.parse().unwrap_or_else(|_| env::panic_str("bad publisher key"));
            require!(self.publishers.contains(&key), "not a publisher");
            require!(!seen.contains(&key), "a publisher signed twice");
            let raw: [u8; 32] = key.as_bytes()[1..]
                .try_into()
                .unwrap_or_else(|_| env::panic_str("publishers use ed25519 keys"));
            require!(
                env::ed25519_verify(&decode_signature(signature), message.as_bytes(), &raw),
                "a signature does not match"
            );
            seen.push(key);
        }
        seen
    }

    fn only_owner(&self) {
        require!(env::predecessor_account_id() == self.owner, "owner only");
    }

    // The least a market registered now must leave between close_at and resolve_by: time to propose, then the longest a
    // case can take, then room for apply() to land (see DEFAULT_APPLY_BUFFER_NS).
    fn min_resolve_gap_ns(&self) -> u64 {
        self.min_proposal_ns
            + case_span_ns(self.window_ns, self.draw_window_ns, self.panel_deadline_ns)
            + self.apply_buffer_ns
    }

    fn require_allowed(&self, market: &AccountId) {
        require!(
            self.allowed_markets.contains(market),
            "that market contract is not allowed"
        );
    }

    fn get_case_of(&self, market: &AccountId, id: u64) -> Option<Case> {
        self.cases
            .get(&(market.clone(), id))
            .map(|stored| stored.clone().into_inner())
    }

    fn put_case(&mut self, market: &AccountId, id: u64, case: Case) {
        self.cases.insert((market.clone(), id), VersionedCase::current(case));
    }

    fn get_market_of(&self, market: &AccountId, id: u64) -> Option<MarketInfo> {
        self.markets
            .get(&(market.clone(), id))
            .map(|stored| stored.clone().into_inner())
    }

    fn get_payout(&self, id: u64) -> Option<Payout> {
        self.payouts.get(&id).map(|stored| stored.clone().into_inner())
    }

    fn case(&self, market: &AccountId, id: u64) -> Case {
        self.get_case_of(market, id)
            .unwrap_or_else(|| env::panic_str("no case for that market"))
    }

    fn draw_delay_of(&self, case: &Case) -> u64 {
        case.draw_delay_blocks
            .map_or(self.old_case_draw_delay_blocks, |delay| delay.0)
    }

    fn market_info(&self, market: &AccountId, id: u64) -> MarketInfo {
        self.get_market_of(market, id)
            .unwrap_or_else(|| env::panic_str("market is not registered"))
    }

    fn add_claimable(&mut self, who: &AccountId, amount: u128) {
        let have = self.claimable.get(who).copied().unwrap_or(0);
        self.claimable.insert(who.clone(), have + amount);
        self.claimable_total += amount;
    }

    // `signers` are the publishers behind a price answer, empty for any other. They go into the event, which is where the
    // record shows who signed without anyone having to read the transaction.
    fn propose(
        &mut self,
        proposer: AccountId,
        market: &AccountId,
        id: u64,
        outcome: Outcome,
        evidence: String,
        signers: &[PublicKey],
    ) {
        let info = self.market_info(market, id);
        let now = env::block_timestamp();
        require!(now >= info.close_at.0, "the market has not closed yet");
        require!(evidence.len() <= MAX_EVIDENCE, "evidence link is too long");
        // A case must be able to finish, challenge and both juries included, with room left for apply() to land,
        // before the market's deadline answer is due.
        require!(
            now + info.case_span_ns() + info.apply_buffer_ns.0 <= info.resolve_by.0,
            "too late to propose, the market will be voided at its deadline"
        );
        require!(
            !self.cases.contains_key(&(market.clone(), id)),
            "an answer was already proposed"
        );
        let window_ends_at = U64(now + info.window_ns.0);
        self.last_case_uid += 1;
        self.put_case(
            market,
            id,
            Case {
                case_uid: U64(self.last_case_uid),
                stage: Stage::Proposed,
                proposer: proposer.clone(),
                proposed: outcome,
                bond: U128(self.bond),
                evidence: evidence.clone(),
                window_ends_at,
                challenger: None,
                challenger_answer: None,
                round: 0,
                jury_size: self.jury_size,
                draw_by: U64(0),
                draw_after_height: U64(0),
                commit_ends_at: U64(0),
                panel_deadline: U64(0),
                panel: vec![],
                first_panel: vec![],
                seated: false,
                commits: vec![],
                votes: vec![],
                final_outcome: None,
                applied: false,
                challenged_at: U64(0),
                juror_share_bps: self.juror_share_bps,
                no_decision_share_bps: self.no_decision_share_bps,
                delinquent: vec![],
                draw_delay_blocks: Some(U64(self.draw_delay_blocks)),
            },
        );
        emit(
            "proposed",
            json!({ "market": market, "market_id": id.to_string(), "proposer": proposer, "outcome": outcome,
                    "evidence": evidence, "bond": self.bond.to_string(),
                    "window_ends_at": window_ends_at.0.to_string(), "signers": signers }),
        );
    }

    fn challenge(&mut self, challenger: AccountId, market: &AccountId, id: u64, answer: Outcome) {
        let mut case = self.case(market, id);
        require!(case.stage == Stage::Proposed, "nothing to challenge");
        require!(
            env::block_timestamp() < case.window_ends_at.0,
            "the challenge window closed"
        );
        require!(challenger != case.proposer, "you cannot challenge your own answer");
        require!(
            answer != case.proposed,
            "a challenge must name a different answer than the proposal"
        );
        let draw_window_ns = self.market_info(market, id).draw_window_ns.0;
        let now = env::block_timestamp();
        case.stage = Stage::Disputed;
        case.challenger = Some(challenger.clone());
        case.challenger_answer = Some(answer);
        if case.jury_size == 0 {
            case.jury_size = self.jury_size;
        }
        case.challenged_at = U64(now);
        case.draw_by = U64(now + draw_window_ns);
        case.draw_after_height = U64(env::block_height() + self.draw_delay_of(&case));
        let draw_by = case.draw_by.0;
        let bond = case.bond.0;
        self.put_case(market, id, case);
        emit(
            "challenged",
            json!({ "market": market, "market_id": id.to_string(), "challenger": challenger, "answer": answer,
                    "bond": bond.to_string(), "draw_by": draw_by.to_string() }),
        );
    }

    // A round ended without a majority. The first one is followed by a larger jury of other accounts, unless there is
    // no longer time for it to finish before resolve_by. Otherwise nobody decided: a price market keeps the price the
    // publishers signed, and an event market is Void.
    fn close_round(&mut self, market: &AccountId, id: u64, mut case: Case) {
        let info = self.market_info(market, id);
        let now = env::block_timestamp();
        let round_ns = info.draw_window_ns.0 + info.panel_deadline_ns.0;
        // The first draw found too few free seats, possibly because other cases hold them. Wait for the seats instead of ruling,
        // for as long as a jury seated at the end of the wait still has time to decide. A case that already seated a jury
        // does not wait: its seats would only stay busy longer.
        if case.round == 0
            && case.panel.is_empty()
            && !case.seated
            && now + info.draw_window_ns.0 <= case.challenged_at.0 + MAX_DRAW_QUEUE_WINDOWS * info.draw_window_ns.0
            && now + round_ns + info.apply_buffer_ns.0 <= info.resolve_by.0
        {
            case.draw_by = U64(now + info.draw_window_ns.0);
            case.draw_after_height = U64(env::block_height());
            emit(
                "draw_extended",
                json!({ "market": market, "market_id": id.to_string(), "round": case.round,
                        "draw_by": case.draw_by.0.to_string() }),
            );
            self.put_case(market, id, case);
            return;
        }
        if case.round == 0 && now + round_ns + info.apply_buffer_ns.0 <= info.resolve_by.0 {
            case.round = 1;
            case.jury_size = (2 * case.jury_size + 1).min(MAX_PANEL as u32);
            case.draw_by = U64(now + info.draw_window_ns.0);
            case.draw_after_height = U64(env::block_height() + self.draw_delay_of(&case));
            case.commit_ends_at = U64(0);
            case.panel_deadline = U64(0);
            case.first_panel = std::mem::take(&mut case.panel);
            emit(
                "escalated",
                json!({ "market": market, "market_id": id.to_string(), "jury_size": case.jury_size,
                        "draw_by": case.draw_by.0.to_string() }),
            );
            self.put_case(market, id, case);
        } else {
            let outcome = if info.price_rule.is_some() {
                case.proposed
            } else {
                Outcome::Void
            };
            let ruling = if case.seated {
                Ruling::NoDecision
            } else {
                Ruling::NoJury
            };
            self.settle(market, id, outcome, ruling);
        }
    }

    // Fix the outcome, hand out bonds, then tell the market. State changes first, call last.
    fn settle(&mut self, market: &AccountId, id: u64, outcome: Outcome, ruling: Ruling) {
        let mut case = self.case(market, id);
        case.stage = Stage::Final;
        case.final_outcome = Some(outcome);
        let disputed = ruling != Ruling::Unchallenged;
        if disputed {
            case.delinquent = delinquent_jurors(&case, env::block_timestamp());
        }
        let proposer = case.proposer.clone();
        let challenger = case.challenger.clone();
        let proposed = case.proposed;
        // Jurors who revealed, and those of them who sat with the final outcome. A majority of a jury is what decides a
        // dispute, so anything short of that, a timeout above all, is a dispute nobody won.
        let revealed: Vec<AccountId> = case.votes.iter().map(|v| v.juror.clone()).collect();
        let majority: Vec<AccountId> = case
            .votes
            .iter()
            .filter(|v| v.outcome == outcome)
            .map(|v| v.juror.clone())
            .collect();
        let delinquent = case.delinquent.clone();
        let round = case.round;
        let case_uid = case.case_uid.0;
        let bond = case.bond.0;
        let juror_share_bps = u128::from(case.juror_share_bps);
        let no_decision_share_bps = u128::from(case.no_decision_share_bps);
        self.put_case(market, id, case);
        // The bonds that were put into this case are all handed out below, to the accounts that earned them.
        self.bonds_held -= if challenger.is_some() { 2 * bond } else { bond };

        let mut juror_pay = 0;
        let mut paid: Vec<AccountId> = vec![];
        match (challenger, ruling) {
            (Some(c), Ruling::Decided) => {
                // The loser's bond: a quarter shared by the majority jurors, the rest to the winner with the winner's own
                // bond. The division rounds down and the winner keeps the remainder, so the two bonds are paid out exactly.
                let winner = if outcome == proposed { proposer } else { c };
                let pool = bond * juror_share_bps / 10_000;
                juror_pay = pool / majority.len() as u128;
                for juror in &majority {
                    self.add_claimable(juror, juror_pay);
                }
                self.add_claimable(&winner, 2 * bond - juror_pay * majority.len() as u128);
                paid = majority;
            }
            (Some(_), Ruling::NoDecision) => {
                // Nobody won, so the proposer gets their own bond back. The challenger put a case in front of two juries
                // and neither found for them: half of their bond goes to the jurors who revealed, the rest to the
                // proposer. With no juror having revealed, the no-decision recipient holds that half, so a pair of accounts
                // that propose and challenge each other loses it whatever the juries do.
                let pool = bond * no_decision_share_bps / 10_000;
                if revealed.is_empty() {
                    let recipient = self.no_decision_recipient.clone();
                    self.add_claimable(&recipient, pool);
                    self.add_claimable(&proposer, 2 * bond - pool);
                } else {
                    juror_pay = pool / revealed.len() as u128;
                    for juror in &revealed {
                        self.add_claimable(juror, juror_pay);
                    }
                    self.add_claimable(&proposer, 2 * bond - juror_pay * revealed.len() as u128);
                }
                paid = revealed;
            }
            (Some(c), Ruling::NoJury) => {
                // No jury could be seated, so nobody ruled on the challenge and neither side is at fault. Each gets their
                // own bond back in full.
                self.add_claimable(&proposer, bond);
                self.add_claimable(&c, bond);
            }
            _ => self.add_claimable(&proposer, bond),
        }
        emit(
            "final",
            json!({ "market": market, "market_id": id.to_string(), "outcome": outcome, "ruling": ruling.word(),
                    "juror_pay_each": juror_pay.to_string(), "paid_jurors": paid, "delinquent": delinquent }),
        );
        self.apply(market, id, outcome);
        // Lets the juries unstake. Nothing waits on it: if it fails, retry_unlock sends it again.
        if disputed {
            let _ = self.unlock_juries(case_uid, round, delinquent, GAS_UNLOCK);
        }
    }

    fn apply(&self, market: &AccountId, id: u64, outcome: Outcome) {
        let _ = ext_market::ext(market.clone())
            .with_static_gas(GAS_APPLY)
            .set_outcome(U64(id), outcome)
            .then(
                Self::ext(env::current_account_id())
                    .with_static_gas(GAS_CALLBACK)
                    .on_applied(market.clone(), U64(id)),
            );
    }

    // Releases the seats of the case's first jury and, once there was a second round, of its second. Both calls carry
    // the same list of jurors who never voted: the council only looks at the seats of the jury it is releasing. They run
    // one after the other, because retry_unlock returns this promise and the runtime refuses to return a joint one.
    fn unlock_juries(&self, case_uid: u64, round: u8, delinquent: Vec<AccountId>, gas: Gas) -> Promise {
        let unlock = |round: u8| {
            ext_council::ext(self.council.clone())
                .with_static_gas(gas)
                .unlock_case(council_key(case_uid, round), delinquent.clone())
        };
        if round == 0 {
            unlock(0)
        } else {
            unlock(0).then(unlock(1))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ed25519_dalek::{Signer, SigningKey};
    use near_sdk::test_utils::VMContextBuilder;
    use near_sdk::testing_env;

    const OWNER: &str = "owner.near";
    const OPERATOR: &str = "ops.near";
    const MARKET: &str = "market.near";
    const VERIFIER: &str = "intents.near";
    const COLLATERAL: &str = "nep141:usdc.near";
    const COUNCIL: &str = "council.near";
    const RECIPIENT: &str = "biz.near";
    const NETWORK: &str = "testnet";
    // The settings every test oracle starts with.
    const APPLY_BUFFER_NS: u64 = DEFAULT_APPLY_BUFFER_NS;
    const JUROR_SHARE_BPS: u128 = DEFAULT_JUROR_SHARE_BPS as u128;
    const NO_DECISION_JUROR_SHARE_BPS: u128 = DEFAULT_NO_DECISION_JUROR_SHARE_BPS as u128;

    fn acct(name: &str) -> AccountId {
        name.parse().unwrap()
    }

    impl OracleContract {
        // Writes a market of the test market account straight into storage.
        fn put_market(&mut self, id: u64, info: MarketInfo) {
            self.markets
                .insert((acct(MARKET), id), VersionedMarketInfo::current(info));
        }
    }

    // Every call carries the one yocto the juror methods need.
    fn act_as(who: &str, now_ns: u64) {
        act_at_height(who, now_ns, 0);
    }

    fn act_at_height(who: &str, now_ns: u64, height: u64) {
        testing_env!(VMContextBuilder::new()
            .predecessor_account_id(acct(who))
            .block_timestamp(now_ns)
            .block_height(height)
            .attached_deposit(NearToken::from_yoctonear(1))
            .build());
    }

    fn act_unpaid(who: &str, now_ns: u64) {
        testing_env!(VMContextBuilder::new()
            .predecessor_account_id(acct(who))
            .block_timestamp(now_ns)
            .build());
    }

    // What the verifier hands over after `sender` moved `amount` of the collateral out of their own Intents balance. The caller
    // acts as the verifier first.
    fn deliver(o: &mut OracleContract, sender: &str, amount: u128, msg: &str) -> Vec<U128> {
        o.mt_on_transfer(
            acct(sender),
            vec![acct(sender)],
            vec![COLLATERAL.to_string()],
            vec![U128(amount)],
            msg.to_string(),
        )
    }

    fn fresh_oracle() -> OracleContract {
        oracle_with_bond(MIN_BOND)
    }

    fn oracle_with_bond(bond: u128) -> OracleContract {
        oracle_with(bond, 2)
    }

    const SECOND: u64 = 1_000_000_000;
    // The oracle below is deployed with the shortest window the floor allows for the window, the draw window and the
    // proposal time, and twice that for the panel deadline.
    const WINDOW_MS: u64 = MIN_WINDOW_MS;
    const PANEL_MS: u64 = 2 * MIN_WINDOW_MS;
    const WINDOW: u64 = WINDOW_MS * NS_PER_MS;
    const DRAW_WINDOW: u64 = WINDOW;
    const PANEL: u64 = PANEL_MS * NS_PER_MS;
    const PROPOSAL_TIME: u64 = WINDOW;
    const TEST_JURY_SIZE: u32 = MIN_JURY_SIZE;
    const LARGER_JURY_SIZE: u32 = MIN_JURY_SIZE + 2;
    const TEST_DRAW_DELAY_BLOCKS: u64 = 2;
    const FIRST_JURORS: usize = TEST_JURY_SIZE as usize;
    const SECOND_JURORS: usize = 2 * FIRST_JURORS + 1;
    // The reveals that carry a jury of the second size.
    const SECOND_MAJORITY: usize = SECOND_JURORS / 2 + 1;
    const FIRST_MAJORITY: usize = FIRST_JURORS / 2 + 1;

    fn oracle_with(bond: u128, price_threshold: u32) -> OracleContract {
        oracle_on(COLLATERAL, bond, price_threshold)
    }

    fn oracle_on(collateral_token_id: &str, bond: u128, price_threshold: u32) -> OracleContract {
        near_sdk::mock::with_mocked_blockchain(|b| {
            let _ = b.take_storage();
        });
        act_as(OWNER, 0);
        new_oracle(
            collateral_token_id,
            bond,
            [WINDOW_MS, PANEL_MS, WINDOW_MS, WINDOW_MS],
            TEST_JURY_SIZE,
            price_threshold,
        )
    }

    // The windows are the challenge window, the panel deadline, the draw window and the minimum proposal time, in ms.
    fn new_oracle(
        collateral_token_id: &str,
        bond: u128,
        windows_ms: [u64; 4],
        jury_size: u32,
        price_threshold: u32,
    ) -> OracleContract {
        let [window, panel, draw, min_proposal] = windows_ms;
        OracleContract::new(
            acct(OWNER),
            acct(MARKET),
            acct(VERIFIER),
            collateral_token_id.to_string(),
            U128(bond),
            U64(window),
            U64(panel),
            U64(draw),
            acct(COUNCIL),
            jury_size,
            U64(TEST_DRAW_DELAY_BLOCKS),
            U64(min_proposal),
            acct(OPERATOR),
            NETWORK.to_string(),
            price_threshold,
            acct(RECIPIENT),
        )
    }

    // A market closed at 0 with the oracle's test windows.
    fn base_info() -> MarketInfo {
        MarketInfo {
            close_at: U64(0),
            resolve_by: U64(0),
            rule_hash: "hash".to_string(),
            price_rule: None,
            window_ns: U64(WINDOW),
            panel_deadline_ns: U64(PANEL),
            draw_window_ns: U64(DRAW_WINDOW),
            apply_buffer_ns: U64(DEFAULT_APPLY_BUFFER_NS),
        }
    }

    // The market is written straight into storage: register_market would refuse one this tight, and propose()
    // still has to hold for a market that was fine when created and is proposed on late.
    fn oracle_with_resolve_by(resolve_by_ns: u64) -> OracleContract {
        let mut o = fresh_oracle();
        o.put_market(
            0,
            MarketInfo {
                resolve_by: U64(resolve_by_ns),
                ..base_info()
            },
        );
        o
    }

    // The window and two rounds of a draw window and a panel deadline: what a case can take from its proposal.
    const CASE_SPAN: u64 = WINDOW + 2 * (DRAW_WINDOW + PANEL);
    const MIN_GAP: u64 = PROPOSAL_TIME + CASE_SPAN + APPLY_BUFFER_NS;

    // ---- what a settled dispute pays, and who is delinquent -------------------------------------------

    const BOND: u128 = MIN_BOND;
    const DEADLINE: u64 = 120 * SECOND;
    const JURORS: [&str; 3] = ["j0.near", "j1.near", "j2.near"];

    fn other_answer(proposed: Outcome) -> Outcome {
        if proposed == Outcome::Yes {
            Outcome::No
        } else {
            Outcome::Yes
        }
    }

    // A challenged case, proposed by carol and challenged by dave, with a jury of three. `commits` and `votes` are
    // who committed and who revealed what. Dave's answer is the other one of Yes and No unless a test names it.
    fn disputed_case(o: &mut OracleContract, proposed: Outcome, commits: &[&str], votes: &[(&str, Outcome)]) {
        disputed_case_answering(o, proposed, other_answer(proposed), commits, votes);
    }

    fn disputed_case_answering(
        o: &mut OracleContract,
        proposed: Outcome,
        answer: Outcome,
        commits: &[&str],
        votes: &[(&str, Outcome)],
    ) {
        // Both bonds are in the case, as they would be had it been proposed and challenged through the hook.
        o.bonds_held += 2 * o.bond;
        o.put_case(
            &acct(MARKET),
            0,
            Case {
                case_uid: U64(1),
                stage: Stage::Disputed,
                proposer: acct("carol.near"),
                proposed,
                bond: U128(o.bond),
                evidence: String::new(),
                window_ends_at: U64(0),
                challenger: Some(acct("dave.near")),
                challenger_answer: Some(answer),
                round: 0,
                jury_size: 3,
                draw_by: U64(DRAW_WINDOW),
                draw_after_height: U64(0),
                commit_ends_at: U64(DEADLINE / 2),
                panel_deadline: U64(DEADLINE),
                panel: JURORS.iter().map(|j| acct(j)).collect(),
                first_panel: vec![],
                seated: true,
                commits: commits
                    .iter()
                    .map(|j| Commit {
                        juror: acct(j),
                        commitment: "c".into(),
                    })
                    .collect(),
                votes: votes
                    .iter()
                    .map(|(j, outcome)| Vote {
                        juror: acct(j),
                        outcome: *outcome,
                        reason: "r".into(),
                    })
                    .collect(),
                final_outcome: None,
                applied: false,
                challenged_at: U64(0),
                juror_share_bps: DEFAULT_JUROR_SHARE_BPS,
                no_decision_share_bps: DEFAULT_NO_DECISION_JUROR_SHARE_BPS,
                delinquent: vec![],
                draw_delay_blocks: Some(U64(TEST_DRAW_DELAY_BLOCKS)),
            },
        );
    }

    // Like disputed_case, with a jury of any size.
    fn put_case_with_panel(
        o: &mut OracleContract,
        proposed: Outcome,
        panel: &[String],
        commits: &[&str],
        votes: &[(&str, Outcome)],
    ) {
        disputed_case(o, proposed, commits, votes);
        let mut case = o.case(&acct(MARKET), 0);
        case.panel = panel.iter().map(|j| acct(j)).collect();
        case.jury_size = panel.len() as u32;
        o.put_case(&acct(MARKET), 0, case);
    }

    fn owed(o: &OracleContract, who: &str) -> u128 {
        o.claimable_of(acct(who)).0
    }

    // The arguments of each call the last transaction sent to `method`, in the order they were sent.
    fn calls_to(method: &str) -> Vec<near_sdk::serde_json::Value> {
        near_sdk::test_utils::get_created_receipts()
            .iter()
            .flat_map(|r| r.actions.iter())
            .filter_map(|a| match a {
                near_sdk::mock::MockAction::FunctionCallWeight { method_name, args, .. }
                    if method_name == method.as_bytes() =>
                {
                    Some(near_sdk::serde_json::from_slice(args).unwrap())
                }
                _ => None,
            })
            .collect()
    }

    fn unlock_call() -> Option<near_sdk::serde_json::Value> {
        calls_to("unlock_case").into_iter().next()
    }

    fn names(count: usize, prefix: &str) -> Vec<String> {
        (0..count).map(|i| format!("{prefix}{i}.near")).collect()
    }

    // ---- a case run through the real calls ---------------------------------------------------------------

    // Far enough away that no deadline of the market comes into play.
    const MARKET_DEADLINE: u64 = 1_000_000 * SECOND;
    const CHALLENGED_AT: u64 = 2 * SECOND;
    const DRAW_BY: u64 = CHALLENGED_AT + DRAW_WINDOW;
    // The first moment a finalize no longer waits for seats: the draw queue runs for MAX_DRAW_QUEUE_WINDOWS windows.
    const QUEUE_OVER: u64 = CHALLENGED_AT + (MAX_DRAW_QUEUE_WINDOWS - 1) * DRAW_WINDOW + 1;

    // Market 0 closed at 0. Carol proposes `proposed` a second later and Dave challenges naming `answer` the second after.
    fn challenged(proposed: Outcome, answer: Outcome) -> OracleContract {
        let mut o = oracle_with_bond(BOND);
        o.put_market(
            0,
            MarketInfo {
                resolve_by: U64(MARKET_DEADLINE),
                ..base_info()
            },
        );
        act_as(VERIFIER, SECOND);
        deliver(
            &mut o,
            "carol.near",
            BOND,
            &format!("propose:market.near:0:{}:https://x", proposed.word()),
        );
        act_as(VERIFIER, CHALLENGED_AT);
        deliver(
            &mut o,
            "dave.near",
            BOND,
            &format!("challenge:market.near:0:{}", answer.word()),
        );
        o
    }

    // The council answers the draw at `at` with these jurors.
    fn seat(o: &mut OracleContract, at: u64, jurors: &[String]) {
        act_as(COUNCIL, at);
        let round = o.case(&acct(MARKET), 0).round;
        o.on_drawn(
            acct(MARKET),
            U64(0),
            round,
            Ok(jurors.iter().map(|j| acct(j)).collect()),
        );
    }

    fn commit(o: &mut OracleContract, juror: &str, at: u64, outcome: Outcome, salt: &str) {
        act_as(juror, at);
        o.commit_vote(acct(MARKET), U64(0), commitment_of(&acct(juror), outcome, salt));
    }

    fn reveal(o: &mut OracleContract, juror: &str, at: u64, outcome: Outcome, salt: &str) {
        act_as(juror, at);
        o.reveal_vote(acct(MARKET), U64(0), outcome, salt.into(), "because".into());
    }

    // A reveal at the moment the current round's reveal phase opens.
    fn reveal_when_open(o: &mut OracleContract, juror: &str, outcome: Outcome, salt: &str) {
        let opens = o.case(&acct(MARKET), 0).commit_ends_at.0;
        reveal(o, juror, opens, outcome, salt);
    }

    // Round 0 with `jurors` seated at the last moment a draw is allowed, none of whom do anything. Returns when the
    // round is over.
    fn first_round_that_does_nothing(o: &mut OracleContract, jurors: &[String]) -> u64 {
        seat(o, DRAW_BY, jurors);
        o.case(&acct(MARKET), 0).panel_deadline.0 + 1
    }

    // ---- attacks: randomized ---------------------------------------------------------------------------

    use proptest::prelude::*;

    const PROPTEST_MAX_BOND: u128 = 10 * MIN_BOND;

    proptest! {
        #![proptest_config(ProptestConfig::with_cases(400))]

        // However the jury behaves, a settled dispute pays out exactly the two bonds that were put in: not a unit more
        // (money created), not a unit less (money stuck). Only jurors who revealed are paid, and in a decided dispute
        // only those who sat with the outcome. A dispute nobody decided pays the proposer, the jurors who revealed and,
        // if none did, the owner, and never the challenger. The delinquent are only jurors who did not vote.
        #[test]
        fn a_settled_dispute_pays_out_exactly_the_bonds_and_only_to_those_who_earned_it(
            bond in MIN_BOND..PROPTEST_MAX_BOND,
            jury_size in prop::sample::select(vec![5usize, 7, 11, 21]),
            behaviour in prop::collection::vec((0u8..3, any::<bool>()), 21),
            proposed in 0u8..3,
            after_deadline in any::<bool>(),
        ) {
            let proposed = [Outcome::Yes, Outcome::No, Outcome::Void][proposed as usize];
            let answer = other_answer(proposed);
            let mut o = oracle_with_bond(bond);
            let jurors = names(jury_size, "j");
            // Each juror: did not commit, committed only, or committed and revealed; and which of the two answers.
            let mut commits = vec![];
            let mut votes = vec![];
            for (i, (kind, for_challenger)) in behaviour.iter().take(jury_size).enumerate() {
                if *kind >= 1 { commits.push(jurors[i].as_str()); }
                if *kind == 2 { votes.push((jurors[i].as_str(), if *for_challenger { answer } else { proposed })); }
            }
            let needed = jury_size / 2 + 1;
            let majority = [proposed, answer].into_iter().find(|a| votes.iter().filter(|(_, v)| v == a).count() >= needed);
            // The case settles on a majority the moment it forms, or with no decision once the deadline has passed.
            let (outcome, ruling, now) = match (majority, after_deadline) {
                (Some(m), _) => (m, Ruling::Decided, DEADLINE - 1),
                (None, true) => (Outcome::Void, Ruling::NoDecision, DEADLINE + 1),
                (None, false) => return Ok(()),
            };
            put_case_with_panel(&mut o, proposed, &jurors, &commits, &votes);
            act_as("anyone.near", now);
            o.settle(&acct(MARKET), 0, outcome, ruling);

            let paid_jurors: u128 = jurors.iter().map(|j| owed(&o, j)).sum();
            let (carol, dave, recipient) = (owed(&o, "carol.near"), owed(&o, "dave.near"), owed(&o, RECIPIENT));
            prop_assert_eq!(paid_jurors + carol + dave + recipient, 2 * bond, "the two bonds are paid out exactly");
            prop_assert_eq!((o.total_owed().0, o.bonds_held), (2 * bond, 0), "settling moves the bonds into claimable and owes nothing new");
            prop_assert_eq!(owed(&o, OWNER), 0, "the owner is never paid");

            let case = o.case(&acct(MARKET), 0);
            let revealed = |j: &String| votes.iter().any(|(v, _)| v == j);
            for j in &jurors {
                let sat_with_outcome = votes.iter().any(|(v, out)| v == j && *out == outcome);
                let may_be_paid = match ruling {
                    Ruling::Decided => sat_with_outcome,
                    _ => revealed(j),
                };
                if !may_be_paid {
                    prop_assert_eq!(owed(&o, j), 0, "{} was paid without earning it", j);
                }
            }
            let pool = match ruling {
                Ruling::Decided => bond * JUROR_SHARE_BPS / 10_000,
                _ => bond * NO_DECISION_JUROR_SHARE_BPS / 10_000,
            };
            // The two parties of a case that went to a jury get back less than they put in by the jurors' share, up
            // to a unit of rounding for each juror.
            prop_assert!(2 * bond - (carol + dave) + jury_size as u128 >= pool, "the parties kept {} of the jurors' {}", carol + dave, pool);
            if ruling == Ruling::NoDecision {
                prop_assert_eq!(dave, 0, "the challenger's bond is not returned when nobody decided");
                prop_assert!(carol >= bond, "the proposer's own bond comes back");
                prop_assert_eq!(recipient, if votes.is_empty() { pool } else { 0 }, "the recipient holds the jurors' half only when none revealed");
            }
            // Delinquent means did not vote: never a juror who revealed.
            for d in &case.delinquent {
                prop_assert!(!votes.iter().any(|(v, _)| *v == d.as_str()), "{} revealed and is delinquent", d);
                prop_assert!(jurors.iter().any(|j| j == d.as_str()), "a delinquent juror is on the panel");
            }
            // Everyone who never committed is delinquent, however the case ended.
            for j in &jurors {
                if !commits.contains(&j.as_str()) {
                    prop_assert!(case.delinquent.iter().any(|d| d.as_str() == j), "{} never committed and is not delinquent", j);
                }
            }
        }

        // With any odd jury and every juror voting for one of the two answers, the case settles: some answer always has
        // a majority, so a full binary ballot cannot stall.
        #[test]
        fn a_full_binary_ballot_always_settles(
            jury_size in prop::sample::select(vec![5usize, 7, 11, 21]),
            ballot in prop::collection::vec(any::<bool>(), 21),
        ) {
            let mut o = challenged(Outcome::Yes, Outcome::No);
            let jurors = names(jury_size, "j");
            o.put_case(&acct(MARKET), 0, Case { jury_size: jury_size as u32, ..o.case(&acct(MARKET), 0) });
            seat(&mut o, DRAW_BY, &jurors);
            let commit_ends = o.case(&acct(MARKET), 0).commit_ends_at.0;
            let vote = |i: usize| if ballot[i] { Outcome::No } else { Outcome::Yes };
            for (i, j) in jurors.iter().enumerate() {
                commit(&mut o, j, DRAW_BY + SECOND, vote(i), "a-long-random-salt");
            }
            for (i, j) in jurors.iter().enumerate() {
                if o.case(&acct(MARKET), 0).stage == Stage::Final {
                    break;
                }
                reveal(&mut o, j, commit_ends, vote(i), "a-long-random-salt");
            }
            let case = o.case(&acct(MARKET), 0);
            prop_assert_eq!(case.stage, Stage::Final, "a full ballot left the case open");
            let for_no = (0..jury_size).filter(|i| ballot[*i]).count();
            let expected = if for_no * 2 > jury_size { Outcome::No } else { Outcome::Yes };
            prop_assert_eq!(case.final_outcome, Some(expected));
        }

        // Two accounts that propose and challenge each other to stall a case end down by at least the jurors' share,
        // whatever the jurors, in either round, do. Both rounds' jurors are other accounts than the pair.
        #[test]
        fn a_self_challenging_pair_ends_down_by_at_least_the_juror_share_whatever_the_jury_does(
            bond in MIN_BOND..PROPTEST_MAX_BOND,
            first_size in prop::sample::select(vec![5usize, 7, 11]),
            first in prop::collection::vec((0u8..3, any::<bool>()), 11),
            second in prop::collection::vec((0u8..3, any::<bool>()), 21),
            two_rounds in any::<bool>(),
            decided in any::<bool>(),
        ) {
            let (proposed, answer) = (Outcome::Yes, Outcome::No);
            let mut o = oracle_with_bond(bond);
            let first_jurors = names(first_size, "f");
            let second_size = (2 * first_size + 1).min(MAX_PANEL);
            let second_jurors = names(second_size, "s");
            let mut commits: Vec<String> = vec![];
            let mut votes: Vec<(String, Outcome)> = vec![];
            for (i, (kind, for_challenger)) in first.iter().take(first_size).enumerate() {
                if *kind >= 1 { commits.push(first_jurors[i].clone()); }
                if *kind == 2 { votes.push((first_jurors[i].clone(), if *for_challenger { answer } else { proposed })); }
            }
            if two_rounds {
                for (i, (kind, for_challenger)) in second.iter().take(second_size).enumerate() {
                    if *kind >= 1 { commits.push(second_jurors[i].clone()); }
                    if *kind == 2 { votes.push((second_jurors[i].clone(), if *for_challenger { answer } else { proposed })); }
                }
            }
            let commit_refs: Vec<&str> = commits.iter().map(String::as_str).collect();
            let vote_refs: Vec<(&str, Outcome)> = votes.iter().map(|(j, v)| (j.as_str(), *v)).collect();
            let panel = if two_rounds { &second_jurors } else { &first_jurors };
            put_case_with_panel(&mut o, proposed, panel, &commit_refs, &vote_refs);
            if two_rounds {
                let mut case = o.case(&acct(MARKET), 0);
                case.round = 1;
                case.first_panel = first_jurors.iter().map(|j| acct(j)).collect();
                o.put_case(&acct(MARKET), 0, case);
            }
            // A decided case needs a vote for the outcome. Give the outcome to whoever the votes favour, or to the
            // proposer when none were cast.
            let for_proposed = votes.iter().filter(|(_, v)| *v == proposed).count();
            let outcome = if for_proposed * 2 >= votes.len() { proposed } else { answer };
            let decided = decided && votes.iter().any(|(_, v)| *v == outcome);
            act_as("anyone.near", DEADLINE + 1);
            if decided {
                o.settle(&acct(MARKET), 0, outcome, Ruling::Decided);
            } else {
                o.settle(&acct(MARKET), 0, Outcome::Void, Ruling::NoDecision);
            }
            let pair = owed(&o, "carol.near") + owed(&o, "dave.near");
            let share = if decided { bond * JUROR_SHARE_BPS / 10_000 } else { bond * NO_DECISION_JUROR_SHARE_BPS / 10_000 };
            let jurors_paid = first_size + if two_rounds { second_size } else { 0 };
            prop_assert!(2 * bond - pair + jurors_paid as u128 >= share, "the pair kept {} of {}, the jurors' share is {}", pair, 2 * bond, share);
        }
    }

    #[test]
    fn the_majority_jurors_share_a_quarter_of_the_losing_bond_and_the_winner_keeps_the_rest() {
        let mut o = oracle_with_bond(BOND);
        // Carol proposed Yes. j2 reveals Yes first, then j0 and j1 reveal No and settle it. Dave wins; the two No
        // jurors are paid and the Yes juror, who revealed but sat with the minority, is not.
        disputed_case(
            &mut o,
            Outcome::Yes,
            &JURORS,
            &[
                (JURORS[2], Outcome::Yes),
                (JURORS[0], Outcome::No),
                (JURORS[1], Outcome::No),
            ],
        );
        act_as(JURORS[1], 100);
        o.settle(&acct(MARKET), 0, Outcome::No, Ruling::Decided);
        assert_eq!(owed(&o, "j0.near"), 625_000);
        assert_eq!(owed(&o, "j1.near"), 625_000);
        assert_eq!(owed(&o, "j2.near"), 0, "revealed with the minority, so no pay");
        assert!(o.case(&acct(MARKET), 0).delinquent.is_empty(), "everyone voted");
        assert_eq!(owed(&o, "dave.near"), 2 * BOND - 1_250_000);
        assert_eq!(owed(&o, "carol.near"), 0);
    }

    #[test]
    fn when_the_proposer_wins_the_challengers_bond_is_the_one_split() {
        let mut o = oracle_with_bond(BOND);
        disputed_case(
            &mut o,
            Outcome::Yes,
            &JURORS,
            &[(JURORS[0], Outcome::Yes), (JURORS[1], Outcome::Yes)],
        );
        act_as(JURORS[1], 100);
        o.settle(&acct(MARKET), 0, Outcome::Yes, Ruling::Decided);
        assert_eq!((owed(&o, "j0.near"), owed(&o, "j1.near")), (625_000, 625_000));
        assert_eq!(owed(&o, "carol.near"), 2 * BOND - 1_250_000);
        assert_eq!(owed(&o, "dave.near"), 0);
    }

    #[test]
    fn rounding_stays_with_the_winner_so_both_bonds_are_paid_out_exactly() {
        let bond = MIN_BOND + 3;
        let mut o = oracle_with_bond(bond);
        disputed_case(&mut o, Outcome::Yes, &JURORS, &JURORS.map(|j| (j, Outcome::No)));
        act_as(JURORS[2], 100);
        o.settle(&acct(MARKET), 0, Outcome::No, Ruling::Decided);
        // A quarter rounds down to 1,250,000, three ways is 416,666 each and 2 over, which the winner keeps.
        assert_eq!(
            (owed(&o, "j0.near"), owed(&o, "j1.near"), owed(&o, "j2.near")),
            (416_666, 416_666, 416_666)
        );
        let paid: u128 = ["j0.near", "j1.near", "j2.near", "carol.near", "dave.near"]
            .iter()
            .map(|a| owed(&o, a))
            .sum();
        assert_eq!(paid, 2 * bond, "nothing created or lost");
    }

    #[test]
    fn a_jury_that_votes_void_makes_the_proposer_of_another_answer_the_loser() {
        let mut o = oracle_with_bond(BOND);
        disputed_case_answering(
            &mut o,
            Outcome::Yes,
            Outcome::Void,
            &JURORS,
            &[(JURORS[0], Outcome::Void), (JURORS[1], Outcome::Void)],
        );
        act_as(JURORS[1], 100);
        o.settle(&acct(MARKET), 0, Outcome::Void, Ruling::Decided);
        assert_eq!(
            (owed(&o, "j0.near"), owed(&o, "j1.near")),
            (625_000, 625_000),
            "voting Void is paid like any other decision"
        );
        assert_eq!(
            (owed(&o, "dave.near"), owed(&o, "carol.near")),
            (2 * BOND - 1_250_000, 0)
        );
    }

    // Nobody decided, so the proposer gets their own bond back. The challenger's bond is split: half to the jurors who
    // revealed, the other half to the proposer.
    #[test]
    fn a_dispute_nobody_decided_returns_the_proposers_bond_and_splits_the_challengers() {
        let mut o = oracle_with_bond(BOND);
        disputed_case(
            &mut o,
            Outcome::Yes,
            &JURORS[..2],
            &[(JURORS[0], Outcome::Yes), (JURORS[1], Outcome::No)],
        );
        act_as("anyone.near", DEADLINE + 1);
        o.settle(&acct(MARKET), 0, Outcome::Void, Ruling::NoDecision);
        assert_eq!(
            (owed(&o, "j0.near"), owed(&o, "j1.near"), owed(&o, "j2.near")),
            (1_250_000, 1_250_000, 0)
        );
        assert_eq!((owed(&o, "carol.near"), owed(&o, "dave.near")), (BOND + BOND / 2, 0));
        assert_eq!((owed(&o, OWNER), owed(&o, RECIPIENT)), (0, 0));
    }

    // With nobody having revealed, the jurors' half is held by the no-decision recipient, so it still leaves the two
    // parties, and it does not land in the owner's claimable, which is the DAO's.
    #[test]
    fn when_no_juror_revealed_the_no_decision_recipient_holds_the_jurors_half() {
        let mut o = oracle_with_bond(BOND);
        disputed_case(&mut o, Outcome::Void, &[], &[]);
        act_as("anyone.near", DEADLINE + 1);
        o.settle(&acct(MARKET), 0, Outcome::Void, Ruling::NoDecision);
        assert_eq!(
            (
                owed(&o, "carol.near"),
                owed(&o, "dave.near"),
                owed(&o, RECIPIENT),
                owed(&o, OWNER)
            ),
            (BOND + BOND / 2, 0, BOND / 2, 0)
        );
    }

    #[test]
    fn a_recipient_the_owner_set_receives_the_half_instead_of_the_one_given_at_deploy() {
        let mut o = oracle_with_bond(BOND);
        act_unpaid(OWNER, 1);
        o.set_no_decision_recipient(acct("council-revenue.near"));
        disputed_case(&mut o, Outcome::Void, &[], &[]);
        act_as("anyone.near", DEADLINE + 1);
        o.settle(&acct(MARKET), 0, Outcome::Void, Ruling::NoDecision);
        assert_eq!((owed(&o, "council-revenue.near"), owed(&o, RECIPIENT)), (BOND / 2, 0));
    }

    #[test]
    fn only_the_owner_sets_the_recipient_and_the_change_is_logged_and_shown() {
        let mut o = fresh_oracle();
        assert_eq!(o.config()["no_decision_recipient"], RECIPIENT);
        for who in ["stranger.near", OPERATOR] {
            act_unpaid(who, 5);
            assert!(refusal(|| o.set_no_decision_recipient(acct("x.near"))).contains("owner only"));
        }
        act_unpaid(OWNER, 5);
        o.set_no_decision_recipient(acct("x.near"));
        assert_eq!(o.config()["no_decision_recipient"], "x.near");
        assert!(near_sdk::test_utils::get_logs()
            .iter()
            .any(|l| l.contains("no_decision_recipient_set") && l.contains("x.near")));
    }

    // Carol proposed Void herself and nobody decided. She must not win both bonds just because the answer is the one she
    // proposed: the challenger's half for the jurors still leaves her.
    #[test]
    fn a_timeout_does_not_hand_the_proposer_both_bonds_when_she_proposed_void() {
        let mut o = oracle_with_bond(BOND);
        disputed_case(&mut o, Outcome::Void, &[], &[]);
        act_as("anyone.near", DEADLINE + 1);
        o.settle(&acct(MARKET), 0, Outcome::Void, Ruling::NoDecision);
        assert!(owed(&o, "carol.near") < 2 * BOND, "{}", owed(&o, "carol.near"));
    }

    #[test]
    fn an_unchallenged_answer_only_returns_the_proposers_bond() {
        let mut o = oracle_with_bond(BOND);
        let mut case = {
            disputed_case(&mut o, Outcome::Yes, &[], &[]);
            o.case(&acct(MARKET), 0)
        };
        case.stage = Stage::Proposed;
        case.challenger = None;
        case.challenger_answer = None;
        case.panel = vec![];
        o.put_case(&acct(MARKET), 0, case);
        o.bonds_held = BOND;
        act_as("anyone.near", 100);
        o.settle(&acct(MARKET), 0, Outcome::Yes, Ruling::Unchallenged);
        assert_eq!((owed(&o, "carol.near"), owed(&o, "dave.near")), (BOND, 0));
        assert!(o.case(&acct(MARKET), 0).delinquent.is_empty());
    }

    #[test]
    fn jurors_who_never_committed_are_delinquent_but_a_case_settled_early_does_not_blame_a_committed_juror() {
        let mut o = oracle_with_bond(BOND);
        // j0 and j1 revealed No, j2 never committed. j1's commit counts as voted. A fourth juror who committed and has
        // not revealed would still have time, so is not counted.
        disputed_case(
            &mut o,
            Outcome::Yes,
            &JURORS[..2],
            &[(JURORS[0], Outcome::No), (JURORS[1], Outcome::No)],
        );
        let mut case = o.case(&acct(MARKET), 0);
        case.panel.push(acct("j3.near"));
        case.commits.push(Commit {
            juror: acct("j3.near"),
            commitment: "c".into(),
        });
        o.put_case(&acct(MARKET), 0, case);
        act_as(JURORS[1], DEADLINE - 1);
        o.settle(&acct(MARKET), 0, Outcome::No, Ruling::Decided);
        assert_eq!(o.case(&acct(MARKET), 0).delinquent, vec![acct("j2.near")]);
        let sent = unlock_call().expect("the council is told to release the jury");
        assert_eq!(sent["delinquent"], near_sdk::serde_json::json!(["j2.near"]));
        assert_eq!(sent["case_key"], "1");
    }

    #[test]
    fn once_the_reveal_window_is_over_a_juror_who_committed_and_never_revealed_is_delinquent_too() {
        let mut o = oracle_with_bond(BOND);
        disputed_case(&mut o, Outcome::Yes, &JURORS, &[(JURORS[0], Outcome::Yes)]);
        act_as("anyone.near", DEADLINE + 1);
        o.settle(&acct(MARKET), 0, Outcome::Void, Ruling::NoDecision);
        assert_eq!(
            o.case(&acct(MARKET), 0).delinquent,
            vec![acct("j1.near"), acct("j2.near")]
        );
    }

    #[test]
    fn retry_unlock_sends_the_same_delinquent_list_again() {
        let mut o = oracle_with_bond(BOND);
        disputed_case(&mut o, Outcome::Yes, &JURORS, &[]);
        act_as("anyone.near", DEADLINE + 1);
        o.settle(&acct(MARKET), 0, Outcome::Void, Ruling::NoDecision);
        let first = unlock_call().unwrap();
        act_as("stranger.near", DEADLINE + 2);
        assert!(
            unlock_call().is_none(),
            "a new transaction starts with no receipts, so the next one is the retry's"
        );
        let _ = o.retry_unlock(acct(MARKET), U64(0));
        assert_eq!(unlock_call().expect("the retry sends it"), first);
        assert_eq!(
            first["delinquent"],
            near_sdk::serde_json::json!(["j0.near", "j1.near", "j2.near"])
        );
    }

    // ---- challenges name an answer --------------------------------------------------------------------

    #[test]
    #[should_panic(expected = "a challenge must name a different answer than the proposal")]
    fn a_challenge_naming_the_proposed_answer_is_refused() {
        challenged(Outcome::Yes, Outcome::Yes);
    }

    #[test]
    #[should_panic(expected = "outcome must be yes, no or void")]
    fn a_challenge_with_no_answer_is_refused() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        o.put_case(
            &acct(MARKET),
            0,
            Case {
                case_uid: U64(1),
                stage: Stage::Proposed,
                challenger: None,
                challenger_answer: None,
                ..o.case(&acct(MARKET), 0)
            },
        );
        act_as(VERIFIER, CHALLENGED_AT);
        deliver(&mut o, "dave.near", BOND, "challenge:market.near:0");
    }

    #[test]
    fn a_challenge_records_the_answer_the_round_and_the_jury_size_the_case_was_proposed_with() {
        let mut o = oracle_with_bond(BOND);
        act_as(OWNER, 0);
        o.set_jury_size(LARGER_JURY_SIZE);
        o.put_market(
            0,
            MarketInfo {
                resolve_by: U64(MARKET_DEADLINE),
                ..base_info()
            },
        );
        act_as(VERIFIER, SECOND);
        deliver(&mut o, "carol.near", BOND, "propose:market.near:0:yes:https://x");
        act_at_height(VERIFIER, CHALLENGED_AT, 10);
        deliver(&mut o, "dave.near", BOND, "challenge:market.near:0:void");
        let case = o.case(&acct(MARKET), 0);
        assert_eq!(
            (case.stage, case.challenger_answer, case.round, case.jury_size),
            (Stage::Disputed, Some(Outcome::Void), 0, LARGER_JURY_SIZE)
        );
        assert_eq!(
            (case.challenged_at.0, case.draw_by.0, case.draw_after_height.0),
            (CHALLENGED_AT, DRAW_BY, 12)
        );
        assert_eq!(
            (case.commit_ends_at.0, case.panel_deadline.0),
            (0, 0),
            "the jurors' clock has not started"
        );
    }

    #[test]
    #[should_panic(expected = "vote for the proposed answer or the challenger's answer")]
    fn a_vote_for_a_third_outcome_is_refused() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        let jurors = names(FIRST_JURORS, "j");
        seat(&mut o, DRAW_BY, &jurors);
        commit(&mut o, "j0.near", DRAW_BY + SECOND, Outcome::Void, "a-long-random-salt");
        reveal_when_open(&mut o, "j0.near", Outcome::Void, "a-long-random-salt");
    }

    // ---- the jurors' clock starts at the draw -----------------------------------------------------------------

    #[test]
    fn a_jury_drawn_at_the_last_allowed_moment_still_gets_the_full_commit_and_reveal_time() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        let jurors = names(FIRST_JURORS, "j");
        act_at_height(OWNER, DRAW_BY, 5);
        let _ = o.resolve_draw(acct(MARKET), U64(0));
        seat(&mut o, DRAW_BY, &jurors);
        let case = o.case(&acct(MARKET), 0);
        assert_eq!(case.commit_ends_at.0, DRAW_BY + PANEL / 2);
        assert_eq!(case.panel_deadline.0, DRAW_BY + PANEL);
        // The jurors can commit right up to the end of their own commit phase and reveal right up to their deadline.
        commit(
            &mut o,
            "j0.near",
            case.commit_ends_at.0 - 1,
            Outcome::No,
            "a-long-random-salt",
        );
        reveal(
            &mut o,
            "j0.near",
            case.panel_deadline.0,
            Outcome::No,
            "a-long-random-salt",
        );
        assert_eq!(o.case(&acct(MARKET), 0).votes.len(), 1);
    }

    #[test]
    fn the_jury_clock_counts_from_when_the_jury_lands_not_from_the_challenge() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        seat(&mut o, CHALLENGED_AT + 17 * SECOND, &names(FIRST_JURORS, "j"));
        assert_eq!(
            o.case(&acct(MARKET), 0).panel_deadline.0,
            CHALLENGED_AT + 17 * SECOND + PANEL
        );
    }

    #[test]
    fn a_jury_can_be_drawn_up_to_and_including_draw_by() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        act_at_height(OWNER, DRAW_BY, 5);
        let _ = o.resolve_draw(acct(MARKET), U64(0));
    }

    #[test]
    #[should_panic(expected = "too late to draw a jury")]
    fn a_jury_cannot_be_drawn_after_draw_by() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        act_at_height(OWNER, DRAW_BY + 1, 5);
        let _ = o.resolve_draw(acct(MARKET), U64(0));
    }

    #[test]
    fn a_draw_carries_the_case_key_the_jury_size_and_who_may_not_sit_and_no_seed() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        act_at_height(OWNER, DRAW_BY, 5);
        let _ = o.resolve_draw(acct(MARKET), U64(0));
        let sent = calls_to("draw");
        assert_eq!(
            sent,
            vec![
                near_sdk::serde_json::json!({ "case_key": "1", "n": TEST_JURY_SIZE, "exclude": ["carol.near", "dave.near"] })
            ]
        );
    }

    // A size change after the challenge leaves the case on the size it was challenged with.
    #[test]
    fn a_jury_size_change_between_challenge_and_draw_does_not_strand_the_case() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        act_as(OWNER, 3 * SECOND);
        o.set_jury_size(TEST_JURY_SIZE + 2);
        act_at_height(OWNER, DRAW_BY, 5);
        let _ = o.resolve_draw(acct(MARKET), U64(0));
        assert_eq!(
            calls_to("draw")[0]["n"],
            TEST_JURY_SIZE,
            "the draw asks for the size the case was challenged with"
        );
        seat(&mut o, DRAW_BY, &names(FIRST_JURORS, "j"));
        assert_eq!(
            o.case(&acct(MARKET), 0).panel.len(),
            FIRST_JURORS,
            "a jury of that size is accepted although the setting is larger now"
        );
        assert_eq!(o.get_case(acct(MARKET), U64(0)).unwrap().jury_size, TEST_JURY_SIZE);
    }

    #[test]
    fn a_jury_of_the_wrong_size_or_for_another_round_is_refused() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        seat(&mut o, DRAW_BY, &names(2, "j"));
        assert!(
            o.case(&acct(MARKET), 0).panel.is_empty(),
            "two jurors for a jury of five"
        );
        act_as(COUNCIL, DRAW_BY);
        o.on_drawn(
            acct(MARKET),
            U64(0),
            1,
            Ok(names(FIRST_JURORS, "j").iter().map(|j| acct(j)).collect()),
        );
        assert!(
            o.case(&acct(MARKET), 0).panel.is_empty(),
            "a draw for the second round while the case is in the first"
        );
    }

    // ---- a stalled jury is no longer free ------------------------------------------------------------------

    #[test]
    fn a_case_never_drawn_is_a_no_decision_that_calls_for_the_second_jury() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        act_as("anyone.near", DRAW_BY);
        let early = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| o.finalize(acct(MARKET), U64(0))));
        assert!(early.is_err(), "a jury can still be drawn at draw_by");
        act_at_height("anyone.near", QUEUE_OVER, 20);
        o.finalize(acct(MARKET), U64(0));
        let case = o.case(&acct(MARKET), 0);
        assert_eq!(
            (case.stage, case.round, case.jury_size),
            (Stage::Disputed, 1, SECOND_JURORS as u32)
        );
        assert_eq!(case.draw_by.0, QUEUE_OVER + DRAW_WINDOW);
        assert_eq!(case.draw_after_height.0, 22);
        assert!(case.first_panel.is_empty() && case.panel.is_empty());
    }

    #[test]
    fn a_no_decision_escalates_exactly_once_to_a_larger_disjoint_jury() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        let first = names(FIRST_JURORS, "j");
        let over = first_round_that_does_nothing(&mut o, &first);
        // One juror commits and reveals, which is not a majority of five.
        let case = o.case(&acct(MARKET), 0);
        commit(&mut o, "j0.near", DRAW_BY + SECOND, Outcome::No, "a-long-random-salt");
        reveal(
            &mut o,
            "j0.near",
            case.commit_ends_at.0,
            Outcome::No,
            "a-long-random-salt",
        );
        act_at_height("anyone.near", over, 30);
        o.finalize(acct(MARKET), U64(0));
        let case = o.case(&acct(MARKET), 0);
        assert_eq!(
            (case.stage, case.round, case.jury_size),
            (Stage::Disputed, 1, SECOND_JURORS as u32),
            "it called for a larger jury"
        );
        assert_eq!(case.first_panel, first.iter().map(|j| acct(j)).collect::<Vec<_>>());
        assert!(case.panel.is_empty(), "and the second jury is drawn afresh");
        assert_eq!(case.votes.len(), 1, "what the first jury did is kept");

        // The second draw names the second round's own key, the larger size, and leaves out the parties and the first jury.
        act_at_height("anyone.near", over + SECOND, 40);
        let _ = o.resolve_draw(acct(MARKET), U64(0));
        let sent = calls_to("draw");
        assert_eq!(
            sent,
            vec![near_sdk::serde_json::json!({
                "case_key": (SECOND_ROUND_KEY | 1).to_string(), "n": SECOND_JURORS,
                "exclude": ["carol.near", "dave.near", "j0.near", "j1.near", "j2.near", "j3.near", "j4.near"]
            })]
        );

        // The second jury sits and does nothing. Its deadline passing settles the case, and it does not escalate again.
        let second = names(SECOND_JURORS, "k");
        seat(&mut o, over + 2 * SECOND, &second);
        let over_again = o.case(&acct(MARKET), 0).panel_deadline.0 + 1;
        act_as("anyone.near", over_again);
        o.finalize(acct(MARKET), U64(0));
        let case = o.case(&acct(MARKET), 0);
        assert_eq!((case.stage, case.final_outcome), (Stage::Final, Some(Outcome::Void)));
        assert_eq!(case.round, 1);
        // Both juries are released, each under its own key, with the same list of who never voted.
        let unlocks = calls_to("unlock_case");
        let keys: Vec<_> = unlocks.iter().map(|u| u["case_key"].clone()).collect();
        assert_eq!(
            keys,
            vec![
                near_sdk::serde_json::json!("1"),
                near_sdk::serde_json::json!((SECOND_ROUND_KEY | 1).to_string())
            ]
        );
        assert_eq!(unlocks[0]["delinquent"], unlocks[1]["delinquent"]);
        assert_eq!(
            unlocks[0]["delinquent"].as_array().unwrap().len(),
            (FIRST_JURORS - 1) + SECOND_JURORS,
            "the first jurors but j0 and all the second jurors never voted"
        );
    }

    #[test]
    fn a_late_draw_for_the_first_round_cannot_seat_a_jury_in_the_second() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        act_as("anyone.near", DRAW_BY + 1);
        o.finalize(acct(MARKET), U64(0));
        act_as(COUNCIL, DRAW_BY + 2);
        o.on_drawn(
            acct(MARKET),
            U64(0),
            0,
            Ok(names(SECOND_JURORS, "k").iter().map(|j| acct(j)).collect()),
        );
        assert!(o.case(&acct(MARKET), 0).panel.is_empty());
    }

    #[test]
    fn the_second_jury_is_twice_the_first_plus_one_and_never_more_than_21() {
        for (first, second) in [(5u32, 11u32), (7, 15), (9, 19), (11, 21), (21, 21)] {
            let mut o = challenged(Outcome::Yes, Outcome::No);
            o.put_case(
                &acct(MARKET),
                0,
                Case {
                    jury_size: first,
                    ..o.case(&acct(MARKET), 0)
                },
            );
            act_as("anyone.near", QUEUE_OVER);
            o.finalize(acct(MARKET), U64(0));
            assert_eq!(o.case(&acct(MARKET), 0).jury_size, second, "from {first}");
        }
    }

    // No time left for another round before the market's deadline: the case ends with no decision instead.
    #[test]
    fn a_failed_first_jury_does_not_call_for_a_second_when_there_is_no_time_for_it() {
        let over = DRAW_BY + 1;
        let fits = over + DRAW_WINDOW + PANEL + APPLY_BUFFER_NS;
        for (resolve_by, escalates) in [(fits, true), (fits - 1, false)] {
            let mut o = challenged(Outcome::Yes, Outcome::No);
            o.put_market(
                0,
                MarketInfo {
                    resolve_by: U64(resolve_by),
                    ..o.get_market_info(acct(MARKET), U64(0)).unwrap()
                },
            );
            act_as("anyone.near", over);
            o.finalize(acct(MARKET), U64(0));
            let case = o.case(&acct(MARKET), 0);
            assert_eq!(case.stage == Stage::Disputed, escalates, "resolve_by {resolve_by}");
            assert_eq!(case.stage == Stage::Final, !escalates);
        }
    }

    #[test]
    fn a_second_no_decision_pays_the_proposer_and_every_juror_who_revealed() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        let first = names(FIRST_JURORS, "j");
        let over = first_round_that_does_nothing(&mut o, &first);
        commit(&mut o, "j0.near", DRAW_BY + SECOND, Outcome::Yes, "a-long-random-salt");
        reveal_when_open(&mut o, "j0.near", Outcome::Yes, "a-long-random-salt");
        act_at_height("anyone.near", over, 30);
        o.finalize(acct(MARKET), U64(0));
        let second = names(SECOND_JURORS, "k");
        seat(&mut o, over + SECOND, &second);
        let case = o.case(&acct(MARKET), 0);
        for (juror, outcome) in [("k0.near", Outcome::No), ("k1.near", Outcome::Yes)] {
            commit(&mut o, juror, over + 2 * SECOND, outcome, "a-long-random-salt");
            reveal(&mut o, juror, case.commit_ends_at.0, outcome, "a-long-random-salt");
        }
        act_as("anyone.near", case.panel_deadline.0 + 1);
        o.finalize(acct(MARKET), U64(0));
        // Three jurors revealed, in two rounds. Half the challenger's bond, 2,500,000, is split three ways and the rest
        // of both bonds is the proposer's.
        assert_eq!(
            (owed(&o, "j0.near"), owed(&o, "k0.near"), owed(&o, "k1.near")),
            (833_333, 833_333, 833_333)
        );
        assert_eq!(owed(&o, "carol.near"), 2 * BOND - 3 * 833_333);
        assert_eq!(
            (owed(&o, "dave.near"), owed(&o, "k2.near"), owed(&o, "j1.near")),
            (0, 0, 0)
        );
        assert_eq!(o.case(&acct(MARKET), 0).final_outcome, Some(Outcome::Void));
    }

    #[test]
    fn a_price_market_whose_dispute_never_decides_keeps_the_signed_price_and_an_event_market_is_void() {
        for (price_rule, expected) in [
            (
                Some(PriceRule {
                    observation_time: U64(0),
                    strike: U128(1),
                    decimals: 2,
                    above: true,
                }),
                Outcome::Yes,
            ),
            (None, Outcome::Void),
        ] {
            let mut o = challenged(Outcome::Yes, Outcome::No);
            o.put_market(
                0,
                MarketInfo {
                    price_rule,
                    ..o.get_market_info(acct(MARKET), U64(0)).unwrap()
                },
            );
            let mut case = o.case(&acct(MARKET), 0);
            case.round = 1;
            o.put_case(&acct(MARKET), 0, case);
            act_as("anyone.near", QUEUE_OVER);
            o.finalize(acct(MARKET), U64(0));
            assert_eq!(o.case(&acct(MARKET), 0).final_outcome, Some(expected));
            let applied = calls_to("set_outcome");
            assert_eq!(
                applied,
                vec![near_sdk::serde_json::json!({ "market_id": "0", "outcome": expected })]
            );
        }
    }

    #[test]
    #[should_panic(expected = "not on the panel for this case")]
    fn a_juror_of_the_first_jury_cannot_reveal_in_the_second_round() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        let first = names(FIRST_JURORS, "j");
        let over = first_round_that_does_nothing(&mut o, &first);
        commit(&mut o, "j0.near", DRAW_BY + SECOND, Outcome::No, "a-long-random-salt");
        act_as("anyone.near", over);
        o.finalize(acct(MARKET), U64(0));
        seat(&mut o, over + SECOND, &names(SECOND_JURORS, "k"));
        reveal_when_open(&mut o, "j0.near", Outcome::No, "a-long-random-salt");
    }

    // Round one of five: j0 revealed No, j1 committed and never revealed, j2 to j4 never committed. Round two of eleven: k0
    // to k5 reveal No and decide it, k6 committed and has time left, k7 to k10 never committed.
    #[test]
    fn jurors_who_never_voted_in_either_round_are_delinquent_and_every_revealer_with_the_outcome_is_paid() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        let first = names(FIRST_JURORS, "j");
        let over = first_round_that_does_nothing(&mut o, &first);
        commit(&mut o, "j0.near", DRAW_BY + SECOND, Outcome::No, "a-long-random-salt");
        commit(&mut o, "j1.near", DRAW_BY + SECOND, Outcome::No, "a-long-random-salt");
        reveal_when_open(&mut o, "j0.near", Outcome::No, "a-long-random-salt");
        act_at_height("anyone.near", over, 30);
        o.finalize(acct(MARKET), U64(0));
        seat(&mut o, over + SECOND, &names(SECOND_JURORS, "k"));
        let case = o.case(&acct(MARKET), 0);
        for i in 0..=SECOND_MAJORITY {
            commit(
                &mut o,
                &format!("k{i}.near"),
                over + 2 * SECOND,
                Outcome::No,
                "a-long-random-salt",
            );
        }
        for i in 0..SECOND_MAJORITY {
            reveal(
                &mut o,
                &format!("k{i}.near"),
                case.commit_ends_at.0,
                Outcome::No,
                "a-long-random-salt",
            );
        }
        let case = o.case(&acct(MARKET), 0);
        assert_eq!((case.stage, case.final_outcome), (Stage::Final, Some(Outcome::No)));
        assert_eq!(
            case.delinquent,
            ["j1", "j2", "j3", "j4", "k7", "k8", "k9", "k10"]
                .map(|j| acct(&format!("{j}.near")))
                .to_vec(),
            "the first jury's non-voters, and the second jury's who never committed"
        );
        // Carol proposed Yes and lost. A quarter of her bond is split by those who revealed No, across both rounds.
        let revealers = 1 + SECOND_MAJORITY as u128;
        let each = BOND * JUROR_SHARE_BPS / 10_000 / revealers;
        let revealed = ["j0".to_string()]
            .into_iter()
            .chain((0..SECOND_MAJORITY).map(|i| format!("k{i}")));
        for juror in revealed {
            assert_eq!(owed(&o, &format!("{juror}.near")), each, "{juror}");
        }
        assert_eq!(owed(&o, "dave.near"), 2 * BOND - each * revealers);
        assert_eq!(owed(&o, "carol.near"), 0);
    }

    #[test]
    fn retry_unlock_after_a_second_round_releases_both_juries() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        let mut case = o.case(&acct(MARKET), 0);
        case.round = 1;
        o.put_case(&acct(MARKET), 0, case);
        act_as("anyone.near", QUEUE_OVER);
        o.finalize(acct(MARKET), U64(0));
        act_as("stranger.near", DRAW_BY + 2);
        let _ = o.retry_unlock(acct(MARKET), U64(0));
        let keys: Vec<_> = calls_to("unlock_case").iter().map(|u| u["case_key"].clone()).collect();
        assert_eq!(
            keys,
            vec![
                near_sdk::serde_json::json!("1"),
                near_sdk::serde_json::json!((SECOND_ROUND_KEY | 1).to_string())
            ]
        );
    }

    // ---- gas floors ---------------------------------------------------------------------------------------

    fn act_with_gas(who: &str, now_ns: u64, tgas: u64) {
        testing_env!(VMContextBuilder::new()
            .predecessor_account_id(acct(who))
            .block_timestamp(now_ns)
            .attached_deposit(NearToken::from_yoctonear(1))
            .prepaid_gas(Gas::from_tgas(tgas))
            .build());
    }

    // The least a method may be called with, and the words its refusal starts with.
    #[test]
    fn a_call_below_its_gas_floor_is_refused_with_the_amount_to_attach() {
        let settle = "attach at least 80 TGas: a call that settles a case sends the answer to the market and releases the juries";
        let mut o = challenged(Outcome::Yes, Outcome::No);
        let at = DRAW_BY + 1;
        act_with_gas("anyone.near", at, 79);
        assert_eq!(refusal(|| o.finalize(acct(MARKET), U64(0))), settle);
        act_with_gas("anyone.near", at, 79);
        assert_eq!(refusal(|| o.resolve_by_deadline(acct(MARKET), U64(0))), settle);
        act_with_gas("j0.near", at, 79);
        assert_eq!(
            refusal(|| o.reveal_vote(acct(MARKET), U64(0), Outcome::Yes, "s".into(), "r".into())),
            settle
        );
        act_with_gas("anyone.near", at, 274);
        assert_eq!(
            refusal(|| drop(o.resolve_draw(acct(MARKET), U64(0)))),
            "attach at least 275 TGas: the jury draw reads every staked seat"
        );
        act_with_gas("anyone.near", at, 34);
        assert_eq!(
            refusal(|| drop(o.retry_unlock(acct(MARKET), U64(0)))),
            "attach at least 35 TGas: each jury's release gets an equal share of what is attached"
        );
        act_with_gas("anyone.near", at, 32);
        assert_eq!(
            refusal(|| drop(o.withdraw_bond())),
            "attach at least 33 TGas: a withdrawal sends the payout and then settles it"
        );
    }

    // At the floor the gas check passes and the call goes on to whatever else it checks, here a market with no case.
    #[test]
    fn a_call_with_exactly_its_gas_floor_gets_past_the_check() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        let at = DRAW_BY + 1;
        let past = |refused: String| {
            assert!(
                refused.contains("not registered") || refused.contains("no case"),
                "{refused}"
            )
        };
        act_with_gas("anyone.near", at, 80);
        past(refusal(|| o.finalize(acct(MARKET), U64(99))));
        act_with_gas("anyone.near", at, 80);
        past(refusal(|| o.resolve_by_deadline(acct(MARKET), U64(99))));
        act_with_gas("j0.near", at, 80);
        past(refusal(|| {
            o.reveal_vote(acct(MARKET), U64(99), Outcome::Yes, "s".into(), "r".into())
        }));
        act_with_gas("anyone.near", at, 275);
        past(refusal(|| drop(o.resolve_draw(acct(MARKET), U64(99)))));
        act_with_gas("anyone.near", at, 35);
        past(refusal(|| drop(o.retry_unlock(acct(MARKET), U64(99)))));
        let refused = {
            act_with_gas("anyone.near", at, 33);
            refusal(|| drop(o.withdraw_bond()))
        };
        assert_eq!(refused, "nothing to withdraw");
    }

    #[test]
    fn the_floors_follow_from_what_the_methods_reserve() {
        assert_eq!(
            GAS_SETTLE_FLOOR,
            Gas::from_tgas(80),
            "apply 20, its callback 10, two releases of 15, and 20 for the call itself"
        );
        assert_eq!(
            GAS_DRAW_FLOOR,
            Gas::from_tgas(275),
            "the draw 250, its callback 15, and 10 for the call itself"
        );
        assert_eq!(GAS_RETRY_UNLOCK_FLOOR, Gas::from_tgas(35));
        assert_eq!(
            GAS_WITHDRAW_FLOOR,
            Gas::from_tgas(33),
            "the payout 15, its callback 10, and 8 for the call itself"
        );
        assert!(
            GAS_DRAW_FLOOR < Gas::from_tgas(300),
            "a transaction carries at most 300 TGas"
        );
    }

    // ---- the deadline answer is the oracle's ----------------------------------------------------------------

    #[test]
    #[should_panic(expected = "the answer deadline has not passed")]
    fn nobody_can_ask_for_the_deadline_answer_early() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        o.put_market(
            0,
            MarketInfo {
                resolve_by: U64(MARKET_DEADLINE),
                ..o.get_market_info(acct(MARKET), U64(0)).unwrap()
            },
        );
        act_as("anyone.near", MARKET_DEADLINE - 1);
        o.resolve_by_deadline(acct(MARKET), U64(0));
    }

    #[test]
    fn with_no_case_the_deadline_voids_the_market_and_there_is_no_case_to_mark_applied() {
        let mut o = fresh_oracle();
        o.put_market(
            0,
            MarketInfo {
                resolve_by: U64(1_000),
                ..base_info()
            },
        );
        act_as("anyone.near", 1_000);
        o.resolve_by_deadline(acct(MARKET), U64(0));
        assert_eq!(
            calls_to("set_outcome"),
            vec![near_sdk::serde_json::json!({ "market_id": "0", "outcome": "void" })]
        );
        act_as(MARKET, 1_001);
        o.on_applied(acct(MARKET), U64(0), Ok(()));
        assert!(o.get_case(acct(MARKET), U64(0)).is_none());
    }

    // The answer nobody finalized is applied instead of voided over.
    #[test]
    fn a_settleable_unchallenged_proposal_is_settled_at_the_deadline_not_voided() {
        let mut o = oracle_with_bond(BOND);
        o.put_market(
            0,
            MarketInfo {
                resolve_by: U64(MIN_GAP),
                ..base_info()
            },
        );
        act_as(VERIFIER, SECOND);
        deliver(&mut o, "carol.near", BOND, "propose:market.near:0:yes:https://x");
        act_as("anyone.near", MIN_GAP);
        o.resolve_by_deadline(acct(MARKET), U64(0));
        assert_eq!(
            calls_to("set_outcome"),
            vec![near_sdk::serde_json::json!({ "market_id": "0", "outcome": "yes" })]
        );
        assert_eq!(
            (o.case(&acct(MARKET), 0).stage, owed(&o, "carol.near")),
            (Stage::Final, BOND)
        );
    }

    #[test]
    fn a_dispute_that_ran_out_of_time_is_settled_with_no_decision_at_the_deadline() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        o.put_market(
            0,
            MarketInfo {
                resolve_by: U64(DRAW_BY + 1),
                ..o.get_market_info(acct(MARKET), U64(0)).unwrap()
            },
        );
        act_as("anyone.near", DRAW_BY + 1);
        o.resolve_by_deadline(acct(MARKET), U64(0));
        assert_eq!(
            (o.case(&acct(MARKET), 0).stage, o.case(&acct(MARKET), 0).final_outcome),
            (Stage::Final, Some(Outcome::Void))
        );
        assert_eq!(calls_to("set_outcome").len(), 1);
    }

    #[test]
    fn a_final_answer_the_market_never_received_is_sent_again_and_a_received_one_is_refused() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        o.put_market(
            0,
            MarketInfo {
                resolve_by: U64(DRAW_BY + 1),
                ..o.get_market_info(acct(MARKET), U64(0)).unwrap()
            },
        );
        act_as("anyone.near", DRAW_BY + 1);
        o.resolve_by_deadline(acct(MARKET), U64(0));
        act_as("anyone.near", DRAW_BY + 2);
        o.resolve_by_deadline(acct(MARKET), U64(0));
        assert_eq!(calls_to("set_outcome").len(), 1, "sent again");
        let mut case = o.case(&acct(MARKET), 0);
        case.applied = true;
        o.put_case(&acct(MARKET), 0, case);
        let again = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            o.resolve_by_deadline(acct(MARKET), U64(0))
        }));
        assert!(again.is_err());
    }

    // The timing rules leave no case with time at resolve_by. If a later change ever does, the deadline call refuses
    // instead of voiding the market under a case that would settle an answer nobody can apply.
    #[test]
    fn a_proposal_whose_window_is_still_open_at_the_deadline_is_refused_not_voided() {
        let mut o = oracle_with_bond(BOND);
        o.put_market(
            0,
            MarketInfo {
                resolve_by: U64(MARKET_DEADLINE),
                ..base_info()
            },
        );
        act_as(VERIFIER, SECOND);
        deliver(&mut o, "carol.near", BOND, "propose:market.near:0:yes:https://x");
        o.put_market(
            0,
            MarketInfo {
                resolve_by: U64(10 * SECOND),
                ..base_info()
            },
        );
        act_as("anyone.near", 10 * SECOND);
        assert!(refusal(|| o.resolve_by_deadline(acct(MARKET), U64(0))).contains("the case still has time"));
        assert!(calls_to("set_outcome").is_empty(), "the market was not told anything");
        assert_eq!(o.case(&acct(MARKET), 0).stage, Stage::Proposed);
    }

    #[test]
    fn a_dispute_whose_jury_still_has_time_at_the_deadline_is_refused_not_voided() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        seat(&mut o, DRAW_BY, &names(FIRST_JURORS, "j"));
        let panel_deadline = o.case(&acct(MARKET), 0).panel_deadline.0;
        o.put_market(
            0,
            MarketInfo {
                resolve_by: U64(panel_deadline),
                ..o.get_market_info(acct(MARKET), U64(0)).unwrap()
            },
        );
        act_as("anyone.near", panel_deadline);
        assert!(refusal(|| o.resolve_by_deadline(acct(MARKET), U64(0))).contains("the case still has time"));
        assert!(calls_to("set_outcome").is_empty());
        assert_eq!(o.case(&acct(MARKET), 0).stage, Stage::Disputed);
        act_as("anyone.near", panel_deadline + 1);
        o.resolve_by_deadline(acct(MARKET), U64(0));
        assert_eq!(
            o.case(&acct(MARKET), 0).stage,
            Stage::Final,
            "one nanosecond later the round is over and it settles"
        );
    }

    // The most a jury can be seated after the last block a draw is allowed in: a few blocks.
    const SEAT_LAG: u64 = 10 * SECOND;

    proptest! {
        #![proptest_config(ProptestConfig::with_cases(300))]

        // Whatever the windows, whenever the answer is proposed and challenged, whenever the juries are seated (up to a few
        // blocks after the last allowed moment) and whenever, if ever, someone finalizes, a market that registered is never
        // at resolve_by with a case that still has time. Nobody ever has to act: the deadline call alone settles it.
        #[test]
        fn no_registered_market_reaches_its_deadline_with_a_case_that_still_has_time(
            window in 1u64..300,
            draw_window in 1u64..300,
            panel in 2u64..300,
            min_proposal in 1u64..300,
            extra in 0u64..600,
            propose_at in 0u64..=1000,
            challenge_at in proptest::option::of(0u64..1000),
            seat_at in proptest::collection::vec(
                proptest::option::of((prop_oneof![Just(1000), 0u64..=1000], prop_oneof![Just(SEAT_LAG), 0..=SEAT_LAG])),
                2,
            ),
            finalize_after in proptest::collection::vec(proptest::option::of(0u64..=1000), 2),
            at_the_limit in proptest::collection::vec(proptest::option::of(prop_oneof![Just(35), 0u64..=35]), 2),
        ) {
            let mut o = oracle_with_bond(BOND);
            o.window_ns = window * SECOND;
            o.draw_window_ns = draw_window * SECOND;
            o.panel_deadline_ns = panel * SECOND;
            o.min_proposal_ns = min_proposal * SECOND;
            let close = 1_000 * SECOND;
            let deadline = close + o.min_resolve_gap_ns() + extra * SECOND;
            act_as(MARKET, 0);
            o.register_market(U64(0), U64(close), U64(deadline), "hash".to_string(), None);
            let round = o.draw_window_ns + o.panel_deadline_ns;
            let span = case_span_ns(o.window_ns, o.draw_window_ns, o.panel_deadline_ns);
            // Proposals are tried up to the last moment a case could finish by the deadline with no buffer at all. The
            // buffered moment is the last one that has to be accepted. Any between is accepted or refused, never unsafe.
            let latest_proposal = deadline - span - APPLY_BUFFER_NS;
            let proposed = close + (latest_proposal + APPLY_BUFFER_NS - close) * propose_at / 1000;
            act_as(VERIFIER, proposed);
            let accepted = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                deliver(&mut o, "carol.near", BOND, "propose:market.near:0:yes:https://x");
            }))
            .is_ok();
            prop_assert!(accepted || proposed > latest_proposal, "a proposal in time was refused");
            if !accepted {
                return Ok(());
            }
            if let Some(at) = challenge_at {
                let challenged_at = proposed + (o.window_ns - 1) * at / 1000;
                act_as(VERIFIER, challenged_at);
                deliver(&mut o, "dave.near", BOND, "challenge:market.near:0:no");
                let mut round_started = challenged_at;
                for turn in 0..2 {
                    let case = o.case(&acct(MARKET), 0);
                    if let Some((at, lag)) = seat_at[turn] {
                        let seated = round_started + (case.draw_by.0 - round_started) * at / 1000 + lag;
                        seat(&mut o, seated, &names(case.jury_size as usize, "j"));
                    }
                    let case = o.case(&acct(MARKET), 0);
                    let over = if case.panel.is_empty() { case.draw_by.0 } else { case.panel_deadline.0 } + 1;
                    let Some(after) = finalize_after[turn] else { break };
                    let at = match at_the_limit[turn] {
                        Some(offset) => (deadline - round - APPLY_BUFFER_NS + offset * SECOND).saturating_sub(5 * SECOND).max(over),
                        None => over + deadline.saturating_sub(over) * after / 1000,
                    };
                    if at >= deadline {
                        break;
                    }
                    act_as("anyone.near", at);
                    o.finalize(acct(MARKET), U64(0));
                    if o.case(&acct(MARKET), 0).stage == Stage::Final {
                        break;
                    }
                    round_started = at;
                }
            }
            let case = o.case(&acct(MARKET), 0);
            match case.stage {
                Stage::Proposed => prop_assert!(deadline >= case.window_ends_at.0, "the challenge window is still open"),
                Stage::Disputed => prop_assert!(round_is_over(&case, deadline), "the round is not over"),
                Stage::Final => {}
            }
            act_as("anyone.near", deadline);
            o.resolve_by_deadline(acct(MARKET), U64(0));
            prop_assert_eq!(o.case(&acct(MARKET), 0).stage, Stage::Final);
        }
    }

    // ---- the juror methods need exactly one yocto -----------------------------------------------------------

    #[test]
    #[should_panic(expected = "Requires attached deposit of exactly 1 yoctoNEAR")]
    fn commit_vote_refuses_a_call_with_no_deposit() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        act_unpaid("j0.near", DRAW_BY);
        o.commit_vote(acct(MARKET), U64(0), "0".repeat(64));
    }

    #[test]
    #[should_panic(expected = "Requires attached deposit of exactly 1 yoctoNEAR")]
    fn reveal_vote_refuses_a_call_with_no_deposit() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        act_unpaid("j0.near", DRAW_BY);
        o.reveal_vote(acct(MARKET), U64(0), Outcome::Yes, "salt".into(), "because".into());
    }

    // ---- the minimum gap counts the draw window and both rounds -----------------------------------------------

    #[test]
    fn the_minimum_gap_counts_the_proposal_time_the_window_both_rounds_and_the_apply_buffer() {
        let o = fresh_oracle();
        let expected = PROPOSAL_TIME + WINDOW + 2 * (DRAW_WINDOW + PANEL) + APPLY_BUFFER_NS;
        assert_eq!(o.config()["min_resolve_gap_ns"], expected.to_string());
        assert_eq!(o.config()["draw_window_ns"], DRAW_WINDOW.to_string());
    }

    // ---- price markets: signed prices ----------------------------------------------------------------

    const OBS: u64 = 1_000_000_000_000;
    const STRIKE: u128 = 1_000;

    fn signing_key(seed: u8) -> SigningKey {
        SigningKey::from_bytes(&[seed; 32])
    }

    fn public(key: &SigningKey) -> PublicKey {
        PublicKey::from_parts(CurveType::ED25519, key.verifying_key().to_bytes().to_vec()).unwrap()
    }

    fn rule(above: bool) -> PriceRule {
        PriceRule {
            observation_time: U64(OBS),
            strike: U128(STRIKE),
            decimals: 2,
            above,
        }
    }

    // `signer`'s entry for a submission: its key, a dot, and its signature over `message` in hex.
    fn entry(signer: &SigningKey, message: &str) -> String {
        let signature: String = signer
            .sign(message.as_bytes())
            .to_bytes()
            .iter()
            .map(|b| format!("{b:02x}"))
            .collect();
        format!("{}.{signature}", public(signer))
    }

    // What the market's own rule makes publishers sign for `price`.
    fn message(market: u64, rule: &PriceRule, price: u128) -> String {
        price_message(&env::current_account_id(), NETWORK, &acct(MARKET), market, rule, price)
    }

    // Three publishers, two of whom must sign, and price market 0 observed at OBS with room to be answered.
    fn price_oracle(above: bool) -> (OracleContract, Vec<SigningKey>) {
        let mut o = oracle_with(BOND, 2);
        let keys: Vec<SigningKey> = (1..=3).map(signing_key).collect();
        act_as(OWNER, 0);
        for k in &keys {
            o.add_publisher(public(k));
        }
        act_as(MARKET, 0);
        o.register_market(
            U64(0),
            U64(OBS),
            U64(OBS + MIN_GAP + 10_000_000_000),
            "hash".to_string(),
            Some(rule(above)),
        );
        (o, keys)
    }

    // The threshold has to stay above half the publishers, so it is raised before each key that would break that.
    fn add_publisher_keeping_majority(o: &mut OracleContract, key: PublicKey) {
        let needed = (o.publishers.len().div_ceil(2) + 1) as u32;
        if needed > o.price_threshold {
            o.set_price_threshold(needed);
        }
        o.add_publisher(key);
    }

    fn submit(o: &mut OracleContract, at: u64, price: u128, entries: &[String]) {
        act_as(VERIFIER, at);
        deliver(
            o,
            "carol.near",
            BOND,
            &format!("price:market.near:0:{price}:{}", entries.join(",")),
        );
    }

    fn signed_by(keys: &[&SigningKey], market: u64, rule: &PriceRule, price: u128) -> Vec<String> {
        act_as(VERIFIER, 0);
        keys.iter().map(|k| entry(k, &message(market, rule, price))).collect()
    }

    #[test]
    fn two_of_three_publishers_signing_the_markets_own_price_open_a_case() {
        let (mut o, k) = price_oracle(true);
        let sigs = signed_by(&[&k[0], &k[2]], 0, &rule(true), 1_250);
        submit(&mut o, OBS, 1_250, &sigs);
        let case = o.case(&acct(MARKET), 0);
        assert_eq!(
            (case.stage, case.proposed, case.proposer),
            (Stage::Proposed, Outcome::Yes, acct("carol.near"))
        );
        assert_eq!(case.evidence, "signed price 1250 by 2 publishers");
    }

    // The data of the last proposed event the call logged.
    fn proposed_event() -> near_sdk::serde_json::Value {
        near_sdk::test_utils::get_logs()
            .iter()
            .filter_map(|l| l.strip_prefix("EVENT_JSON:"))
            .map(|j| near_sdk::serde_json::from_str::<near_sdk::serde_json::Value>(j).unwrap())
            .find(|e| e["event"] == "proposed")
            .expect("a proposed event")["data"]
            .clone()
    }

    #[test]
    fn the_proposed_event_of_a_price_answer_names_the_publishers_who_signed() {
        let (mut o, k) = price_oracle(true);
        let sigs = signed_by(&[&k[2], &k[0]], 0, &rule(true), 1_250);
        submit(&mut o, OBS, 1_250, &sigs);
        let event = proposed_event();
        assert_eq!(
            event["signers"],
            near_sdk::serde_json::json!([public(&k[2]).to_string(), public(&k[0]).to_string()])
        );
        assert_eq!(event["evidence"], "signed price 1250 by 2 publishers");
    }

    #[test]
    fn every_signer_counts_and_is_named_when_more_than_the_threshold_sign() {
        let (mut o, k) = price_oracle(true);
        let sigs = signed_by(&[&k[0], &k[1], &k[2]], 0, &rule(true), 900);
        submit(&mut o, OBS, 900, &sigs);
        let signers = proposed_event()["signers"].clone();
        assert_eq!(signers.as_array().unwrap().len(), 3);
        assert_eq!(o.case(&acct(MARKET), 0).evidence, "signed price 900 by 3 publishers");
    }

    #[test]
    fn a_plain_proposal_names_no_signers() {
        let mut o = oracle_with_resolve_by(MARKET_DEADLINE);
        act_as(VERIFIER, 10 * SECOND);
        let bond = o.bond;
        deliver(
            &mut o,
            "carol.near",
            bond,
            "propose:market.near:0:yes:https://example.com",
        );
        assert_eq!(proposed_event()["signers"], near_sdk::serde_json::json!([]));
    }

    #[test]
    fn the_price_decides_yes_or_no_against_the_strike_in_the_markets_direction() {
        for (above, price, expected) in [
            (true, STRIKE, Outcome::Yes),
            (true, STRIKE - 1, Outcome::No),
            (true, STRIKE + 1, Outcome::Yes),
            (false, STRIKE, Outcome::No),
            (false, STRIKE - 1, Outcome::Yes),
            (false, STRIKE + 1, Outcome::No),
        ] {
            let (mut o, k) = price_oracle(above);
            let sigs = signed_by(&[&k[0], &k[1]], 0, &rule(above), price);
            submit(&mut o, OBS, price, &sigs);
            assert_eq!(
                o.case(&acct(MARKET), 0).proposed,
                expected,
                "above={above} price={price}"
            );
        }
    }

    #[test]
    fn a_publisher_that_was_down_at_the_observation_time_can_sign_it_later() {
        let (mut o, k) = price_oracle(true);
        let sigs = signed_by(&[&k[0], &k[1]], 0, &rule(true), 900);
        submit(&mut o, OBS + 5_000_000_000, 900, &sigs);
        assert_eq!(o.case(&acct(MARKET), 0).proposed, Outcome::No);
    }

    #[test]
    #[should_panic(expected = "the observation time has not come")]
    fn a_price_cannot_be_submitted_before_its_observation_time() {
        let (mut o, k) = price_oracle(true);
        let sigs = signed_by(&[&k[0], &k[1]], 0, &rule(true), 1_250);
        submit(&mut o, OBS - 1, 1_250, &sigs);
    }

    #[test]
    #[should_panic(expected = "not enough valid publisher signatures")]
    fn one_signature_is_not_enough_when_two_must_sign() {
        let (mut o, k) = price_oracle(true);
        let sigs = signed_by(&[&k[0]], 0, &rule(true), 1_250);
        submit(&mut o, OBS, 1_250, &sigs);
    }

    #[test]
    #[should_panic(expected = "a publisher signed twice")]
    fn one_publisher_signing_twice_does_not_count_twice() {
        let (mut o, k) = price_oracle(true);
        let sigs = signed_by(&[&k[0], &k[0]], 0, &rule(true), 1_250);
        submit(&mut o, OBS, 1_250, &sigs);
    }

    #[test]
    #[should_panic(expected = "not a publisher")]
    fn a_signature_from_a_key_that_is_not_a_publisher_is_refused() {
        let (mut o, k) = price_oracle(true);
        let sigs = signed_by(&[&k[0], &signing_key(99)], 0, &rule(true), 1_250);
        submit(&mut o, OBS, 1_250, &sigs);
    }

    // Each of these signs something that is not exactly this market, moment, price or contract.
    fn assert_refused_when_signed_over(signed: impl Fn(&AccountId) -> String, price_submitted: u128) {
        let (mut o, k) = price_oracle(true);
        act_as(VERIFIER, 0);
        let contract = env::current_account_id();
        let message = signed(&contract);
        let sigs = vec![entry(&k[0], &message), entry(&k[1], &message)];
        let outcome = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            submit(&mut o, OBS, price_submitted, &sigs)
        }));
        assert!(
            outcome.is_err(),
            "a signature over {message} must not open a case for price {price_submitted}"
        );
        assert!(o.get_case_of(&acct(MARKET), 0).is_none());
    }

    #[test]
    fn a_signature_is_good_for_one_price_of_one_market_on_one_network_and_one_contract_only() {
        let r = rule(true);
        assert_refused_when_signed_over(|c| price_message(c, NETWORK, &acct(MARKET), 1, &r, 1_250), 1_250); // another market id
        assert_refused_when_signed_over(
            |c| price_message(c, NETWORK, &acct("other-market.near"), 0, &r, 1_250),
            1_250,
        ); // another market account
        assert_refused_when_signed_over(|c| price_message(c, "mainnet", &acct(MARKET), 0, &r, 1_250), 1_250); // another network
        assert_refused_when_signed_over(
            |_| price_message(&acct("other.near"), NETWORK, &acct(MARKET), 0, &r, 1_250),
            1_250,
        ); // another contract
        assert_refused_when_signed_over(
            |c| {
                price_message(
                    c,
                    NETWORK,
                    &acct(MARKET),
                    0,
                    &PriceRule {
                        observation_time: U64(OBS + 1),
                        ..r
                    },
                    1_250,
                )
            },
            1_250,
        ); // another moment
        assert_refused_when_signed_over(
            |c| price_message(c, NETWORK, &acct(MARKET), 0, &PriceRule { decimals: 8, ..r }, 1_250),
            1_250,
        ); // other decimals
        assert_refused_when_signed_over(|c| price_message(c, NETWORK, &acct(MARKET), 0, &r, 1_250), 1_251);
        // a different price than was signed
    }

    #[test]
    #[should_panic(expected = "a price market is answered with a signed price")]
    fn a_price_market_cannot_be_answered_with_a_plain_proposal() {
        let (mut o, _) = price_oracle(true);
        act_as(VERIFIER, OBS);
        deliver(&mut o, "carol.near", BOND, "propose:market.near:0:yes:https://x");
    }

    #[test]
    #[should_panic(expected = "not a price market")]
    fn an_event_market_does_not_take_a_signed_price() {
        let (mut o, k) = price_oracle(true);
        act_as(MARKET, 0);
        o.register_market(U64(1), U64(OBS), U64(OBS + MIN_GAP), "hash".to_string(), None);
        let sigs = signed_by(&[&k[0], &k[1]], 1, &rule(true), 1_250);
        act_as(VERIFIER, OBS);
        deliver(
            &mut o,
            "carol.near",
            BOND,
            &format!("price:market.near:1:1250:{}", sigs.join(",")),
        );
    }

    #[test]
    #[should_panic(expected = "not enough price publishers are configured")]
    fn a_price_market_cannot_register_before_enough_publishers_exist() {
        let mut o = oracle_with(BOND, 2);
        act_as(OWNER, 0);
        o.add_publisher(public(&signing_key(1)));
        act_as(MARKET, 0);
        o.register_market(
            U64(0),
            U64(OBS),
            U64(OBS + MIN_GAP),
            "hash".to_string(),
            Some(rule(true)),
        );
    }

    #[test]
    fn a_price_market_is_measured_from_its_observation_time_not_its_close() {
        let mut o = oracle_with(BOND, 1);
        act_as(OWNER, 0);
        o.add_publisher(public(&signing_key(1)));
        act_as(MARKET, 0);
        // Closes at 0 and is observed a day later, so a gap measured from the close would be huge.
        let obs = 86_400_000_000_000;
        let late = PriceRule {
            observation_time: U64(obs),
            ..rule(true)
        };
        o.register_market(U64(0), U64(0), U64(obs + MIN_GAP), "hash".to_string(), Some(late));
        assert!(o.get_market_info(acct(MARKET), U64(0)).is_some());
        let caught = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            o.register_market(U64(1), U64(0), U64(obs + MIN_GAP - 1), "hash".to_string(), Some(late));
        }));
        assert!(
            caught.is_err(),
            "one nanosecond short of the gap after the observation is refused"
        );
    }

    // ---- price markets: who manages the publishers ---------------------------------------------------

    #[test]
    #[should_panic(expected = "owner only")]
    fn the_operator_cannot_add_a_publisher() {
        let (mut o, _) = price_oracle(true);
        act_as(OPERATOR, 1);
        o.add_publisher(public(&signing_key(50)));
    }

    #[test]
    #[should_panic(expected = "owner only")]
    fn the_operator_cannot_change_how_many_must_sign() {
        let (mut o, _) = price_oracle(true);
        act_as(OPERATOR, 1);
        o.set_price_threshold(3);
    }

    #[test]
    #[should_panic(expected = "owner only")]
    fn the_operator_cannot_appoint_a_new_operator() {
        let (mut o, _) = price_oracle(true);
        act_as(OPERATOR, 1);
        o.set_operator(acct("someone.near"));
    }

    #[test]
    fn the_operator_cuts_off_a_publisher_at_once_but_never_below_the_threshold() {
        let (mut o, k) = price_oracle(true);
        act_as(OPERATOR, 1);
        o.remove_publisher(public(&k[2]));
        assert_eq!(o.publishers.len(), 2);
        // The two left are exactly the two that must sign. Removing another would leave no price able to pass.
        let caught = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| o.remove_publisher(public(&k[1]))));
        assert!(caught.is_err());
        assert_eq!(o.publishers.len(), 2);
    }

    #[test]
    #[should_panic(expected = "operator or owner only")]
    fn a_stranger_cannot_remove_a_publisher() {
        let (mut o, k) = price_oracle(true);
        act_as("stranger.near", 1);
        o.remove_publisher(public(&k[0]));
    }

    #[test]
    #[should_panic(expected = "not a publisher")]
    fn removing_someone_who_is_not_a_publisher_is_refused() {
        let (mut o, _) = price_oracle(true);
        act_as(OPERATOR, 1);
        o.remove_publisher(public(&signing_key(77)));
    }

    #[test]
    fn a_removed_publisher_can_no_longer_sign_a_price() {
        let (mut o, k) = price_oracle(true);
        act_as(OPERATOR, 1);
        o.remove_publisher(public(&k[0]));
        let sigs = signed_by(&[&k[0], &k[1]], 0, &rule(true), 1_250);
        let caught = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| submit(&mut o, OBS, 1_250, &sigs)));
        assert!(caught.is_err());
    }

    #[test]
    #[should_panic(expected = "already a publisher")]
    fn the_same_key_cannot_be_added_twice() {
        let (mut o, k) = price_oracle(true);
        act_as(OWNER, 1);
        o.add_publisher(public(&k[0]));
    }

    #[test]
    #[should_panic(expected = "publishers use ed25519 keys")]
    fn only_ed25519_keys_can_be_publishers() {
        let (mut o, _) = price_oracle(true);
        act_as(OWNER, 1);
        o.add_publisher(PublicKey::from_parts(CurveType::SECP256K1, vec![1; 64]).unwrap());
    }

    #[test]
    #[should_panic(expected = "there can be at most 10 publishers")]
    fn there_can_be_at_most_ten_publishers() {
        let (mut o, _) = price_oracle(true);
        act_as(OWNER, 1);
        for seed in 10..20 {
            add_publisher_keeping_majority(&mut o, public(&signing_key(seed)));
        }
    }

    #[test]
    fn the_owner_sets_how_many_must_sign_within_the_publishers_there_are() {
        let (mut o, _) = price_oracle(true);
        act_as(OWNER, 1);
        o.set_price_threshold(3);
        assert_eq!(o.config()["price_threshold"], 3);
        let caught = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| o.set_price_threshold(4)));
        assert!(caught.is_err(), "more than the publishers there are");
        let caught = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| o.set_price_threshold(0)));
        assert!(caught.is_err(), "nobody signing at all");
    }

    #[test]
    fn a_market_with_exactly_the_minimum_gap_registers() {
        let mut o = fresh_oracle();
        act_as(MARKET, 0);
        o.register_market(U64(0), U64(1_000), U64(1_000 + MIN_GAP), "hash".to_string(), None);
        assert!(o.get_market_info(acct(MARKET), U64(0)).is_some());
        assert_eq!(o.config()["min_resolve_gap_ns"], MIN_GAP.to_string());
    }

    #[test]
    #[should_panic(expected = "resolve_by is too soon after close_at for a case to finish")]
    fn a_market_one_nanosecond_short_of_the_minimum_gap_is_refused() {
        let mut o = fresh_oracle();
        act_as(MARKET, 0);
        o.register_market(U64(0), U64(1_000), U64(1_000 + MIN_GAP - 1), "hash".to_string(), None);
    }

    #[test]
    #[should_panic(expected = "resolve_by is too soon after close_at for a case to finish")]
    fn a_market_that_resolves_before_it_closes_is_refused_without_overflow() {
        let mut o = fresh_oracle();
        act_as(MARKET, 0);
        o.register_market(U64(0), U64(1_000_000), U64(5), "hash".to_string(), None);
    }

    #[test]
    #[should_panic(expected = "too late to propose, the market will be voided at its deadline")]
    fn a_proposal_is_refused_with_exactly_zero_slack_for_apply_to_land() {
        let mut o = oracle_with_resolve_by(CASE_SPAN);
        act_as(VERIFIER, 0);
        deliver(&mut o, "carol.near", BOND, "propose:market.near:0:yes:https://x");
    }

    #[test]
    fn a_proposal_is_accepted_with_exactly_apply_buffer_of_slack() {
        let mut o = oracle_with_resolve_by(CASE_SPAN + APPLY_BUFFER_NS);
        act_as(VERIFIER, 0);
        deliver(&mut o, "carol.near", BOND, "propose:market.near:0:yes:https://x");
        assert_eq!(
            o.case(&acct(MARKET), 0).stage,
            Stage::Proposed,
            "exactly the buffer's worth of slack is accepted"
        );
    }

    #[test]
    #[should_panic(expected = "too late to propose, the market will be voided at its deadline")]
    fn a_proposal_is_refused_one_nanosecond_short_of_the_buffer() {
        let mut o = oracle_with_resolve_by(CASE_SPAN + APPLY_BUFFER_NS - 1);
        act_as(VERIFIER, 0);
        deliver(&mut o, "carol.near", BOND, "propose:market.near:0:yes:https://x");
    }

    // ---- code: staging, upgrade, migrate and seal ---------------------------------------------------------

    const WASM: &[u8] = &[0, 97, 115, 109, 1, 0, 0, 0, 9, 9, 9];
    const KEY: &str = "ed25519:6E8sCci9badyRkXb3JoRpBj5p8C6Tw41ELDZoiihKEtp";
    const SELF: &str = "alice.near";

    fn stage_wasm(o: &mut OracleContract, deposit: NearToken) -> Base58CryptoHash {
        let mut builder = VMContextBuilder::new();
        builder
            .predecessor_account_id(acct("anyone.near"))
            .attached_deposit(deposit);
        builder.context.input = WASM.to_vec().into();
        testing_env!(builder.build());
        o.stage_code()
    }

    fn staged(o: &mut OracleContract) -> Base58CryptoHash {
        stage_wasm(o, NearToken::from_near(5))
    }

    fn receipts() -> Vec<near_sdk::mock::Receipt> {
        near_sdk::test_utils::get_created_receipts()
    }

    #[test]
    #[should_panic(expected = "attach at least")]
    fn staging_with_too_little_deposit_is_refused() {
        let mut o = fresh_oracle();
        stage_wasm(&mut o, NearToken::from_yoctonear(1));
    }

    #[test]
    #[should_panic(expected = "owner only")]
    fn a_stranger_cannot_upgrade() {
        let mut o = fresh_oracle();
        let hash = staged(&mut o);
        act_unpaid("stranger.near", 5);
        let _ = o.upgrade(hash);
    }

    #[test]
    #[should_panic(expected = "owner only")]
    fn the_operator_cannot_upgrade() {
        let mut o = fresh_oracle();
        let hash = staged(&mut o);
        act_unpaid(OPERATOR, 5);
        let _ = o.upgrade(hash);
    }

    #[test]
    #[should_panic(expected = "no code is staged under that hash")]
    fn an_upgrade_to_a_hash_nobody_staged_is_refused() {
        let mut o = fresh_oracle();
        act_unpaid(OWNER, 5);
        let _ = o.upgrade(Base58CryptoHash::from([5u8; 32]));
    }

    #[test]
    #[should_panic(expected = "attach at least 100 TGas to upgrade")]
    fn an_upgrade_with_too_little_gas_is_refused_and_says_how_much() {
        let mut o = fresh_oracle();
        let hash = staged(&mut o);
        testing_env!(VMContextBuilder::new()
            .predecessor_account_id(acct(OWNER))
            .prepaid_gas(Gas::from_tgas(99))
            .build());
        let _ = o.upgrade(hash);
    }

    #[test]
    fn the_owner_deploys_the_staged_code_and_migrates_in_one_batch_and_the_copy_is_removed() {
        let mut o = fresh_oracle();
        let hash = staged(&mut o);
        assert!(o.is_staged(hash));
        act_unpaid(OWNER, 5);
        let _ = o.upgrade(hash);
        assert!(!o.is_staged(hash), "the staged copy is gone");
        let batch = &receipts()[0];
        assert_eq!(batch.receiver_id.as_str(), SELF);
        assert!(matches!(&batch.actions[0], near_sdk::mock::MockAction::DeployContract { code, .. } if code == WASM));
        assert!(
            matches!(&batch.actions[1], near_sdk::mock::MockAction::FunctionCallWeight { method_name, .. } if method_name == b"migrate")
        );
    }

    #[test]
    #[should_panic(expected = "prove the upgrade path before deleting keys")]
    fn seal_is_refused_until_an_upgrade_has_gone_through() {
        let mut o = fresh_oracle();
        act_unpaid(OWNER, 5);
        let _ = o.seal(KEY.parse().unwrap());
    }

    #[test]
    #[should_panic(expected = "owner only")]
    fn a_stranger_cannot_seal() {
        let mut o = fresh_oracle();
        o.upgrade_proven = true;
        act_unpaid("stranger.near", 5);
        let _ = o.seal(KEY.parse().unwrap());
    }

    #[test]
    fn once_proven_the_owner_deletes_a_key() {
        let mut o = fresh_oracle();
        o.upgrade_proven = true;
        act_unpaid(OWNER, 5);
        let _ = o.seal(KEY.parse().unwrap());
        assert!(
            matches!(&receipts()[0].actions[0], near_sdk::mock::MockAction::DeleteKey { public_key, .. } if public_key.to_string() == KEY)
        );
    }

    #[test]
    fn migrate_keeps_markets_and_cases_and_marks_the_upgrade_proven() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        assert!(!o.upgrade_proven);
        o.upgrade_in_flight = true;
        env::state_write(&o);
        drop(o);
        act_unpaid(SELF, 5);
        let migrated = OracleContract::migrate();
        assert_eq!(
            (
                migrated.upgrade_proven,
                migrated.upgrade_in_flight,
                migrated.state_version
            ),
            (true, false, STATE_VERSION)
        );
        assert_eq!(migrated.case(&acct(MARKET), 0).stage, Stage::Disputed);
        assert_eq!(migrated.config()["upgrade_proven"], true);
    }

    #[test]
    #[should_panic(expected = "migrate runs only inside an upgrade")]
    fn migrate_called_by_hand_is_refused_and_proves_nothing() {
        let o = fresh_oracle();
        env::state_write(&o);
        drop(o);
        act_unpaid(SELF, 5);
        OracleContract::migrate();
    }

    #[test]
    fn upgrade_marks_the_upgrade_in_flight_and_a_second_one_sets_it_again() {
        let mut o = fresh_oracle();
        let hash = staged(&mut o);
        assert!(!o.upgrade_in_flight);
        act_unpaid(OWNER, 5);
        let _ = o.upgrade(hash);
        assert!(o.upgrade_in_flight);
        assert_eq!(o.config()["upgrade_in_flight"], true);
        o.upgrade_in_flight = false;
        let again = staged(&mut o);
        act_unpaid(OWNER, 6);
        let _ = o.upgrade(again);
        assert!(o.upgrade_in_flight, "the next upgrade sets it again");
    }

    #[test]
    #[should_panic(expected = "unsupported state version")]
    fn migrate_refuses_state_written_by_another_version() {
        let mut o = fresh_oracle();
        o.state_version = 1;
        env::state_write(&o);
        drop(o);
        act_unpaid(SELF, 5);
        OracleContract::migrate();
    }

    // The state a version-2 contract wrote, with the draw delay it had when the upgrade came.
    const DELAY_AT_MIGRATION: u64 = 9;

    fn state_v2_of(o: &OracleContract) -> StateV2 {
        StateV2 {
            state_version: 2,
            upgrade_proven: false,
            upgrade_in_flight: true,
            owner: o.owner.clone(),
            pending_owner: None,
            operator: o.operator.clone(),
            allowed_markets: o.allowed_markets.clone(),
            verifier: o.verifier.clone(),
            collateral_token_id: o.collateral_token_id.clone(),
            bond: o.bond,
            window_ns: o.window_ns,
            apply_buffer_ns: o.apply_buffer_ns,
            juror_share_bps: o.juror_share_bps,
            no_decision_share_bps: o.no_decision_share_bps,
            max_publishers: o.max_publishers,
            panel_deadline_ns: o.panel_deadline_ns,
            draw_window_ns: o.draw_window_ns,
            min_proposal_ns: o.min_proposal_ns,
            council: o.council.clone(),
            jury_size: o.jury_size,
            draw_delay_blocks: DELAY_AT_MIGRATION,
            network: o.network.clone(),
            publishers: o.publishers.clone(),
            price_threshold: o.price_threshold,
            no_decision_recipient: o.no_decision_recipient.clone(),
            markets: LookupMap::new(Key::Markets),
            cases: LookupMap::new(Key::Cases),
            last_case_uid: 1,
            claimable: LookupMap::new(Key::Claimable),
            claimable_total: 0,
            bonds_held: BOND,
            payouts: LookupMap::new(Key::Payouts),
            pending_payouts_total: 0,
            reconcile_wait_ns: o.reconcile_wait_ns,
            last_payout_id: 0,
        }
    }

    fn migrate_old_state(old: StateV2) -> OracleContract {
        env::state_write(&old);
        act_unpaid(SELF, 5);
        OracleContract::migrate()
    }

    #[test]
    fn migrate_moves_version_two_state_to_three_and_old_cases_take_the_delay_at_migration() {
        let case = proposed_case();
        let o = oracle_with_resolve_by(MARKET_DEADLINE);
        let mut key = current_bytes(&Key::Cases);
        key.extend(current_bytes(&(acct(MARKET), 0u64)));
        env::storage_write(&key, &old_case_bytes(&case));
        let old = state_v2_of(&o);
        drop(o);
        let mut migrated = migrate_old_state(old);
        assert_eq!(migrated.state_version, STATE_VERSION);
        assert_eq!(migrated.old_case_draw_delay_blocks, DELAY_AT_MIGRATION);
        assert_eq!((migrated.bond, migrated.jury_size), (BOND, TEST_JURY_SIZE));
        assert!(migrated.upgrade_proven && !migrated.upgrade_in_flight);

        let stored = migrated.case(&acct(MARKET), 0);
        assert_eq!(stored.draw_delay_blocks, None);
        assert_eq!(stored.jury_size, TEST_JURY_SIZE);
        act_unpaid(OWNER, 6);
        migrated.set_draw_delay_blocks(U64(1));
        assert_eq!(
            migrated.draw_delay_of(&stored),
            DELAY_AT_MIGRATION,
            "an owner change after the upgrade does not reach the old case"
        );
        act_as(VERIFIER, CHALLENGED_AT);
        deliver(&mut migrated, "dave.near", BOND, "challenge:market.near:0:no");
        assert_eq!(migrated.case(&acct(MARKET), 0).draw_after_height.0, DELAY_AT_MIGRATION);
    }

    #[test]
    #[should_panic(expected = "the bond must be at least 5 USDC")]
    fn migrate_refuses_a_version_two_state_with_a_bond_below_the_floor() {
        let o = fresh_oracle();
        let mut old = state_v2_of(&o);
        old.bond = MIN_BOND - 1;
        drop(o);
        migrate_old_state(old);
    }

    #[test]
    fn migrate_refuses_a_version_two_state_with_a_window_below_the_floor() {
        for lower in [
            |s: &mut StateV2| s.window_ns = MIN_WINDOW_MS * NS_PER_MS - 1,
            |s: &mut StateV2| s.panel_deadline_ns = MIN_WINDOW_MS * NS_PER_MS - 1,
            |s: &mut StateV2| s.draw_window_ns = MIN_WINDOW_MS * NS_PER_MS - 1,
            |s: &mut StateV2| s.min_proposal_ns = MIN_WINDOW_MS * NS_PER_MS - 1,
        ] {
            let o = fresh_oracle();
            let mut old = state_v2_of(&o);
            drop(o);
            lower(&mut old);
            let message = refusal(|| drop(migrate_old_state(old)));
            assert!(message.contains("windows must be at least an hour"), "{message}");
        }
    }

    #[test]
    #[should_panic(expected = "jury size must be odd, from 5 to 21")]
    fn migrate_refuses_a_version_two_state_with_a_jury_below_the_floor() {
        let o = fresh_oracle();
        let mut old = state_v2_of(&o);
        old.jury_size = MIN_JURY_SIZE - 2;
        drop(o);
        migrate_old_state(old);
    }

    #[test]
    #[should_panic(expected = "the bond must be at least 5 USDC")]
    fn migrate_refuses_a_current_state_below_the_floors_too() {
        let mut o = fresh_oracle();
        o.upgrade_in_flight = true;
        o.bond = MIN_BOND - 1;
        env::state_write(&o);
        drop(o);
        act_unpaid(SELF, 5);
        OracleContract::migrate();
    }

    // ---- the owner's settings ---------------------------------------------------------------------------

    type Setter = fn(&mut OracleContract, u64);
    // A value each setter takes that is not the default, and the delay's own.
    const SETTER_WINDOW_MS: u64 = 2 * MIN_WINDOW_MS;
    const SETTER_DELAY_BLOCKS: u64 = 7;
    // (name, setter, the config key it changes, the event it emits, a value to set, the least value it takes)
    const SETTERS: [(&str, Setter, &str, &str, u64, u64); 6] = [
        (
            "set_bond",
            |o, v| o.set_bond(U128(v as u128)),
            "bond",
            "bond_set",
            2 * MIN_BOND as u64,
            MIN_BOND as u64,
        ),
        (
            "set_window_ms",
            |o, v| o.set_window_ms(U64(v)),
            "window_ns",
            "window_set",
            SETTER_WINDOW_MS,
            MIN_WINDOW_MS,
        ),
        (
            "set_panel_deadline_ms",
            |o, v| o.set_panel_deadline_ms(U64(v)),
            "panel_deadline_ns",
            "panel_deadline_set",
            SETTER_WINDOW_MS,
            MIN_WINDOW_MS,
        ),
        (
            "set_min_proposal_ms",
            |o, v| o.set_min_proposal_ms(U64(v)),
            "min_proposal_ns",
            "min_proposal_set",
            SETTER_WINDOW_MS,
            MIN_WINDOW_MS,
        ),
        (
            "set_draw_window_ms",
            |o, v| o.set_draw_window_ms(U64(v)),
            "draw_window_ns",
            "draw_window_set",
            SETTER_WINDOW_MS,
            MIN_WINDOW_MS,
        ),
        (
            "set_draw_delay_blocks",
            |o, v| o.set_draw_delay_blocks(U64(v)),
            "draw_delay_blocks",
            "draw_delay_set",
            SETTER_DELAY_BLOCKS,
            0,
        ),
    ];

    // The config value a setter shows after it took `value`: windows are shown in nanoseconds.
    fn shown_after(key: &str, value: u64) -> String {
        if key.ends_with("_ns") {
            (value * NS_PER_MS).to_string()
        } else {
            value.to_string()
        }
    }

    fn refusal(f: impl FnOnce()) -> String {
        let err = std::panic::catch_unwind(std::panic::AssertUnwindSafe(f)).expect_err("expected a refusal");
        err.downcast_ref::<String>()
            .cloned()
            .or_else(|| err.downcast_ref::<&str>().map(|s| s.to_string()))
            .unwrap_or_default()
    }

    #[test]
    fn every_setting_refuses_a_stranger_and_the_operator() {
        let mut o = fresh_oracle();
        for who in ["stranger.near", OPERATOR] {
            for (name, set, _, _, value, _) in SETTERS {
                act_unpaid(who, 5);
                assert!(refusal(|| set(&mut o, value)).contains("owner only"), "{name} by {who}");
            }
        }
    }

    #[test]
    fn every_setting_but_the_draw_delay_refuses_a_value_below_its_floor_and_takes_the_floor() {
        let mut o = fresh_oracle();
        for (name, set, key, _, _, floor) in &SETTERS[..5] {
            for below in [0, floor - 1] {
                act_unpaid(OWNER, 5);
                let message = refusal(|| set(&mut o, below));
                assert!(message.contains("at least"), "{name} at {below}: {message}");
            }
            act_unpaid(OWNER, 5);
            set(&mut o, *floor);
            assert_eq!(o.config()[key], shown_after(key, *floor), "{name} takes its floor");
        }
    }

    #[test]
    fn the_floors_are_an_hour_five_jurors_and_five_usdc() {
        assert_eq!(MIN_WINDOW_MS, 3_600 * 1_000);
        assert_eq!(MIN_JURY_SIZE, 5);
        assert_eq!(MIN_BOND, 5 * 1_000_000);
    }

    #[test]
    fn every_setting_changes_its_value_and_emits_its_event() {
        let mut o = fresh_oracle();
        for (name, set, key, event, value, _) in SETTERS {
            act_unpaid(OWNER, 5);
            set(&mut o, value);
            assert_eq!(o.config()[key], shown_after(key, value), "{name}");
            assert!(
                near_sdk::test_utils::get_logs().iter().any(|l| l.contains(event)),
                "{name} emits {event}"
            );
        }
    }

    #[test]
    fn a_market_registered_before_a_setting_change_keeps_its_windows_and_one_registered_after_uses_the_new_ones() {
        let mut o = fresh_oracle();
        act_as(MARKET, 0);
        o.register_market(U64(0), U64(1_000), U64(1_000 + MIN_GAP), "hash".to_string(), None);
        act_unpaid(OWNER, 1);
        o.set_window_ms(U64(10 * WINDOW_MS));
        o.set_panel_deadline_ms(U64(10 * PANEL_MS));
        o.set_draw_window_ms(U64(10 * WINDOW_MS));
        assert_ne!(
            o.config()["min_resolve_gap_ns"],
            MIN_GAP.to_string(),
            "the longer settings raise the gap new markets need"
        );
        act_as(MARKET, 2);
        o.register_market(U64(1), U64(1_000), U64(1_000 + 20 * MIN_GAP), "hash".to_string(), None);

        let (old, new) = (o.market_info(&acct(MARKET), 0), o.market_info(&acct(MARKET), 1));
        assert_eq!(
            (old.window_ns.0, old.draw_window_ns.0, old.panel_deadline_ns.0),
            (WINDOW, DRAW_WINDOW, PANEL)
        );
        assert_eq!(
            (new.window_ns.0, new.draw_window_ns.0, new.panel_deadline_ns.0),
            (10 * WINDOW, 10 * DRAW_WINDOW, 10 * PANEL)
        );

        // The old market still fits a whole case in its time, and every deadline of the case is on the old windows.
        act_as(VERIFIER, 1_000);
        deliver(&mut o, "carol.near", BOND, "propose:market.near:0:yes:https://x");
        assert_eq!(o.case(&acct(MARKET), 0).window_ends_at.0, 1_000 + WINDOW);
        act_as(VERIFIER, 1_001);
        deliver(&mut o, "dave.near", BOND, "challenge:market.near:0:no");
        assert_eq!(o.case(&acct(MARKET), 0).draw_by.0, 1_001 + DRAW_WINDOW);
        seat(&mut o, 1_002, &names(FIRST_JURORS, "j"));
        let case = o.case(&acct(MARKET), 0);
        assert_eq!(
            (case.commit_ends_at.0, case.panel_deadline.0),
            (1_002 + PANEL / 2, 1_002 + PANEL)
        );

        // The new market runs on the new windows.
        act_as(VERIFIER, 1_000);
        deliver(&mut o, "carol.near", BOND, "propose:market.near:1:yes:https://x");
        assert_eq!(o.case(&acct(MARKET), 1).window_ends_at.0, 1_000 + 10 * WINDOW);
    }

    #[test]
    fn a_round_two_draw_on_an_old_market_gets_the_old_draw_window() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        act_unpaid(OWNER, 3);
        o.set_draw_window_ms(U64(10 * WINDOW_MS));
        o.set_panel_deadline_ms(U64(10 * PANEL_MS));
        act_as("anyone.near", QUEUE_OVER);
        o.finalize(acct(MARKET), U64(0));
        let case = o.case(&acct(MARKET), 0);
        assert_eq!((case.round, case.draw_by.0), (1, QUEUE_OVER + DRAW_WINDOW));
    }

    // ---- the bond ---------------------------------------------------------------------------------------

    const NEW_BOND: u128 = 2 * MIN_BOND;

    #[test]
    fn a_new_bond_applies_to_new_cases_and_a_challenge_matches_the_bond_its_case_was_proposed_with() {
        let mut o = fresh_oracle();
        o.put_market(
            0,
            MarketInfo {
                resolve_by: U64(MARKET_DEADLINE),
                ..base_info()
            },
        );
        o.put_market(
            1,
            MarketInfo {
                resolve_by: U64(MARKET_DEADLINE),
                ..base_info()
            },
        );
        act_as(VERIFIER, SECOND);
        deliver(&mut o, "carol.near", BOND, "propose:market.near:0:yes:https://x");
        act_unpaid(OWNER, 2 * SECOND);
        o.set_bond(U128(NEW_BOND));
        assert_eq!(o.case(&acct(MARKET), 0).bond.0, BOND, "the open case keeps its bond");

        act_as(VERIFIER, 3 * SECOND);
        assert!(refusal(|| {
            deliver(&mut o, "dave.near", NEW_BOND, "challenge:market.near:0:no");
        })
        .contains("send exactly the bond"));
        deliver(&mut o, "dave.near", BOND, "challenge:market.near:0:no");
        assert_eq!(o.case(&acct(MARKET), 0).stage, Stage::Disputed);

        act_as(VERIFIER, 4 * SECOND);
        assert!(refusal(|| {
            deliver(&mut o, "carol.near", BOND, "propose:market.near:1:yes:https://x");
        })
        .contains("send exactly the bond"));
        deliver(&mut o, "carol.near", NEW_BOND, "propose:market.near:1:yes:https://x");
        assert_eq!(o.case(&acct(MARKET), 1).bond.0, NEW_BOND);
    }

    #[test]
    fn a_settled_case_pays_the_bond_it_was_proposed_with_not_the_current_one() {
        let mut o = fresh_oracle();
        o.put_market(
            0,
            MarketInfo {
                resolve_by: U64(MARKET_DEADLINE),
                ..base_info()
            },
        );
        act_as(VERIFIER, SECOND);
        deliver(&mut o, "carol.near", BOND, "propose:market.near:0:yes:https://x");
        act_unpaid(OWNER, 2 * SECOND);
        o.set_bond(U128(NEW_BOND));
        act_as("anyone.near", SECOND + WINDOW);
        o.finalize(acct(MARKET), U64(0));
        assert_eq!(owed(&o, "carol.near"), BOND);
    }

    // ---- money through the verifier ---------------------------------------------------------------------------

    fn logged(event: &str) -> Vec<near_sdk::serde_json::Value> {
        near_sdk::test_utils::get_logs()
            .iter()
            .filter_map(|l| l.strip_prefix("EVENT_JSON:"))
            .map(|j| near_sdk::serde_json::from_str::<near_sdk::serde_json::Value>(j).unwrap())
            .filter(|e| e["event"] == event)
            .map(|e| e["data"].clone())
            .collect()
    }

    // Runs the payout callback for `id` as the contract itself, as the verifier's answer would.
    fn settle(o: &mut OracleContract, id: u64, paid: bool) {
        act_as(OWNER, 10 * DEADLINE);
        o.on_bond_withdrawn(U64(id), if paid { Ok(()) } else { Err(PromiseError::Failed) });
    }

    // The verifier call a payout sent: its arguments, the yocto attached and the gas reserved.
    fn mt_transfer_sent() -> (near_sdk::serde_json::Value, u128, u64) {
        let sent = receipts();
        assert_eq!(sent[0].receiver_id, acct(VERIFIER));
        match &sent[0].actions[0] {
            near_sdk::mock::MockAction::FunctionCallWeight {
                method_name,
                args,
                attached_deposit,
                prepaid_gas,
                ..
            } => {
                assert_eq!(method_name.as_slice(), b"mt_transfer");
                (
                    near_sdk::serde_json::from_slice(args).unwrap(),
                    attached_deposit.as_yoctonear(),
                    prepaid_gas.as_gas(),
                )
            }
            other => panic!("not a function call: {other:?}"),
        }
    }

    // Market 0 is open for answers. Carol puts her bond in through the hook at one second and nobody challenges, so it is
    // hers to withdraw once anyone finalizes.
    fn unchallenged_and_final() -> OracleContract {
        let mut o = oracle_with_bond(BOND);
        o.put_market(
            0,
            MarketInfo {
                resolve_by: U64(MARKET_DEADLINE),
                ..base_info()
            },
        );
        act_as(VERIFIER, SECOND);
        deliver(&mut o, "carol.near", BOND, "propose:market.near:0:yes:https://x");
        act_as("anyone.near", SECOND + WINDOW);
        o.finalize(acct(MARKET), U64(0));
        o
    }

    #[test]
    fn a_bond_from_the_verifier_is_kept_in_full_and_counted_as_owed() {
        let mut o = oracle_with_bond(BOND);
        o.put_market(
            0,
            MarketInfo {
                resolve_by: U64(MARKET_DEADLINE),
                ..base_info()
            },
        );
        act_as(VERIFIER, SECOND);
        assert_eq!(
            deliver(&mut o, "carol.near", BOND, "propose:market.near:0:yes:https://x"),
            vec![U128(0)]
        );
        assert_eq!(o.case(&acct(MARKET), 0).proposer, acct("carol.near"));
        assert_eq!((o.total_owed().0, o.bonds_held, o.claimable_total), (BOND, BOND, 0));
        act_as(VERIFIER, CHALLENGED_AT);
        assert_eq!(
            deliver(&mut o, "dave.near", BOND, "challenge:market.near:0:no"),
            vec![U128(0)]
        );
        assert_eq!(o.case(&acct(MARKET), 0).challenger, Some(acct("dave.near")));
        assert_eq!(
            (o.total_owed().0, o.bonds_held, o.claimable_total),
            (2 * BOND, 2 * BOND, 0)
        );
    }

    #[test]
    fn a_bond_from_anyone_but_the_verifier_is_refused_and_counts_for_nothing() {
        let mut o = oracle_with_resolve_by(MARKET_DEADLINE);
        for who in ["carol.near", COUNCIL, MARKET, OWNER, OPERATOR, "stranger.near"] {
            act_as(who, SECOND);
            let message = refusal(|| {
                deliver(&mut o, "carol.near", BOND, "propose:market.near:0:yes:https://x");
            });
            assert_eq!(message, "only the verifier can deliver money", "{who}");
        }
        assert!(o.get_case_of(&acct(MARKET), 0).is_none());
        assert_eq!(o.total_owed().0, 0);
    }

    #[test]
    fn a_delivery_that_is_not_one_bond_of_the_collateral_from_the_senders_own_balance_is_refused() {
        let mut o = oracle_with_bond(BOND);
        o.put_market(
            0,
            MarketInfo {
                resolve_by: U64(MARKET_DEADLINE),
                ..base_info()
            },
        );
        let (carol, dave) = (acct("carol.near"), acct("dave.near"));
        let bond = U128(BOND);
        let msg = "propose:market.near:0:yes:https://x";
        // What is wrong, then the previous owners, token ids and amounts of the delivery, then the refusal.
        type Delivery = (&'static str, Vec<AccountId>, Vec<String>, Vec<U128>, &'static str);
        let cases: Vec<Delivery> = vec![
            (
                "another token",
                vec![carol.clone()],
                vec!["nep141:other.near".into()],
                vec![bond],
                "wrong token",
            ),
            (
                "the bare contract id",
                vec![carol.clone()],
                vec!["usdc.near".into()],
                vec![bond],
                "wrong token",
            ),
            (
                "two tokens in one delivery",
                vec![carol.clone(), carol.clone()],
                vec![COLLATERAL.into(), COLLATERAL.into()],
                vec![bond, bond],
                "exactly one token and amount",
            ),
            (
                "no token at all",
                vec![],
                vec![],
                vec![],
                "exactly one token and amount",
            ),
            (
                "one token with two amounts",
                vec![carol.clone()],
                vec![COLLATERAL.into()],
                vec![bond, bond],
                "exactly one token and amount",
            ),
            (
                "money that was somebody else's",
                vec![dave.clone()],
                vec![COLLATERAL.into()],
                vec![bond],
                "the money must come from the sender's own balance",
            ),
            (
                "no previous owner",
                vec![],
                vec![COLLATERAL.into()],
                vec![bond],
                "the money must come from the sender's own balance",
            ),
            (
                "money passed through two owners",
                vec![carol.clone(), dave.clone()],
                vec![COLLATERAL.into()],
                vec![bond],
                "the money must come from the sender's own balance",
            ),
            (
                "a zero amount",
                vec![carol.clone()],
                vec![COLLATERAL.into()],
                vec![U128(0)],
                "amount must be positive",
            ),
            (
                "an amount that is not the bond",
                vec![carol.clone()],
                vec![COLLATERAL.into()],
                vec![U128(BOND + 1)],
                "send exactly the bond",
            ),
        ];
        for (what, previous, tokens, amounts, why) in cases {
            act_as(VERIFIER, SECOND);
            let message = refusal(|| {
                let _ = o.mt_on_transfer(carol.clone(), previous, tokens, amounts, msg.to_string());
            });
            assert_eq!(message, why, "{what}");
        }
        assert!(o.get_case_of(&acct(MARKET), 0).is_none(), "nothing was proposed");
        assert_eq!(o.total_owed().0, 0, "nothing was counted");
    }

    #[test]
    fn a_message_the_hook_does_not_know_is_refused_so_the_verifier_gives_the_money_back() {
        let mut o = oracle_with_bond(BOND);
        o.put_market(
            0,
            MarketInfo {
                resolve_by: U64(MARKET_DEADLINE),
                ..base_info()
            },
        );
        for (msg, why) in [
            ("hello", "bad market account"),
            ("deposit", "bad market account"),
            ("propose:Not An Account:0:yes:https://x", "bad market account"),
            (
                "propose:other-market.near:0:yes:https://x",
                "that market contract is not allowed",
            ),
            ("propose:market.near:x:yes:https://x", "bad market id"),
            (
                "propose:market.near:0:maybe:https://x",
                "outcome must be yes, no or void",
            ),
            ("withdraw:market.near:0", "unknown action"),
            ("challenge:market.near:0:no", "no case for that market"),
        ] {
            act_as(VERIFIER, SECOND);
            let message = refusal(|| {
                deliver(&mut o, "carol.near", BOND, msg);
            });
            assert!(message.contains(why), "{msg}: {message}");
        }
        assert!(o.get_case_of(&acct(MARKET), 0).is_none());
        assert_eq!(o.total_owed().0, 0);
    }

    #[test]
    fn an_unchallenged_case_releases_its_one_bond_into_claimable() {
        let o = unchallenged_and_final();
        assert_eq!((o.total_owed().0, o.bonds_held, o.claimable_total), (BOND, 0, BOND));
        assert_eq!(owed(&o, "carol.near"), BOND);
    }

    #[test]
    fn total_owed_follows_the_bonds_through_a_dispute_and_falls_only_as_payees_withdraw() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        assert_eq!(o.total_owed().0, 2 * BOND, "both bonds are held while the case is open");
        let jurors = names(FIRST_JURORS, "j");
        seat(&mut o, DRAW_BY, &jurors);
        let majority = &jurors[..FIRST_MAJORITY];
        for j in majority {
            commit(&mut o, j, DRAW_BY + SECOND, Outcome::No, "a-long-random-salt");
        }
        for j in &majority[..FIRST_MAJORITY - 1] {
            reveal_when_open(&mut o, j, Outcome::No, "a-long-random-salt");
        }
        assert_eq!(o.total_owed().0, 2 * BOND, "a vote does not move money");
        reveal_when_open(&mut o, &majority[FIRST_MAJORITY - 1], Outcome::No, "a-long-random-salt");
        assert_eq!(o.case(&acct(MARKET), 0).stage, Stage::Final);
        assert_eq!(
            (o.total_owed().0, o.bonds_held, o.claimable_total),
            (2 * BOND, 0, 2 * BOND)
        );

        let mut left = 2 * BOND;
        let payees = ["dave.near".to_string()].into_iter().chain(majority.iter().cloned());
        for (n, who) in payees.enumerate() {
            let who = who.as_str();
            let due = owed(&o, who);
            assert!(due > 0, "{who} is owed something");
            act_as(who, 10 * DEADLINE);
            let _ = o.withdraw_bond();
            assert_eq!(
                o.total_owed().0,
                left,
                "{who}'s {due} is still owed while it is in flight"
            );
            settle(&mut o, n as u64 + 1, true);
            left -= due;
            assert_eq!(o.total_owed().0, left, "{who} took {due}");
        }
        assert_eq!(
            left, 0,
            "two bonds, paid to the winner and the majority jurors, and nobody else is owed"
        );
        assert_eq!(o.total_owed().0, 0);
    }

    #[test]
    fn a_withdrawal_is_one_mt_transfer_of_one_yocto_to_the_caller_and_to_nobody_else() {
        let mut o = unchallenged_and_final();
        act_as("stranger.near", 10 * DEADLINE);
        assert_eq!(refusal(|| drop(o.withdraw_bond())), "nothing to withdraw");
        act_as("carol.near", 10 * DEADLINE);
        let _ = o.withdraw_bond();
        let (args, deposit, gas) = mt_transfer_sent();
        assert_eq!((deposit, gas), (1, GAS_MT_TRANSFER.as_gas()));
        assert_eq!(args["receiver_id"], "carol.near");
        assert_eq!(args["token_id"], COLLATERAL);
        assert_eq!(args["amount"], BOND.to_string());
        assert_eq!((owed(&o, "carol.near"), o.total_owed().0), (0, BOND));
        settle(&mut o, 1, true);
        assert_eq!(o.total_owed().0, 0);
    }

    #[test]
    fn a_withdrawal_without_the_one_yocto_is_refused() {
        let mut o = unchallenged_and_final();
        act_unpaid("carol.near", 10 * DEADLINE);
        assert_eq!(
            refusal(|| drop(o.withdraw_bond())),
            "Requires attached deposit of exactly 1 yoctoNEAR"
        );
        assert_eq!(owed(&o, "carol.near"), BOND, "nothing was taken");
    }

    #[test]
    fn a_payout_the_verifier_refused_gives_the_balance_back_and_a_paid_one_stays_paid() {
        let mut o = unchallenged_and_final();
        act_as("carol.near", 10 * DEADLINE);
        let _ = o.withdraw_bond();
        assert_eq!((owed(&o, "carol.near"), o.total_owed().0), (0, BOND));

        settle(&mut o, 1, false);
        assert_eq!(
            (
                owed(&o, "carol.near"),
                o.total_owed().0,
                o.claimable_total,
                o.pending_payouts_total
            ),
            (BOND, BOND, BOND, 0),
            "the balance and the books are back"
        );
        assert_eq!(
            logged("bond_payout_failed"),
            vec![near_sdk::serde_json::json!({ "account": "carol.near", "amount": BOND.to_string(), "id": "1" })]
        );

        act_as("carol.near", 10 * DEADLINE);
        let _ = o.withdraw_bond();
        settle(&mut o, 2, true);
        assert_eq!((owed(&o, "carol.near"), o.total_owed().0), (0, 0));
        assert_eq!(
            logged("bond_paid"),
            vec![near_sdk::serde_json::json!({ "account": "carol.near", "amount": BOND.to_string(), "id": "2" })]
        );
        assert!(logged("bond_payout_failed").is_empty());
    }

    fn payout_json(account: &str, id: u64) -> near_sdk::serde_json::Value {
        near_sdk::serde_json::json!({ "account": account, "amount": BOND.to_string(), "id": id.to_string() })
    }

    // ---- reconcile_bond_payout: the owner decides when the callback never came ----------------------------------

    const PAID_OUT_AT: u64 = 10 * DEADLINE;
    const PAYOUT_DECIDABLE_AT: u64 = PAID_OUT_AT + DEFAULT_RECONCILE_WAIT_NS;

    // Carol's whole bond is in flight as payout 1.
    fn a_stuck_payout() -> OracleContract {
        let mut o = unchallenged_and_final();
        act_as("carol.near", PAID_OUT_AT);
        let _ = o.withdraw_bond();
        o
    }

    fn reconcile_at(o: &mut OracleContract, now: u64, paid: bool) {
        act_unpaid(OWNER, now);
        o.reconcile_bond_payout(U64(1), paid);
    }

    #[test]
    fn only_the_owner_reconciles_a_payout() {
        let mut o = a_stuck_payout();
        for who in ["stranger.near", OPERATOR, "carol.near"] {
            act_unpaid(who, PAYOUT_DECIDABLE_AT);
            assert!(
                refusal(|| o.reconcile_bond_payout(U64(1), false)).contains("owner only"),
                "{who}"
            );
        }
        assert_eq!((o.pending_payouts_total, o.total_owed().0), (BOND, BOND));
    }

    #[test]
    fn an_unknown_payout_id_is_refused() {
        let mut o = a_stuck_payout();
        act_unpaid(OWNER, PAYOUT_DECIDABLE_AT);
        for id in [0, 2, u64::MAX] {
            assert!(refusal(|| o.reconcile_bond_payout(U64(id), true)).contains("no payout is pending with that id"));
        }
    }

    #[test]
    fn a_payout_is_decided_exactly_at_the_wait_and_not_before() {
        let mut o = a_stuck_payout();
        act_unpaid(OWNER, PAYOUT_DECIDABLE_AT - 1);
        assert!(refusal(|| o.reconcile_bond_payout(U64(1), true))
            .contains("wait 60 minutes after the payout before reconciling"));
        assert_eq!(o.pending_payouts_total, BOND);
        reconcile_at(&mut o, PAYOUT_DECIDABLE_AT, true);
        assert_eq!(o.pending_payouts_total, 0);
    }

    #[test]
    fn a_payout_that_was_paid_is_dropped_and_no_longer_owed() {
        let mut o = a_stuck_payout();
        reconcile_at(&mut o, PAYOUT_DECIDABLE_AT, true);
        assert!(o.get_payout(1).is_none());
        assert_eq!(
            (o.pending_payouts_total, o.claimable_total, o.total_owed().0),
            (0, 0, 0)
        );
        assert_eq!(owed(&o, "carol.near"), 0);
        let mut event = payout_json("carol.near", 1);
        event["paid"] = near_sdk::serde_json::json!(true);
        assert_eq!(logged("bond_payout_reconciled"), vec![event]);
        assert!(logged("bond_paid").is_empty() && logged("bond_payout_failed").is_empty());
    }

    #[test]
    fn a_payout_that_never_happened_is_claimable_again() {
        let mut o = a_stuck_payout();
        reconcile_at(&mut o, PAYOUT_DECIDABLE_AT, false);
        assert!(o.get_payout(1).is_none());
        assert_eq!(
            (o.pending_payouts_total, o.claimable_total, o.total_owed().0),
            (0, BOND, BOND)
        );
        assert_eq!(owed(&o, "carol.near"), BOND);
        let mut event = payout_json("carol.near", 1);
        event["paid"] = near_sdk::serde_json::json!(false);
        assert_eq!(logged("bond_payout_reconciled"), vec![event]);
        act_as("carol.near", PAYOUT_DECIDABLE_AT + 1);
        let _ = o.withdraw_bond();
        assert_eq!((o.pending_payouts_total, o.last_payout_id), (BOND, 2));
    }

    #[test]
    fn a_payout_cannot_be_reconciled_twice() {
        let mut o = a_stuck_payout();
        reconcile_at(&mut o, PAYOUT_DECIDABLE_AT, false);
        for paid in [false, true] {
            act_unpaid(OWNER, PAYOUT_DECIDABLE_AT);
            assert!(refusal(|| o.reconcile_bond_payout(U64(1), paid)).contains("no payout is pending with that id"));
        }
        assert_eq!((owed(&o, "carol.near"), o.total_owed().0), (BOND, BOND));
    }

    #[test]
    fn a_late_callback_after_a_reconcile_changes_nothing() {
        for (paid, claimable) in [(true, 0), (false, BOND)] {
            let mut o = a_stuck_payout();
            reconcile_at(&mut o, PAYOUT_DECIDABLE_AT, paid);
            for callback_paid in [true, false] {
                settle(&mut o, 1, callback_paid);
                assert_eq!(
                    (
                        owed(&o, "carol.near"),
                        o.claimable_total,
                        o.pending_payouts_total,
                        o.total_owed().0
                    ),
                    (claimable, claimable, 0, claimable)
                );
                assert!(logged("bond_paid").is_empty() && logged("bond_payout_failed").is_empty());
            }
        }
    }

    #[test]
    fn a_withdrawal_records_the_payout_and_announces_it_before_the_callback() {
        let mut o = unchallenged_and_final();
        act_as("carol.near", 10 * DEADLINE);
        let _ = o.withdraw_bond();
        let record = o.get_payout(1).unwrap();
        assert_eq!(
            (record.account, record.amount.0, record.at.0),
            (acct("carol.near"), BOND, 10 * DEADLINE)
        );
        assert_eq!(
            (o.last_payout_id, o.pending_payouts_total, o.claimable_total),
            (1, BOND, 0)
        );
        assert_eq!(logged("bond_payout_requested"), vec![payout_json("carol.near", 1)]);
        assert!(logged("bond_paid").is_empty() && logged("bond_payout_failed").is_empty());
    }

    #[test]
    fn a_confirmed_payout_is_removed_and_reported_paid() {
        let mut o = unchallenged_and_final();
        act_as("carol.near", 10 * DEADLINE);
        let _ = o.withdraw_bond();
        settle(&mut o, 1, true);
        assert!(o.get_payout(1).is_none());
        assert_eq!(
            (o.pending_payouts_total, o.claimable_total, o.total_owed().0),
            (0, 0, 0)
        );
        assert_eq!(logged("bond_paid"), vec![payout_json("carol.near", 1)]);
    }

    #[test]
    fn a_callback_that_runs_twice_or_names_an_unknown_id_changes_nothing() {
        let mut o = unchallenged_and_final();
        act_as("carol.near", 10 * DEADLINE);
        let _ = o.withdraw_bond();
        settle(&mut o, 1, false);
        let before = (
            owed(&o, "carol.near"),
            o.claimable_total,
            o.pending_payouts_total,
            o.total_owed().0,
        );
        for (id, paid) in [(1, false), (1, true), (2, true), (0, false), (u64::MAX, false)] {
            settle(&mut o, id, paid);
            assert_eq!(
                (
                    owed(&o, "carol.near"),
                    o.claimable_total,
                    o.pending_payouts_total,
                    o.total_owed().0
                ),
                before
            );
        }
        assert!(logged("bond_paid").is_empty());
        assert!(logged("bond_payout_failed").is_empty());
    }

    #[test]
    fn two_payouts_in_flight_settle_independently() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        act_as("anyone.near", QUEUE_OVER);
        o.finalize(acct(MARKET), U64(0));
        act_as("anyone.near", QUEUE_OVER + PANEL + DRAW_WINDOW + PANEL);
        o.finalize(acct(MARKET), U64(0));
        for who in ["carol.near", "dave.near"] {
            act_as(who, 10 * DEADLINE);
            let _ = o.withdraw_bond();
        }
        assert_eq!(
            (o.pending_payouts_total, o.claimable_total, o.total_owed().0),
            (2 * BOND, 0, 2 * BOND)
        );
        settle(&mut o, 2, false);
        let failed = payout_json("dave.near", 2);
        assert_eq!(logged("bond_payout_failed"), vec![failed]);
        assert_eq!(
            (o.pending_payouts_total, o.claimable_total, o.total_owed().0),
            (BOND, BOND, 2 * BOND)
        );
        assert_eq!((owed(&o, "carol.near"), owed(&o, "dave.near")), (0, BOND));
        assert!(o.get_payout(1).is_some() && o.get_payout(2).is_none());
        settle(&mut o, 1, true);
        assert_eq!(
            (o.pending_payouts_total, o.claimable_total, o.total_owed().0),
            (0, BOND, BOND)
        );
        assert_eq!(logged("bond_paid"), vec![payout_json("carol.near", 1)]);
    }

    #[test]
    fn a_payout_whose_callback_never_reports_stays_pending_and_owed() {
        let mut o = unchallenged_and_final();
        act_as("carol.near", 10 * DEADLINE);
        let _ = o.withdraw_bond();
        act_as("carol.near", 100 * DEADLINE);
        assert_eq!(refusal(|| drop(o.withdraw_bond())), "nothing to withdraw");
        assert_eq!(
            (owed(&o, "carol.near"), o.pending_payouts_total, o.total_owed().0),
            (0, BOND, BOND)
        );
        assert!(o.get_payout(1).is_some());
    }

    proptest! {
        #![proptest_config(ProptestConfig::with_cases(200))]

        // Whatever the verifier answers, or does not, a withdrawal never changes what is owed while it is in flight, and
        // after each callback every unit is in exactly one place: paid out, claimable, or still pending.
        #[test]
        fn withdrawals_with_any_callback_outcome_create_and_lose_nothing(
            balances in prop::collection::vec(1u128..1_000_000, 5),
            steps in prop::collection::vec((0usize..5, 0u8..3), 1..40),
        ) {
            let mut o = fresh_oracle();
            for (i, b) in balances.iter().enumerate() {
                o.add_claimable(&acct(&format!("u{i}.near")), *b);
            }
            let start: u128 = balances.iter().sum();
            let (mut paid, mut stuck) = (0u128, 0u128);
            for (who, answer) in steps {
                let name = format!("u{who}.near");
                let due = owed(&o, &name);
                if due == 0 {
                    continue;
                }
                let before = o.total_owed().0;
                act_as(&name, 10 * DEADLINE);
                let _ = o.withdraw_bond();
                prop_assert_eq!(o.total_owed().0, before, "in flight, the money is still owed");
                prop_assert_eq!(o.pending_payouts_total, stuck + due);
                let id = o.last_payout_id;
                match answer {
                    0 => {
                        settle(&mut o, id, true);
                        paid += due;
                    }
                    1 => settle(&mut o, id, false),
                    _ => stuck += due,
                }
                let claimable: u128 = (0..5).map(|i| owed(&o, &format!("u{i}.near"))).sum();
                prop_assert_eq!(claimable, o.claimable_total);
                prop_assert_eq!(o.pending_payouts_total, stuck);
                prop_assert_eq!(o.total_owed().0 + paid, start, "nothing was created or lost");
                prop_assert_eq!(o.bond_totals().total, o.total_owed());
            }
        }
    }

    #[test]
    fn bond_totals_shows_the_payout_in_flight_and_settles_back_into_the_books() {
        let mut o = unchallenged_and_final();
        let totals = |o: &OracleContract| near_sdk::serde_json::to_value(o.bond_totals()).unwrap();
        let json = |held: u128, claimable: u128, pending: u128| {
            near_sdk::serde_json::json!({
                "bonds_held": held.to_string(),
                "claimable": claimable.to_string(),
                "pending_payouts": pending.to_string(),
                "total": (held + claimable + pending).to_string()
            })
        };
        assert_eq!(totals(&o), json(0, BOND, 0));
        act_as("carol.near", 10 * DEADLINE);
        let _ = o.withdraw_bond();
        assert_eq!(totals(&o), json(0, 0, BOND));
        assert_eq!(o.bond_totals().total, o.total_owed());
        settle(&mut o, 1, false);
        assert_eq!(totals(&o), json(0, BOND, 0));
        act_as("carol.near", 10 * DEADLINE);
        let _ = o.withdraw_bond();
        settle(&mut o, 2, true);
        assert_eq!(totals(&o), json(0, 0, 0));
    }

    #[test]
    fn two_accounts_with_a_balance_each_withdraw_only_their_own() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        act_as("anyone.near", QUEUE_OVER);
        o.finalize(acct(MARKET), U64(0));
        act_as("anyone.near", QUEUE_OVER + PANEL + DRAW_WINDOW + PANEL);
        o.finalize(acct(MARKET), U64(0));
        let (carol, dave) = (owed(&o, "carol.near"), owed(&o, "dave.near"));
        assert_eq!(
            (carol, dave),
            (BOND, BOND),
            "no jury was ever seated: each side is owed their own bond in full"
        );
        act_as("carol.near", 10 * DEADLINE);
        let _ = o.withdraw_bond();
        assert_eq!(mt_transfer_sent().0["receiver_id"], "carol.near");
        assert_eq!(
            o.total_owed().0,
            2 * BOND,
            "carol's payout is still owed until it is confirmed"
        );
        settle(&mut o, 1, true);
        assert_eq!(o.total_owed().0, 2 * BOND - carol);
    }

    // The draw could never happen, so nobody ruled and nobody is charged: both sides get their own bond back in full.
    #[test]
    fn when_no_jury_could_be_drawn_both_sides_get_their_bond_back_and_nobody_is_charged() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        act_as("anyone.near", QUEUE_OVER);
        o.finalize(acct(MARKET), U64(0));
        assert!(!o.case(&acct(MARKET), 0).seated);
        act_as("anyone.near", QUEUE_OVER + PANEL + DRAW_WINDOW + PANEL);
        o.finalize(acct(MARKET), U64(0));
        let case = o.case(&acct(MARKET), 0);
        assert_eq!((case.stage, case.final_outcome), (Stage::Final, Some(Outcome::Void)));
        assert_eq!((owed(&o, "carol.near"), owed(&o, "dave.near")), (BOND, BOND));
        assert_eq!((owed(&o, RECIPIENT), owed(&o, OWNER)), (0, 0));
        assert_eq!(o.total_owed().0, 2 * BOND, "every unit is still owed to someone");
        assert_eq!(o.bonds_held, 0);
        assert_eq!(
            logged("final"),
            vec![
                near_sdk::serde_json::json!({ "market": MARKET, "market_id": "0", "outcome": "void", "ruling": "no_jury",
                "juror_pay_each": "0", "paid_jurors": [], "delinquent": [] })
            ]
        );
    }

    // Seats held by other cases are a shortage that passes. The case waits and draws again instead of ruling.
    #[test]
    fn a_draw_that_found_too_few_free_seats_is_retried_in_a_longer_window_and_can_still_seat_a_jury() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        let retry_at = DRAW_BY + 1;
        act_as("anyone.near", retry_at);
        o.finalize(acct(MARKET), U64(0));
        let case = o.case(&acct(MARKET), 0);
        assert_eq!(
            (case.stage, case.round, case.draw_by.0),
            (Stage::Disputed, 0, retry_at + DRAW_WINDOW)
        );
        assert_eq!(logged("draw_extended").len(), 1);
        assert_eq!(
            (owed(&o, "carol.near"), owed(&o, "dave.near"), owed(&o, RECIPIENT)),
            (0, 0, 0)
        );

        act_at_height("anyone.near", retry_at + 5, 50);
        let _ = o.resolve_draw(acct(MARKET), U64(0));
        act_as(COUNCIL, retry_at + 6);
        let jury: Vec<AccountId> = names(FIRST_JURORS, "j").iter().map(|j| acct(j)).collect();
        o.on_drawn(acct(MARKET), U64(0), 0, Ok(jury));
        let case = o.case(&acct(MARKET), 0);
        assert!(case.seated && case.stage == Stage::Disputed);
    }

    // The wait is bounded: after the last window the old rules apply, a second jury or no jury.
    #[test]
    fn the_wait_for_seats_ends_after_a_few_windows() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        let mut at = DRAW_BY + 1;
        let mut waits = 0;
        loop {
            act_as("anyone.near", at);
            o.finalize(acct(MARKET), U64(0));
            if o.case(&acct(MARKET), 0).round == 1 {
                break;
            }
            waits += 1;
            assert!(waits < MAX_DRAW_QUEUE_WINDOWS, "the wait never ends");
            at = o.case(&acct(MARKET), 0).draw_by.0 + 1;
        }
        assert!(waits >= 1, "it waited at least once before the second round");
    }

    // A jury that sat and never revealed is a dispute nobody decided, not a failed draw: the old split stays.
    #[test]
    fn a_jury_that_was_seated_but_never_revealed_keeps_the_no_decision_split() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        let over = first_round_that_does_nothing(&mut o, &names(FIRST_JURORS, "j"));
        assert!(o.case(&acct(MARKET), 0).seated);
        act_as("anyone.near", over);
        o.finalize(acct(MARKET), U64(0));
        assert!(o.case(&acct(MARKET), 0).seated, "the flag survives the escalation");
        act_as("anyone.near", over + DRAW_WINDOW + 1);
        o.finalize(acct(MARKET), U64(0));
        assert_eq!(o.case(&acct(MARKET), 0).stage, Stage::Final);
        assert_eq!(
            (owed(&o, "carol.near"), owed(&o, "dave.near"), owed(&o, RECIPIENT)),
            (BOND + BOND / 2, 0, BOND / 2)
        );
        assert_eq!(o.total_owed().0, 2 * BOND);
        assert_eq!(logged("final")[0]["ruling"], "no_decision");
    }

    // A jury seated only in the second round counts too.
    #[test]
    fn a_jury_seated_only_in_the_second_round_keeps_the_no_decision_split() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        act_as("anyone.near", QUEUE_OVER);
        o.finalize(acct(MARKET), U64(0));
        let seated_at = QUEUE_OVER + SECOND;
        seat(&mut o, seated_at, &names(SECOND_JURORS, "k"));
        assert!(o.case(&acct(MARKET), 0).seated);
        act_as("anyone.near", o.case(&acct(MARKET), 0).panel_deadline.0 + 1);
        o.finalize(acct(MARKET), U64(0));
        assert_eq!(o.case(&acct(MARKET), 0).stage, Stage::Final);
        assert_eq!(owed(&o, RECIPIENT), BOND / 2);
        assert_eq!(logged("final")[0]["ruling"], "no_decision");
    }

    #[test]
    fn the_collateral_id_must_be_the_exact_nep141_form() {
        let message = refusal(|| drop(oracle_on("usdc.near", BOND, 2)));
        assert_eq!(message, "the collateral token id must look like nep141:<token>");
        let message = refusal(|| drop(oracle_on("NEP141:usdc.near", BOND, 2)));
        assert_eq!(message, "the collateral token id must look like nep141:<token>");
    }

    #[test]
    fn config_names_the_verifier_and_the_exact_token_id_and_no_token_contract() {
        let o = fresh_oracle();
        let config = o.config();
        assert_eq!(config["verifier"], VERIFIER);
        assert_eq!(config["collateral_token_id"], COLLATERAL);
        assert!(config.get("bond_token").is_none());
    }

    // ---- list_cases and bond_totals ------------------------------------------------------------------------

    fn put_case_at(o: &mut OracleContract, id: u64, mut case: Case) {
        case.window_ends_at = U64(id);
        o.put_case(&acct(MARKET), id, case);
    }

    fn summary_json(o: &OracleContract, from: u64, limit: u32) -> near_sdk::serde_json::Value {
        near_sdk::serde_json::to_value(o.list_cases(acct(MARKET), U64(from), limit)).unwrap()
    }

    fn proposed_case() -> Case {
        let mut o = oracle_with_resolve_by(MARKET_DEADLINE);
        act_as(VERIFIER, SECOND);
        deliver(&mut o, "carol.near", BOND, "propose:market.near:0:yes:https://x");
        o.case(&acct(MARKET), 0)
    }

    #[test]
    fn list_cases_shows_proposed_disputed_and_final_cases_with_exact_fields() {
        let proposed = proposed_case();
        let mut o = oracle_with_bond(BOND);
        put_case_at(&mut o, 3, proposed.clone());
        disputed_case(&mut o, Outcome::Yes, &["j0.near"], &[("j0.near", Outcome::No)]);
        let mut disputed = o.case(&acct(MARKET), 0);
        disputed.round = 1;
        put_case_at(&mut o, 4, disputed);
        let mut done = proposed;
        done.stage = Stage::Final;
        done.final_outcome = Some(Outcome::Void);
        done.applied = true;
        put_case_at(&mut o, 5, done);

        let rows = summary_json(&o, 3, 3);
        let window_of = |id: u64| id.to_string();
        let expected = near_sdk::serde_json::json!([
            { "market": MARKET, "market_id": "3", "stage": "proposed", "proposed": "yes", "challenger_answer": null, "round": 0,
              "final_outcome": null, "applied": false, "votes": 0, "window_ends_at": window_of(3),
              "draw_by": "0", "panel_deadline": "0" },
            { "market": MARKET, "market_id": "4", "stage": "disputed", "proposed": "yes", "challenger_answer": "no", "round": 1,
              "final_outcome": null, "applied": false, "votes": 1, "window_ends_at": window_of(4),
              "draw_by": DRAW_WINDOW.to_string(), "panel_deadline": DEADLINE.to_string() },
            { "market": MARKET, "market_id": "5", "stage": "final", "proposed": "yes", "challenger_answer": null, "round": 0,
              "final_outcome": "void", "applied": true, "votes": 0, "window_ends_at": window_of(5),
              "draw_by": "0", "panel_deadline": "0" },
        ]);
        assert_eq!(rows, expected);
    }

    #[test]
    fn list_cases_skips_ids_without_a_case_and_starts_at_the_id_asked_for() {
        let case = proposed_case();
        let mut o = fresh_oracle();
        for id in [1, 4, 6] {
            put_case_at(&mut o, id, case.clone());
        }
        let ids = |from, limit| -> Vec<String> {
            o.list_cases(acct(MARKET), U64(from), limit)
                .iter()
                .map(|c| c.market_id.0.to_string())
                .collect()
        };
        assert_eq!(ids(0, 7), ["1", "4", "6"]);
        assert_eq!(ids(0, 4), ["1"], "ids 0 to 3 hold one case, so the page is short");
        assert_eq!(ids(2, 3), ["4"]);
        assert_eq!(ids(4, 10), ["4", "6"]);
        assert_eq!(ids(5, 1), Vec::<String>::new());
    }

    #[test]
    fn list_cases_clamps_the_limit_and_is_empty_past_the_last_id() {
        let case = proposed_case();
        let mut o = fresh_oracle();
        let last = u64::from(MAX_LIST_CASES) + 9;
        for id in 0..=last {
            put_case_at(&mut o, id, case.clone());
        }
        assert_eq!(
            o.list_cases(acct(MARKET), U64(0), u32::MAX).len(),
            MAX_LIST_CASES as usize
        );
        assert_eq!(
            o.list_cases(acct(MARKET), U64(0), MAX_LIST_CASES + 1)
                .last()
                .unwrap()
                .market_id
                .0,
            u64::from(MAX_LIST_CASES) - 1
        );
        assert_eq!(o.list_cases(acct(MARKET), U64(0), 0).len(), 0);
        assert!(o.list_cases(acct(MARKET), U64(last + 1), 10).is_empty());
        assert!(o.list_cases(acct(MARKET), U64(u64::MAX), u32::MAX).is_empty());
    }

    #[test]
    fn bond_totals_add_up_to_total_owed_through_a_proposal_a_challenge_a_settlement_and_a_withdrawal() {
        let mut o = oracle_with_bond(BOND);
        o.put_market(
            0,
            MarketInfo {
                resolve_by: U64(MARKET_DEADLINE),
                ..base_info()
            },
        );
        let check = |o: &OracleContract, held: u128, claimable: u128, pending: u128| {
            let totals = near_sdk::serde_json::to_value(o.bond_totals()).unwrap();
            assert_eq!(
                totals,
                near_sdk::serde_json::json!({
                    "bonds_held": held.to_string(),
                    "claimable": claimable.to_string(),
                    "pending_payouts": pending.to_string(),
                    "total": (held + claimable + pending).to_string()
                })
            );
            assert_eq!(o.bond_totals().total, o.total_owed());
        };
        check(&o, 0, 0, 0);
        act_as(VERIFIER, SECOND);
        deliver(&mut o, "carol.near", BOND, "propose:market.near:0:yes:https://x");
        check(&o, BOND, 0, 0);
        act_as(VERIFIER, CHALLENGED_AT);
        deliver(&mut o, "dave.near", BOND, "challenge:market.near:0:no");
        check(&o, 2 * BOND, 0, 0);
        act_as("anyone.near", QUEUE_OVER);
        o.finalize(acct(MARKET), U64(0));
        seat(&mut o, QUEUE_OVER + SECOND, &names(SECOND_JURORS, "k"));
        act_as("anyone.near", o.case(&acct(MARKET), 0).panel_deadline.0 + 1);
        o.finalize(acct(MARKET), U64(0));
        assert_eq!(o.case(&acct(MARKET), 0).stage, Stage::Final);
        check(&o, 0, 2 * BOND, 0);
        let paid = owed(&o, RECIPIENT);
        assert!(paid > 0);
        act_as(RECIPIENT, 10 * DEADLINE);
        let _ = o.withdraw_bond();
        check(&o, 0, 2 * BOND - paid, paid);
        settle(&mut o, 1, true);
        check(&o, 0, 2 * BOND - paid, 0);
        let carol = owed(&o, "carol.near");
        assert!(carol > 0);
        act_as("carol.near", 10 * DEADLINE);
        let _ = o.withdraw_bond();
        check(&o, 0, 2 * BOND - paid - carol, carol);
        settle(&mut o, 2, false);
        check(&o, 0, 2 * BOND - paid, 0);
    }

    #[test]
    fn the_list_and_totals_views_change_nothing() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        let case = o.case(&acct(MARKET), 0);
        put_case_at(&mut o, 9, case);
        let before = (
            near_sdk::serde_json::to_value(o.get_case(acct(MARKET), U64(0))).unwrap(),
            near_sdk::serde_json::to_value(o.get_case(acct(MARKET), U64(9))).unwrap(),
            o.config(),
            o.total_owed(),
        );
        for _ in 0..2 {
            let _ = o.list_cases(acct(MARKET), U64(0), 50);
            let _ = o.bond_totals();
        }
        let after = (
            near_sdk::serde_json::to_value(o.get_case(acct(MARKET), U64(0))).unwrap(),
            near_sdk::serde_json::to_value(o.get_case(acct(MARKET), U64(9))).unwrap(),
            o.config(),
            o.total_owed(),
        );
        assert_eq!(before, after);
    }

    #[test]
    fn the_views_leave_a_payout_in_flight_untouched() {
        let mut o = unchallenged_and_final();
        act_as("carol.near", 10 * DEADLINE);
        let _ = o.withdraw_bond();
        let state = |o: &OracleContract| {
            (
                near_sdk::serde_json::to_value(o.bond_totals()).unwrap(),
                o.total_owed(),
                o.claimable_of(acct("carol.near")),
                o.pending_payouts_total,
                o.last_payout_id,
                o.get_payout(1).map(|p| p.amount),
            )
        };
        let before = state(&o);
        for _ in 0..2 {
            let _ = o.list_cases(acct(MARKET), U64(0), 50);
        }
        assert_eq!(before, state(&o));
    }

    // ---- the policy settings the DAO can tune -------------------------------------------------------------------

    #[test]
    fn the_policy_settings_start_at_the_values_that_used_to_be_fixed() {
        let c = fresh_oracle().config();
        assert_eq!(c["apply_buffer_ns"], "30000000000");
        assert_eq!(c["juror_share_bps"], 2_500);
        assert_eq!(c["no_decision_share_bps"], 5_000);
        assert_eq!(c["max_publishers"], 10);
        assert_eq!(c["min_resolve_gap_ns"], MIN_GAP.to_string());
    }

    #[test]
    fn the_policy_settings_refuse_a_stranger_and_the_operator() {
        let mut o = fresh_oracle();
        for who in ["stranger.near", OPERATOR] {
            act_unpaid(who, 5);
            assert!(
                refusal(|| o.set_juror_shares(2_500, 5_000)).contains("owner only"),
                "{who}"
            );
            assert!(
                refusal(|| o.set_apply_buffer_ms(U64(30_000))).contains("owner only"),
                "{who}"
            );
            assert!(refusal(|| o.set_max_publishers(10)).contains("owner only"), "{who}");
        }
    }

    #[test]
    fn the_reconcile_wait_starts_at_an_hour_and_the_owner_moves_it_within_its_bounds() {
        let mut o = fresh_oracle();
        assert_eq!(o.config()["reconcile_wait_ns"], DEFAULT_RECONCILE_WAIT_NS.to_string());
        act_unpaid(OWNER, 5);
        o.set_reconcile_wait_ns(U64(MIN_RECONCILE_WAIT_NS));
        assert_eq!(
            logged("reconcile_wait_set"),
            vec![near_sdk::serde_json::json!({ "reconcile_wait_ns": MIN_RECONCILE_WAIT_NS.to_string() })]
        );
        assert_eq!(o.config()["reconcile_wait_ns"], "600000000000");
        o.set_reconcile_wait_ns(U64(MAX_RECONCILE_WAIT_NS));
        assert_eq!(o.config()["reconcile_wait_ns"], "604800000000000");
        for bad in [0, MIN_RECONCILE_WAIT_NS - 1, MAX_RECONCILE_WAIT_NS + 1] {
            let message = refusal(|| o.set_reconcile_wait_ns(U64(bad)));
            assert!(message.contains("between 10 minutes and 7 days"), "{bad}: {message}");
        }
    }

    #[test]
    fn only_the_owner_sets_the_reconcile_wait() {
        let mut o = fresh_oracle();
        for who in ["stranger.near", OPERATOR] {
            act_unpaid(who, 5);
            assert!(
                refusal(|| o.set_reconcile_wait_ns(U64(DEFAULT_RECONCILE_WAIT_NS))).contains("owner only"),
                "{who}"
            );
        }
        assert_eq!(o.config()["reconcile_wait_ns"], DEFAULT_RECONCILE_WAIT_NS.to_string());
    }

    #[test]
    fn a_longer_reconcile_wait_refuses_a_reconcile_the_old_wait_would_allow() {
        let mut o = a_stuck_payout();
        act_unpaid(OWNER, PAID_OUT_AT);
        o.set_reconcile_wait_ns(U64(2 * DEFAULT_RECONCILE_WAIT_NS));
        act_unpaid(OWNER, PAYOUT_DECIDABLE_AT);
        assert!(refusal(|| o.reconcile_bond_payout(U64(1), true))
            .contains("wait 120 minutes after the payout before reconciling"));
        reconcile_at(&mut o, PAID_OUT_AT + 2 * DEFAULT_RECONCILE_WAIT_NS, true);
        assert_eq!(o.pending_payouts_total, 0);
    }

    #[test]
    fn the_juror_shares_refuse_values_outside_their_range_at_both_ends() {
        let mut o = fresh_oracle();
        act_unpaid(OWNER, 5);
        for decided in [499, 5_001] {
            let message = refusal(|| o.set_juror_shares(decided, 5_000));
            assert!(
                message.contains("decided juror share must be between 500 and 5000"),
                "{decided}: {message}"
            );
        }
        for none in [999, 10_001] {
            let message = refusal(|| o.set_juror_shares(2_500, none));
            assert!(
                message.contains("no decision juror share must be between 1000 and 10000"),
                "{none}: {message}"
            );
        }
        o.set_juror_shares(500, 1_000);
        o.set_juror_shares(5_000, 10_000);
        assert_eq!(o.config()["juror_share_bps"], 5_000);
    }

    #[test]
    fn the_juror_shares_show_in_config_and_emit_their_event() {
        let mut o = fresh_oracle();
        act_unpaid(OWNER, 5);
        o.set_juror_shares(1_000, 2_000);
        let c = o.config();
        assert_eq!(c["juror_share_bps"], 1_000);
        assert_eq!(c["no_decision_share_bps"], 2_000);
        assert_eq!(
            logged("juror_shares_set"),
            vec![near_sdk::serde_json::json!({ "decided_bps": 1_000, "no_decision_bps": 2_000 })]
        );
    }

    fn open_dispute(o: &mut OracleContract, id: u64) {
        o.put_market(
            id,
            MarketInfo {
                resolve_by: U64(MARKET_DEADLINE),
                ..base_info()
            },
        );
        act_as(VERIFIER, SECOND);
        deliver(
            o,
            "carol.near",
            BOND,
            &format!("propose:market.near:{id}:yes:https://x"),
        );
        act_as(VERIFIER, CHALLENGED_AT);
        deliver(o, "dave.near", BOND, &format!("challenge:market.near:{id}:no"));
    }

    // All three jurors are seated and revealed, so a ruling of either kind has jurors to pay.
    fn jurors_revealed(o: &mut OracleContract, id: u64) {
        let mut case = o.case(&acct(MARKET), id);
        case.panel = JURORS.iter().map(|j| acct(j)).collect();
        case.seated = true;
        case.votes = JURORS
            .iter()
            .map(|j| Vote {
                juror: acct(j),
                outcome: Outcome::No,
                reason: "r".into(),
            })
            .collect();
        o.put_case(&acct(MARKET), id, case);
    }

    #[test]
    fn a_case_pays_the_juror_shares_it_was_proposed_with() {
        let mut o = oracle_with_bond(BOND);
        open_dispute(&mut o, 0);
        open_dispute(&mut o, 1);
        act_unpaid(OWNER, 3 * SECOND);
        o.set_juror_shares(1_000, 2_000);
        open_dispute(&mut o, 2);
        open_dispute(&mut o, 3);
        assert_eq!(
            (
                o.case(&acct(MARKET), 0).juror_share_bps,
                o.case(&acct(MARKET), 0).no_decision_share_bps
            ),
            (2_500, 5_000)
        );
        assert_eq!(
            (
                o.case(&acct(MARKET), 2).juror_share_bps,
                o.case(&acct(MARKET), 2).no_decision_share_bps
            ),
            (1_000, 2_000)
        );
        for id in 0..4 {
            jurors_revealed(&mut o, id);
        }
        act_as("anyone.near", 100 * SECOND);
        o.settle(&acct(MARKET), 0, Outcome::No, Ruling::Decided);
        let old = BOND * 2_500 / 10_000 / 3;
        assert_eq!(owed(&o, "j0.near"), old);
        o.settle(&acct(MARKET), 2, Outcome::No, Ruling::Decided);
        let new = BOND * 1_000 / 10_000 / 3;
        assert_eq!(owed(&o, "j0.near"), old + new);
        o.settle(&acct(MARKET), 1, Outcome::Void, Ruling::NoDecision);
        assert_eq!(owed(&o, "j1.near"), old + new + BOND * 5_000 / 10_000 / 3);
        o.settle(&acct(MARKET), 3, Outcome::Void, Ruling::NoDecision);
        assert_eq!(
            owed(&o, "j2.near"),
            old + new + BOND * 5_000 / 10_000 / 3 + BOND * 2_000 / 10_000 / 3
        );
    }

    #[test]
    fn get_case_shows_the_shares_and_list_cases_does_not() {
        let mut o = challenged(Outcome::Yes, Outcome::No);
        let case = near_sdk::serde_json::to_value(o.get_case(acct(MARKET), U64(0))).unwrap();
        assert_eq!(case["juror_share_bps"], 2_500);
        assert_eq!(case["no_decision_share_bps"], 5_000);
        let row = near_sdk::serde_json::to_value(o.list_cases(acct(MARKET), U64(0), 1)).unwrap();
        assert!(row[0].get("juror_share_bps").is_none() && row[0].get("no_decision_share_bps").is_none());
        act_unpaid(OWNER, 5);
        o.set_juror_shares(500, 1_000);
        let case = near_sdk::serde_json::to_value(o.get_case(acct(MARKET), U64(0))).unwrap();
        assert_eq!(case["juror_share_bps"], 2_500, "an open case keeps its shares");
    }

    #[test]
    fn the_apply_buffer_refuses_values_outside_its_range_at_both_ends() {
        let mut o = fresh_oracle();
        act_unpaid(OWNER, 5);
        for ms in [4_999, 300_001] {
            let message = refusal(|| o.set_apply_buffer_ms(U64(ms)));
            assert!(message.contains("between 5 seconds and 5 minutes"), "{ms}: {message}");
        }
        o.set_apply_buffer_ms(U64(5_000));
        assert_eq!(o.config()["apply_buffer_ns"], "5000000000");
        o.set_apply_buffer_ms(U64(300_000));
        assert_eq!(o.config()["apply_buffer_ns"], "300000000000");
        assert_eq!(logged("apply_buffer_set").last().unwrap()["apply_buffer_ms"], "300000");
    }

    #[test]
    fn a_market_keeps_the_apply_buffer_it_was_registered_with() {
        let mut o = fresh_oracle();
        act_as(MARKET, 0);
        o.register_market(U64(0), U64(1_000), U64(1_000 + MIN_GAP), "hash".to_string(), None);
        act_unpaid(OWNER, 1);
        o.set_apply_buffer_ms(U64(60_000));
        assert_eq!(
            o.config()["min_resolve_gap_ns"],
            (MIN_GAP - APPLY_BUFFER_NS + 60 * SECOND).to_string(),
            "new markets need the new buffer"
        );
        act_as(MARKET, 2);
        let refused = refusal(|| {
            o.register_market(U64(1), U64(1_000), U64(1_000 + MIN_GAP), "hash".to_string(), None);
        });
        assert!(refused.contains("too soon after close_at"), "{refused}");
        o.register_market(
            U64(1),
            U64(1_000),
            U64(1_000 + MIN_GAP + 30 * SECOND),
            "hash".to_string(),
            None,
        );
        assert_eq!(o.market_info(&acct(MARKET), 0).apply_buffer_ns.0, APPLY_BUFFER_NS);
        assert_eq!(o.market_info(&acct(MARKET), 1).apply_buffer_ns.0, 60 * SECOND);
        // The old market still fits a case with its own 30 second buffer.
        act_as(VERIFIER, 1_000 + PROPOSAL_TIME);
        deliver(&mut o, "carol.near", BOND, "propose:market.near:0:yes:https://x");
        // The new one does not fit the same moment with its 60 second buffer.
        act_as(VERIFIER, 1_000 + PROPOSAL_TIME + 30 * SECOND + 1);
        let late = refusal(|| {
            deliver(&mut o, "carol.near", BOND, "propose:market.near:1:yes:https://x");
        });
        assert!(late.contains("too late to propose"), "{late}");
    }

    #[test]
    fn the_publisher_limit_refuses_values_outside_its_range_and_below_the_signers_needed() {
        let mut o = fresh_oracle();
        act_unpaid(OWNER, 5);
        for n in [0, 26] {
            let message = refusal(|| o.set_max_publishers(n));
            assert!(message.contains("between 1 and 25"), "{n}: {message}");
        }
        let message = refusal(|| o.set_max_publishers(1));
        assert!(
            message.contains("cannot be below the number that must sign"),
            "{message}"
        );
        o.set_max_publishers(25);
        o.set_max_publishers(2);
        assert_eq!(o.config()["max_publishers"], 2);
        assert_eq!(logged("max_publishers_set").last().unwrap()["max_publishers"], 2);
    }

    #[test]
    fn lowering_the_publisher_limit_blocks_the_next_add_and_keeps_those_there() {
        let (mut o, _) = price_oracle(true);
        act_unpaid(OWNER, 5);
        o.set_max_publishers(2);
        assert_eq!(o.config()["publishers"].as_array().unwrap().len(), 3);
        let message = refusal(|| o.add_publisher(public(&signing_key(40))));
        assert!(message.contains("there can be at most 2 publishers"), "{message}");
        o.set_max_publishers(4);
        add_publisher_keeping_majority(&mut o, public(&signing_key(40)));
        assert_eq!(o.config()["publishers"].as_array().unwrap().len(), 4);
        let message = refusal(|| o.add_publisher(public(&signing_key(41))));
        assert!(message.contains("there can be at most 4 publishers"), "{message}");
    }

    #[test]
    fn a_raised_publisher_limit_lets_more_than_ten_be_added() {
        let (mut o, _) = price_oracle(true);
        act_unpaid(OWNER, 5);
        o.set_max_publishers(25);
        for seed in 10..32 {
            add_publisher_keeping_majority(&mut o, public(&signing_key(seed)));
        }
        assert_eq!(o.config()["publishers"].as_array().unwrap().len(), 25);
    }

    #[test]
    fn the_owner_windows_and_the_draw_delay_have_upper_bounds() {
        let mut o = fresh_oracle();
        act_as(OWNER, 1);
        for setter in [
            |o: &mut OracleContract, v: U64| o.set_window_ms(v),
            |o: &mut OracleContract, v: U64| o.set_panel_deadline_ms(v),
            |o: &mut OracleContract, v: U64| o.set_min_proposal_ms(v),
            |o: &mut OracleContract, v: U64| o.set_draw_window_ms(v),
        ] {
            let message = refusal(|| setter(&mut o, U64(MAX_WINDOW_MS + 1)));
            assert!(message.contains("at most a year"), "{message}");
            setter(&mut o, U64(MAX_WINDOW_MS));
        }
        let message = refusal(|| o.set_draw_delay_blocks(U64(MAX_DRAW_DELAY_BLOCKS + 1)));
        assert!(message.contains("at most 100000 blocks"), "{message}");
        o.set_draw_delay_blocks(U64(MAX_DRAW_DELAY_BLOCKS));
    }

    #[test]
    fn a_failed_upgrade_batch_clears_the_in_flight_flag_and_a_good_one_leaves_it() {
        let mut c = fresh_oracle();
        c.upgrade_in_flight = true;
        c.on_upgrade_done(Ok(()));
        assert!(c.upgrade_in_flight);
        c.on_upgrade_done(Err(PromiseError::Failed));
        assert!(!c.upgrade_in_flight);
    }

    #[test]
    fn the_threshold_must_stay_above_half_of_the_publishers() {
        let (mut o, _) = price_oracle(true);
        act_as(OWNER, 1);
        assert_eq!(o.config()["price_threshold"], 2);
        let message = refusal(|| o.add_publisher(public(&signing_key(40))));
        assert!(message.contains("more than half of the publishers"), "{message}");
        o.set_price_threshold(3);
        o.add_publisher(public(&signing_key(40)));
        let message = refusal(|| o.set_price_threshold(2));
        assert!(message.contains("more than half of the publishers"), "{message}");
        act_as(OWNER, 1);
        o.remove_publisher(public(&signing_key(40)));
        o.set_price_threshold(2);
        assert_eq!(o.config()["price_threshold"], 2);
    }

    // ---- two market accounts, the allow-list and the case uid ------------------------------------------------------

    const MARKET2: &str = "market2.near";

    fn outcome_receivers() -> Vec<String> {
        near_sdk::test_utils::get_created_receipts()
            .iter()
            .filter(|r| {
                r.actions.iter().any(|a| {
                    matches!(a, near_sdk::mock::MockAction::FunctionCallWeight { method_name, .. }
                        if method_name == b"set_outcome")
                })
            })
            .map(|r| r.receiver_id.to_string())
            .collect()
    }

    // Two market contracts, both with a market 0, and the second one allowed by the owner.
    fn two_markets() -> OracleContract {
        let mut o = oracle_with_bond(BOND);
        act_as(OWNER, 0);
        o.allow_market(acct(MARKET2));
        for market in [MARKET, MARKET2] {
            o.markets.insert(
                (acct(market), 0),
                VersionedMarketInfo::current(MarketInfo {
                    resolve_by: U64(MARKET_DEADLINE),
                    ..base_info()
                }),
            );
        }
        o
    }

    fn propose_on(o: &mut OracleContract, market: &str, id: u64, who: &str, outcome: Outcome) {
        act_as(VERIFIER, SECOND);
        deliver(
            o,
            who,
            BOND,
            &format!("propose:{market}:{id}:{}:https://x", outcome.word()),
        );
    }

    #[test]
    fn the_same_market_id_under_two_market_accounts_is_two_markets_with_two_cases() {
        let mut o = two_markets();
        propose_on(&mut o, MARKET, 0, "carol.near", Outcome::Yes);
        assert!(
            o.get_case(acct(MARKET2), U64(0)).is_none(),
            "the other market has no case yet"
        );
        propose_on(&mut o, MARKET2, 0, "erin.near", Outcome::No);
        let (first, second) = (
            o.get_case(acct(MARKET), U64(0)).unwrap(),
            o.get_case(acct(MARKET2), U64(0)).unwrap(),
        );
        assert_eq!((first.proposer, first.proposed), (acct("carol.near"), Outcome::Yes));
        assert_eq!((second.proposer, second.proposed), (acct("erin.near"), Outcome::No));
        act_as(VERIFIER, 2 * SECOND);
        deliver(&mut o, "dave.near", BOND, "challenge:market2.near:0:yes");
        assert_eq!(o.case(&acct(MARKET2), 0).stage, Stage::Disputed);
        assert_eq!(
            o.case(&acct(MARKET), 0).stage,
            Stage::Proposed,
            "the first market's case is untouched"
        );
        assert_eq!(o.bonds_held, 3 * BOND);
    }

    #[test]
    fn a_market_info_is_kept_per_market_account() {
        let mut o = two_markets();
        act_as(MARKET2, SECOND);
        o.register_market(U64(7), U64(0), U64(MARKET_DEADLINE), "second".to_string(), None);
        assert!(o.get_market_info(acct(MARKET2), U64(7)).is_some());
        assert!(o.get_market_info(acct(MARKET), U64(7)).is_none());
        act_as(MARKET, SECOND);
        o.register_market(U64(7), U64(0), U64(MARKET_DEADLINE), "first".to_string(), None);
        assert_eq!(o.get_market_info(acct(MARKET), U64(7)).unwrap().rule_hash, "first");
        assert_eq!(o.get_market_info(acct(MARKET2), U64(7)).unwrap().rule_hash, "second");
    }

    #[test]
    fn the_answer_goes_to_the_market_account_that_owns_the_case() {
        let mut o = two_markets();
        propose_on(&mut o, MARKET2, 0, "erin.near", Outcome::No);
        act_as("anyone.near", SECOND + WINDOW);
        o.finalize(acct(MARKET2), U64(0));
        assert_eq!(outcome_receivers(), [MARKET2]);
        assert_eq!(
            calls_to("set_outcome"),
            [near_sdk::serde_json::json!({ "market_id": "0", "outcome": "no" })]
        );
        assert!(o.get_case(acct(MARKET), U64(0)).is_none());
    }

    #[test]
    fn a_market_that_is_not_allowed_is_refused_at_registration_proposal_and_challenge() {
        let mut o = two_markets();
        act_as("rogue.near", SECOND);
        let message = refusal(|| o.register_market(U64(1), U64(0), U64(MARKET_DEADLINE), "h".to_string(), None));
        assert!(message.contains("that market contract is not allowed"), "{message}");
        for msg in ["propose:rogue.near:0:yes:https://x", "challenge:rogue.near:0:no"] {
            act_as(VERIFIER, SECOND);
            let message = refusal(|| {
                deliver(&mut o, "carol.near", BOND, msg);
            });
            assert!(
                message.contains("that market contract is not allowed"),
                "{msg}: {message}"
            );
        }
        assert_eq!(o.bonds_held, 0);
    }

    #[test]
    fn a_disallowed_market_keeps_its_open_case_but_takes_nothing_new() {
        let mut o = two_markets();
        propose_on(&mut o, MARKET2, 0, "erin.near", Outcome::No);
        act_as(OWNER, 0);
        o.disallow_market(acct(MARKET2));
        assert_eq!(
            logged("market_disallowed"),
            [near_sdk::serde_json::json!({ "market": MARKET2 })]
        );

        act_as(VERIFIER, 2 * SECOND);
        let message = refusal(|| {
            deliver(&mut o, "carol.near", BOND, "propose:market2.near:1:yes:https://x");
        });
        assert!(message.contains("that market contract is not allowed"), "{message}");
        act_as(MARKET2, SECOND);
        let message = refusal(|| o.register_market(U64(9), U64(0), U64(MARKET_DEADLINE), "h".to_string(), None));
        assert!(message.contains("that market contract is not allowed"), "{message}");

        act_as("anyone.near", SECOND + WINDOW);
        o.finalize(acct(MARKET2), U64(0));
        assert_eq!(o.case(&acct(MARKET2), 0).stage, Stage::Final);
        assert_eq!(outcome_receivers(), [MARKET2]);
        assert_eq!(owed(&o, "erin.near"), BOND, "the bond comes back");
        act_as("erin.near", SECOND + WINDOW);
        let _ = o.withdraw_bond();
        o.on_applied(acct(MARKET2), U64(0), Ok(()));
        assert!(o.case(&acct(MARKET2), 0).applied);
    }

    #[test]
    fn a_disallowed_markets_open_case_can_still_be_challenged_but_a_case_that_does_not_exist_cannot() {
        let mut o = two_markets();
        propose_on(&mut o, MARKET2, 0, "erin.near", Outcome::No);
        act_as(OWNER, 0);
        o.disallow_market(acct(MARKET2));

        act_as(VERIFIER, 2 * SECOND);
        let message = refusal(|| {
            deliver(&mut o, "dave.near", BOND, "challenge:market2.near:7:yes");
        });
        assert!(message.contains("that market contract is not allowed"), "{message}");
        deliver(&mut o, "dave.near", BOND, "challenge:market2.near:0:yes");
        assert_eq!(o.case(&acct(MARKET2), 0).stage, Stage::Disputed);
    }

    #[test]
    fn a_disputed_case_of_a_disallowed_market_still_gets_its_draw_votes_and_release() {
        let mut o = two_markets();
        propose_on(&mut o, MARKET2, 0, "carol.near", Outcome::Yes);
        act_as(VERIFIER, CHALLENGED_AT);
        deliver(&mut o, "dave.near", BOND, "challenge:market2.near:0:no");
        act_as(OWNER, 0);
        o.disallow_market(acct(MARKET2));

        act_at_height("anyone.near", DRAW_BY, 5);
        let _ = o.resolve_draw(acct(MARKET2), U64(0));
        act_as(COUNCIL, DRAW_BY + SECOND);
        let jury: Vec<AccountId> = names(FIRST_JURORS, "j").iter().map(|j| acct(j)).collect();
        o.on_drawn(acct(MARKET2), U64(0), 0, Ok(jury));
        let uid = o.case(&acct(MARKET2), 0).case_uid;
        assert!(!o.case(&acct(MARKET2), 0).panel.is_empty());
        act_as("anyone.near", DRAW_BY + SECOND + PANEL + 1);
        o.finalize(acct(MARKET2), U64(0));
        act_as("anyone.near", DRAW_BY + 3 * SECOND + 2 * PANEL + DRAW_WINDOW);
        o.finalize(acct(MARKET2), U64(0));
        assert_eq!(o.case(&acct(MARKET2), 0).stage, Stage::Final);
        let _ = o.retry_unlock(acct(MARKET2), U64(0));
        let keys: Vec<_> = calls_to("unlock_case")
            .iter()
            .map(|u| u["case_key"].as_str().unwrap().to_string())
            .collect();
        let (first, second) = (uid.0.to_string(), (SECOND_ROUND_KEY | uid.0).to_string());
        assert_eq!(
            keys,
            [first.clone(), second.clone(), first, second],
            "the settling call and the retry each release both juries"
        );
    }

    #[test]
    fn the_last_allowed_market_can_be_removed_and_added_back() {
        let mut o = fresh_oracle();
        act_as(OWNER, 0);
        o.disallow_market(acct(MARKET));
        assert_eq!(o.config()["markets"], near_sdk::serde_json::json!([]));
        o.allow_market(acct(MARKET));
        assert_eq!(o.config()["markets"], near_sdk::serde_json::json!([MARKET]));
        assert_eq!(
            logged("market_allowed"),
            [near_sdk::serde_json::json!({ "market": MARKET })]
        );
    }

    #[test]
    fn the_allow_list_is_the_owners_and_has_no_duplicates() {
        let mut o = fresh_oracle();
        act_as("rogue.near", 0);
        assert!(refusal(|| o.allow_market(acct(MARKET2))).contains("owner only"));
        assert!(refusal(|| o.disallow_market(acct(MARKET))).contains("owner only"));
        act_as(OWNER, 0);
        assert!(refusal(|| o.allow_market(acct(MARKET))).contains("already an allowed market"));
        assert!(refusal(|| o.disallow_market(acct(MARKET2))).contains("not an allowed market"));
    }

    #[test]
    fn case_uids_are_unique_across_markets_start_at_one_and_never_change() {
        let mut o = two_markets();
        propose_on(&mut o, MARKET, 0, "carol.near", Outcome::Yes);
        propose_on(&mut o, MARKET2, 0, "erin.near", Outcome::No);
        o.markets.insert(
            (acct(MARKET), 1),
            VersionedMarketInfo::current(MarketInfo {
                resolve_by: U64(MARKET_DEADLINE),
                ..base_info()
            }),
        );
        propose_on(&mut o, MARKET, 1, "carol.near", Outcome::Yes);
        let uids = |o: &OracleContract| {
            [(MARKET, 0), (MARKET2, 0), (MARKET, 1)].map(|(m, id)| o.case(&acct(m), id).case_uid.0)
        };
        assert_eq!(uids(&o), [1, 2, 3]);
        act_as(VERIFIER, 2 * SECOND);
        deliver(&mut o, "dave.near", BOND, "challenge:market2.near:0:yes");
        act_as("anyone.near", SECOND + WINDOW);
        o.finalize(acct(MARKET), U64(1));
        assert_eq!(uids(&o), [1, 2, 3], "challenging and settling never change a uid");
        let json = near_sdk::serde_json::to_value(o.get_case(acct(MARKET2), U64(0))).unwrap();
        assert_eq!(json["case_uid"], "2");
    }

    #[test]
    fn two_markets_with_the_same_id_ask_the_council_for_different_jury_keys() {
        let mut o = two_markets();
        let mut keys = vec![];
        for market in [MARKET, MARKET2] {
            propose_on(&mut o, market, 0, "carol.near", Outcome::Yes);
            act_as(VERIFIER, CHALLENGED_AT);
            deliver(&mut o, "dave.near", BOND, &format!("challenge:{market}:0:no"));
            act_at_height("anyone.near", DRAW_BY, 5);
            let _ = o.resolve_draw(acct(market), U64(0));
            keys.push(calls_to("draw")[0]["case_key"].as_str().unwrap().to_string());
        }
        assert_eq!(keys, ["1", "2"]);
    }

    #[test]
    fn list_cases_lists_one_market_accounts_cases_only() {
        let mut o = two_markets();
        propose_on(&mut o, MARKET, 0, "carol.near", Outcome::Yes);
        assert_eq!(o.list_cases(acct(MARKET), U64(0), 5).len(), 1);
        assert!(o.list_cases(acct(MARKET2), U64(0), 5).is_empty());
    }

    // ---- new events -----------------------------------------------------------------------------------------------

    #[test]
    fn proposed_and_challenged_name_the_market_account_and_the_bond() {
        let mut o = two_markets();
        propose_on(&mut o, MARKET2, 0, "carol.near", Outcome::Yes);
        let data = &logged("proposed")[0];
        assert_eq!(
            (data["market"].as_str(), data["market_id"].as_str()),
            (Some(MARKET2), Some("0"))
        );
        assert_eq!(data["bond"], BOND.to_string());
        act_as(VERIFIER, CHALLENGED_AT);
        deliver(&mut o, "dave.near", BOND, "challenge:market2.near:0:no");
        let data = &logged("challenged")[0];
        assert_eq!(
            (data["market"].as_str(), data["bond"].as_str()),
            (Some(MARKET2), Some(BOND.to_string().as_str()))
        );
    }

    #[test]
    fn a_refused_apply_is_logged_as_apply_failed_and_a_good_one_as_applied() {
        let mut o = two_markets();
        propose_on(&mut o, MARKET, 0, "carol.near", Outcome::Yes);
        act_as(COUNCIL, SECOND);
        o.on_applied(acct(MARKET), U64(0), Err(PromiseError::Failed));
        assert_eq!(
            logged("apply_failed"),
            [near_sdk::serde_json::json!({ "market": MARKET, "market_id": "0" })]
        );
        assert!(logged("outcome_applied").is_empty());
        assert!(!o.case(&acct(MARKET), 0).applied);
        act_as(COUNCIL, SECOND);
        o.on_applied(acct(MARKET), U64(0), Ok(()));
        assert_eq!(
            logged("outcome_applied"),
            [near_sdk::serde_json::json!({ "market": MARKET, "market_id": "0" })]
        );
        assert!(logged("apply_failed").is_empty());
    }

    #[test]
    fn setting_the_jury_size_emits_it() {
        let mut o = fresh_oracle();
        act_as(OWNER, 0);
        o.set_jury_size(LARGER_JURY_SIZE);
        assert_eq!(
            logged("jury_size_set"),
            [near_sdk::serde_json::json!({ "jury_size": LARGER_JURY_SIZE })]
        );
        assert_eq!(o.config()["jury_size"], LARGER_JURY_SIZE);
    }

    #[test]
    fn the_jury_size_setting_refuses_even_sizes_sizes_below_the_floor_and_sizes_above_the_panel_cap() {
        let mut o = fresh_oracle();
        act_as(OWNER, 0);
        for size in [0, 1, 3, MIN_JURY_SIZE + 1, MAX_PANEL as u32 + 1, MAX_PANEL as u32 + 2] {
            let message = refusal(|| o.set_jury_size(size));
            assert!(
                message.contains("jury size must be odd, from 5 to 21"),
                "{size}: {message}"
            );
        }
        o.set_jury_size(MIN_JURY_SIZE);
        o.set_jury_size(MAX_PANEL as u32);
    }

    #[test]
    fn a_new_oracle_refuses_a_bond_a_window_or_a_jury_below_the_floors() {
        let at_floor = [MIN_WINDOW_MS; 4];
        near_sdk::mock::with_mocked_blockchain(|b| {
            let _ = b.take_storage();
        });
        act_as(OWNER, 0);
        drop(new_oracle(COLLATERAL, MIN_BOND, at_floor, MIN_JURY_SIZE, 2));
        let message = refusal(|| drop(new_oracle(COLLATERAL, MIN_BOND - 1, at_floor, MIN_JURY_SIZE, 2)));
        assert!(message.contains("the bond must be at least 5 USDC"), "{message}");
        for which in 0..at_floor.len() {
            let mut windows = at_floor;
            windows[which] = MIN_WINDOW_MS - 1;
            let message = refusal(|| drop(new_oracle(COLLATERAL, MIN_BOND, windows, MIN_JURY_SIZE, 2)));
            assert!(
                message.contains("windows must be at least an hour"),
                "window {which}: {message}"
            );
        }
        for size in [1, 3, MIN_JURY_SIZE + 1] {
            let message = refusal(|| drop(new_oracle(COLLATERAL, MIN_BOND, at_floor, size, 2)));
            assert!(
                message.contains("jury size must be odd, from 5 to 21"),
                "{size}: {message}"
            );
        }
    }

    // The jury size and the draw delay are copied onto the case when it is proposed.
    #[test]
    fn a_setting_change_after_the_proposal_changes_neither_the_jury_size_nor_the_draw_delay_of_the_case() {
        let mut o = oracle_with_bond(BOND);
        o.put_market(
            0,
            MarketInfo {
                resolve_by: U64(MARKET_DEADLINE),
                ..base_info()
            },
        );
        act_as(VERIFIER, SECOND);
        deliver(&mut o, "carol.near", BOND, "propose:market.near:0:yes:https://x");
        let proposed = o.case(&acct(MARKET), 0);
        assert_eq!(
            (proposed.jury_size, proposed.draw_delay_blocks),
            (TEST_JURY_SIZE, Some(U64(TEST_DRAW_DELAY_BLOCKS)))
        );
        act_as(OWNER, 2 * SECOND);
        o.set_jury_size(LARGER_JURY_SIZE);
        o.set_draw_delay_blocks(U64(TEST_DRAW_DELAY_BLOCKS + 30));

        act_at_height(VERIFIER, CHALLENGED_AT, 10);
        deliver(&mut o, "dave.near", BOND, "challenge:market.near:0:no");
        let case = o.case(&acct(MARKET), 0);
        assert_eq!(
            case.jury_size, TEST_JURY_SIZE,
            "the open case keeps the jury size it was proposed with"
        );
        assert_eq!(case.draw_after_height.0, 10 + TEST_DRAW_DELAY_BLOCKS);

        act_at_height("anyone.near", DRAW_BY, 100);
        let _ = o.resolve_draw(acct(MARKET), U64(0));
        assert_eq!(calls_to("draw")[0]["n"], TEST_JURY_SIZE);

        act_unpaid(OWNER, DRAW_BY);
        o.set_draw_delay_blocks(U64(TEST_DRAW_DELAY_BLOCKS + 60));
        act_at_height("anyone.near", QUEUE_OVER, 400);
        o.finalize(acct(MARKET), U64(0));
        let escalated = o.case(&acct(MARKET), 0);
        assert_eq!(escalated.round, 1);
        assert_eq!(
            escalated.draw_after_height.0,
            400 + TEST_DRAW_DELAY_BLOCKS,
            "the second jury waits the case's own delay"
        );
    }

    #[test]
    fn market_events_carry_the_market_account() {
        let mut o = two_markets();
        act_as(MARKET2, SECOND);
        o.register_market(U64(3), U64(0), U64(MARKET_DEADLINE), "h".to_string(), None);
        assert_eq!(
            logged("market_registered"),
            [near_sdk::serde_json::json!({ "market": MARKET2, "market_id": "3" })]
        );
        let mut o = challenged(Outcome::Yes, Outcome::No);
        act_at_height("anyone.near", DRAW_BY, 5);
        let _ = o.resolve_draw(acct(MARKET), U64(0));
        act_as(COUNCIL, DRAW_BY);
        o.on_drawn(acct(MARKET), U64(0), 0, Err(PromiseError::Failed));
        assert_eq!(
            logged("draw_failed"),
            [near_sdk::serde_json::json!({ "market": MARKET, "market_id": "0", "round": 0 })]
        );
        let jury: Vec<AccountId> = names(FIRST_JURORS, "j").iter().map(|j| acct(j)).collect();
        o.on_drawn(acct(MARKET), U64(0), 0, Ok(jury));
        assert_eq!(logged("jury_drawn")[0]["market"], MARKET);
        act_as(JURORS[0], DRAW_BY + 1);
        o.commit_vote(acct(MARKET), U64(0), "a".repeat(64));
        assert_eq!(logged("vote_committed")[0]["market"], MARKET);
    }

    // ---- version tags ---------------------------------------------------------------------------------------------

    fn current_bytes<T: BorshSerialize>(value: &T) -> Vec<u8> {
        near_sdk::borsh::to_vec(value).unwrap()
    }

    // The case record a version-2 contract stored: version byte 0 and the layout before the draw delay.
    const CASE_VERSION_TAG: u8 = 1;
    const OLD_CASE_VERSION_TAG: u8 = 0;

    fn case_v1_of(case: &Case) -> CaseV1 {
        CaseV1 {
            case_uid: case.case_uid,
            stage: case.stage,
            proposer: case.proposer.clone(),
            proposed: case.proposed,
            bond: case.bond,
            evidence: case.evidence.clone(),
            window_ends_at: case.window_ends_at,
            challenger: case.challenger.clone(),
            challenger_answer: case.challenger_answer,
            round: case.round,
            jury_size: case.jury_size,
            draw_by: case.draw_by,
            draw_after_height: case.draw_after_height,
            commit_ends_at: case.commit_ends_at,
            panel_deadline: case.panel_deadline,
            panel: case.panel.clone(),
            first_panel: case.first_panel.clone(),
            seated: case.seated,
            commits: case.commits.clone(),
            votes: case.votes.clone(),
            final_outcome: case.final_outcome,
            applied: case.applied,
            challenged_at: case.challenged_at,
            juror_share_bps: case.juror_share_bps,
            no_decision_share_bps: case.no_decision_share_bps,
            delinquent: case.delinquent.clone(),
        }
    }

    fn old_case_bytes(case: &Case) -> Vec<u8> {
        let mut bytes = vec![OLD_CASE_VERSION_TAG];
        bytes.extend(current_bytes(&case_v1_of(case)));
        bytes
    }

    #[test]
    fn a_case_stored_before_the_draw_delay_was_kept_reads_back_without_one() {
        let case = proposed_case();
        let back = VersionedCase::try_from_slice(&old_case_bytes(&case))
            .unwrap()
            .into_inner();
        assert_eq!(back.draw_delay_blocks, None);
        assert_eq!(current_bytes(&case_v1_of(&back)), current_bytes(&case_v1_of(&case)));
        assert_eq!(case.draw_delay_blocks, Some(U64(TEST_DRAW_DELAY_BLOCKS)));
    }

    #[test]
    fn stored_records_start_with_their_version_byte_and_round_trip() {
        let case = proposed_case();
        let bytes = current_bytes(&VersionedCase::current(case.clone()));
        assert_eq!(bytes[0], CASE_VERSION_TAG);
        assert_eq!(&bytes[1..], current_bytes(&case).as_slice());
        let back = VersionedCase::try_from_slice(&bytes).unwrap();
        assert_eq!(current_bytes(&back), bytes);

        let bytes = current_bytes(&VersionedMarketInfo::current(base_info()));
        assert_eq!(bytes[0], 0);
        let back = VersionedMarketInfo::try_from_slice(&bytes).unwrap();
        assert_eq!(current_bytes(&back), bytes);

        let payout = Payout {
            account: acct("carol.near"),
            amount: U128(5),
            at: U64(9),
        };
        let bytes = current_bytes(&VersionedPayout::current(payout.clone()));
        assert_eq!(bytes[0], 0);
        let back = VersionedPayout::try_from_slice(&bytes).unwrap();
        assert_eq!(
            (back.account.clone(), back.amount, back.at),
            (payout.account, payout.amount, payout.at)
        );
    }

    #[test]
    fn what_the_maps_store_carries_the_version_byte() {
        let mut o = two_markets();
        propose_on(&mut o, MARKET, 0, "carol.near", Outcome::Yes);
        o.cases.flush();
        let stored = near_sdk::mock::with_mocked_blockchain(|b| b.take_storage());
        let case_bytes = current_bytes(&VersionedCase::current(o.case(&acct(MARKET), 0)));
        assert_eq!(case_bytes[0], CASE_VERSION_TAG);
        let found = stored.values().any(|v| *v == case_bytes);
        assert!(found, "the case is stored as the tagged bytes");
    }

    #[test]
    fn a_record_from_a_newer_version_is_refused_with_a_plain_message() {
        let mut bytes = current_bytes(&VersionedCase::current(proposed_case()));
        bytes[0] = CASE_VERSION_TAG + 1;
        let message = refusal(|| {
            let _ = VersionedCase::try_from_slice(&bytes);
        });
        assert!(message.contains("newer version than this code can read"), "{message}");
        let message = refusal(|| {
            let _ = VersionedMarketInfo::try_from_slice(&[7]);
        });
        assert!(message.contains("newer version"), "{message}");
        let message = refusal(|| {
            let _ = VersionedPayout::try_from_slice(&[2]);
        });
        assert!(message.contains("newer version"), "{message}");
    }

    #[test]
    fn a_new_oracle_starts_at_the_current_state_version() {
        assert_eq!(fresh_oracle().state_version, STATE_VERSION);
        assert_eq!(STATE_VERSION, 3);
    }
}
